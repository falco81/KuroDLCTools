# Troubleshooting

## "The plugin tries to open every file (.md, .ini, .inf, …)"

This was a bug in v1.3.0 – v1.3.2 caused by a too-loose detect string
that matched any text file with `#TBL` somewhere in its content.

**Fix:** upgrade to v1.3.3 by re-running the auto-installer:

1. In Total Commander, navigate to `tbl_wlx_v1.3.3_plugin.zip` and
   press Enter on it.
2. Confirm the install when TC prompts.
3. Restart TC.

If TC doesn't show the install prompt, the auto-installer was probably
disabled. Open `wincmd.ini`, find the `[ListerPlugins]` section, and
change the `<n>_detect=...` line for `tbl_wlx.wlx64` to:

```
EXT="TBL" | ([0]=35 & [1]=84 & [2]=66 & [3]=76) | ([0]=249 & [1]=186) | ([0]=217 & [1]=186)
```

Save and restart TC.

## "TC opens .tbl files in its built-in hex/text viewer instead of mine"

The detection rule needs the schemas folder to be next to the DLL.
Verify your install layout:

```
C:\Tools\TC\Plugins\wlx\tbl_wlx\
    tbl_wlx.wlx64
    schemas\
        headers\
            *.json (282 files)
        t_*.json (81 files)
```

If the `schemas\` folder is missing or empty, the plugin's own
`ListLoad` returns 0 and TC falls back to its default viewer. You'll
also see no schema-related errors in TC's log because the plugin
never gets that far.

Check via Configuration → Options → Plugins → Lister (WLX) →
Configure that the plugin is registered and its detection string
is the auto-generated `EXT="TBL" | (FIND("#TBL")...)`.

## "The viewer opens but the JSON tab shows my error message"

The plugin couldn't parse the file. Most common reasons:

1. **CLE-encrypted with a key the plugin doesn't have.** We support
   the standard CLE keys (`F9BA`/`D9BA`/`C9BA` magics) shipped with
   KuroTools. Custom-keyed dumps require the matching Blowfish key
   to be added to `cle.pas` and a rebuild.

2. **Schema version mismatch.** Some games (Kuro 2 patch 1.1.4 etc.)
   add fields KuroTools' bundled schemas don't yet know about. The
   plugin will fall back to raw-passthrough mode for affected sections
   so you can still inspect/save the file, just without grid editing.

3. **Truncated file.** The post-CLE plain bytes need to be at least
   `8 + 80*sec_count + sec_data` long. A truncated download usually
   produces "Section ... extends past EOF".

## "Grid shows '[N rows]' for some columns — how do I edit those?"

These are nested struct fields. Double-click the cell — a sub-grid
dialog opens with one row per nested element. Edit there, close the
dialog, and the changes appear in the parent file.

## "Save fails with 'JSON parse error'"

The JSON tab content didn't round-trip. Either:
- A trailing comma somewhere, or unmatched braces — check the line
  number in the error message. The Edit control is line-aware so
  you can navigate via Ctrl+G in TC's Lister.
- A non-ASCII string was edited and your locale isn't UTF-8. The
  plugin reads/writes raw UTF-8 bytes — TC's default codepage doesn't
  matter at parse time, but the Win32 Edit control uses the system
  ANSI codepage on Windows < 10. Switching system locale to UTF-8 (or
  using Windows 10 1903+ "Beta: Use Unicode UTF-8 for worldwide
  language support") fixes this.

## "The plugin crashes Total Commander when I open a corrupt .tbl"

This shouldn't happen — every entry point is wrapped in `try/except`
and the section directory has bounds checks. If it does, please file
a bug with:
- TC version (Configuration → About)
- Plugin version (1.3 if downloaded from this repo)
- A copy of the .tbl that crashes (or its first 256 bytes)
- Whether the crash is on F3, on save, or somewhere else

## "F2 doesn't reload, gives an unsaved-changes prompt"

That's expected — F2 in Lister means "reload from disk" and would
discard any in-memory edits. Click Yes to confirm the discard, or
Ctrl+S first to save, then F2.

## "I edited an array field but the change didn't stick"

Array fields (rendered as `[1, 2, 3]`) are read-only in the grid in
v1.3. Switch to the JSON tab to edit them. Other fields persist
through save+reload normally.

## "Search doesn't find anything in the grid"

F3/F7 search currently operates on the JSON tab only. Cycle to the
JSON tab (last tab in the strip) before searching. Per-cell grid
search is planned for v2.

## Where do I report bugs?

Open an issue on the GitHub repo, or use TC's plugin feedback channel.
Include the version, the .tbl that misbehaves, and the contents of
your `tbl_wlx.ini` if you've changed `PreferredGame`.
