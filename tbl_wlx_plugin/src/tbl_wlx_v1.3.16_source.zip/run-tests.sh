#!/bin/bash
#
# run-tests.sh — run the Linux smoke regression suite
#
# Returns exit 0 on all-green, exit 1 on any failure.
# Intended as a pre-release gate and CI hook.

set -u

REPO="$(cd "$(dirname "$0")" && pwd)"
SRC="$REPO/src"
TESTS="$REPO/tests"
# Default to the schemas folder shipped in this source package
SCHEMAS="${SCHEMAS:-$REPO/schemas}"
# CORPUS is optional — needed only for the 411-file regressions
CORPUS="${CORPUS:-}"

if [ ! -d "$SCHEMAS" ]; then
  echo "error: SCHEMAS=$SCHEMAS not found"
  echo "  set SCHEMAS env var to point at the KuroTools schemas folder"
  exit 2
fi

cd "$TESTS" || exit 2

# Build all
echo "=== Building tests ==="
BUILD_FAIL=0
for t in testblowfish testcle testschemas testtypes testread \
         testroundtrip testjsonrt testsave testedit testgrid \
         testgridedit testarrayedit testgridsearch testini teste2e; do
  if [ ! -f "${t}.pas" ]; then continue; fi
  if ! fpc -O2 -Sh "-Fu$SRC" "${t}.pas" >/tmp/build_$$.log 2>&1; then
    echo "  BUILD FAIL: $t"
    tail -3 /tmp/build_$$.log | sed 's/^/    /'
    BUILD_FAIL=$((BUILD_FAIL + 1))
  fi
done
rm -f /tmp/build_$$.log
if [ "$BUILD_FAIL" -gt 0 ]; then
  echo "Aborting: $BUILD_FAIL test(s) failed to build"
  exit 1
fi
echo "  all builds OK"

# Run regressions. Each entry is (display name, command, expected substring).
PASS=0; FAIL=0
RUN_CHECK() {
  local NAME="$1"; local EXPECT="$2"; shift 2
  local OUT
  OUT=$("$@" 2>&1)
  if echo "$OUT" | grep -qF "$EXPECT"; then
    printf "  ✓ %-30s\n" "$NAME"
    PASS=$((PASS + 1))
  else
    printf "  ✗ %-30s\n" "$NAME"
    echo "$OUT" | tail -3 | sed 's/^/      /'
    FAIL=$((FAIL + 1))
  fi
}

echo
echo "=== Crypto ==="
RUN_CHECK "Blowfish vectors"   "PASS  CTR roundtrip"             ./testblowfish
RUN_CHECK "CLE 4 fixtures"     "PASS  F9BA(plain) -> plain+pad"  ./testcle

echo
echo "=== Schema parsing ==="
RUN_CHECK "Schema DB lookup"   "PASS  DLCTableData len=64"  ./testschemas "$SCHEMAS"
RUN_CHECK "Type-system 346"    "Failed:                0"  ./testtypes "$SCHEMAS/headers"

echo
echo "=== File I/O ==="
if [ -n "$CORPUS" ] && [ -d "$CORPUS" ]; then
  RUN_CHECK "411 files read"             "read errors=0"             ./testread "$SCHEMAS" "$CORPUS"
  RUN_CHECK "411 direct round-trip"      "Bad:             0"        ./testroundtrip "$SCHEMAS" "$CORPUS"
  RUN_CHECK "411 JSON round-trip"        "Bad / divergent:             0" ./testjsonrt "$SCHEMAS" "$CORPUS"
  RUN_CHECK "411 save pipeline"          "Total: 411, processed: 411" ./testsave "$SCHEMAS" "$CORPUS"
else
  echo "  (skipped 411-file regressions: set CORPUS=/path/to/extracted/tbls"
  echo "   to enable them; they need a real script_eng.p3a unpack.)"
fi

echo
echo "=== Editing ==="
export TBL_SCHEMAS="$SCHEMAS"
if [ -n "$CORPUS" ] && [ -d "$CORPUS" ]; then
  export TBL_CORPUS="$CORPUS"
  RUN_CHECK "JSON edit"     "PASS: edited DLC item name is present"   ./testedit
  RUN_CHECK "Grid edit"     "PASS: scalar + nested-leaf edits"        ./testgridedit
RUN_CHECK "Array edit"    "PASS: array edit round-trip OK"          ./testarrayedit
  RUN_CHECK "End-to-end"    "PASS: full end-to-end pipeline OK"       ./teste2e
else
  echo "  (skipped edit-pipeline tests: set CORPUS=/path/to/extracted/tbls)"
fi
RUN_CHECK "INI settings"  "PASS: inisettings unit tests OK"         ./testini
RUN_CHECK "Grid search"   "PASS: grid-search substring rules OK"    ./testgridsearch

echo
echo "============================================"
printf "Result: %d pass, %d fail\n" "$PASS" "$FAIL"
echo "============================================"

if [ "$FAIL" -gt 0 ]; then exit 1; else exit 0; fi
