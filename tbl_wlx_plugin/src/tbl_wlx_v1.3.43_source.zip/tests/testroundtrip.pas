program testroundtrip;
{$mode objfpc}{$H+}

uses Classes, SysUtils, md5, fpjson, jsonparser,
     tbltypes, tblschemas, tblfile;

function MD5OfFile(const Path: AnsiString): AnsiString;
begin
  Result := MD5Print(MD5File(Path));
end;

function CompareJSON(A, B: TJSONData): Boolean; forward;

function CompareJSONArray(A, B: TJSONArray): Boolean;
var i: Integer;
begin
  if A.Count <> B.Count then Exit(False);
  for i := 0 to A.Count - 1 do
    if not CompareJSON(A.Items[i], B.Items[i]) then Exit(False);
  Result := True;
end;

function CompareJSONObject(A, B: TJSONObject): Boolean;
var i, idx: Integer;
begin
  if A.Count <> B.Count then Exit(False);
  for i := 0 to A.Count - 1 do
  begin
    idx := B.IndexOfName(A.Names[i]);
    if idx < 0 then Exit(False);
    if not CompareJSON(A.Items[i], B.Items[idx]) then Exit(False);
  end;
  Result := True;
end;

function CompareJSON(A, B: TJSONData): Boolean;
begin
  if A.JSONType <> B.JSONType then Exit(False);
  case A.JSONType of
    jtArray:  Result := CompareJSONArray(TJSONArray(A), TJSONArray(B));
    jtObject: Result := CompareJSONObject(TJSONObject(A), TJSONObject(B));
    jtNumber: Result := A.AsFloat = B.AsFloat;
    jtString: Result := A.AsString = B.AsString;
    jtBoolean:Result := A.AsBoolean = B.AsBoolean;
  else
    Result := True;
  end;
end;

// Heuristic: infer game-tag preference from a path. We scan path
// elements for known game name fragments and return the matching
// schema platform game tag. Returns empty string on no match (then
// the schema DB picks the first size-matching variant).
function InferGame(const P: AnsiString): AnsiString;
var
  Lower: AnsiString;
begin
  Lower := LowerCase(P);
  if Pos('daybreak ii', Lower) > 0 then Exit('Kuro2');
  if Pos('daybreak2',   Lower) > 0 then Exit('Kuro2');
  if Pos('daybreak',    Lower) > 0 then Exit('Kuro1');
  if Pos('beyond',      Lower) > 0 then Exit('Kuro2');
  if Pos('horizon',     Lower) > 0 then Exit('Kuro2');
  if Pos('ys x',        Lower) > 0 then Exit('Ys_X');
  if Pos('ys_x',        Lower) > 0 then Exit('Ys_X');
  if Pos('nordics',     Lower) > 0 then Exit('Ys_X');
  if Pos('sky',         Lower) > 0 then Exit('Sora1');
  if Pos('sora',        Lower) > 0 then Exit('Sora1');
  Result := '';
end;

var
  DB: TSchemaDB;
  Errs: TStringList;
  SR: TSearchRec;
  Path, Dir, TmpPath, PreferGame: AnsiString;
  T1, T2: TTBLFile;
  J1, J2: TJSONObject;
  Total, BitId, FuncId, Bad: Integer;
  i: Integer;
  Md5Orig, Md5New: AnsiString;
  BadSamples: TStringList;
begin
  if ParamCount < 2 then
  begin
    WriteLn('usage: testroundtrip <schemas dir> <tbl dir>');
    Halt(1);
  end;

  DB := TSchemaDB.Create;
  Errs := TStringList.Create;
  BadSamples := TStringList.Create;
  try
    DB.LoadFromDir(ParamStr(1), Errs);
    WriteLn(Format('Schemas: %d / %d',
                   [DB.HeaderCount, DB.VariantCount]));

    Total := 0; BitId := 0; FuncId := 0; Bad := 0;

    Dir := IncludeTrailingPathDelimiter(ParamStr(2));
    if FindFirst(Dir + '*.tbl', faAnyFile, SR) = 0 then
    begin
      repeat
        Path := Dir + SR.Name;
        Inc(Total);
        TmpPath := Path + '.rt_test';
        try
          Md5Orig := MD5OfFile(Path);

          T1 := TTBLFile.Create(DB);
          T2 := TTBLFile.Create(DB);
          try
            PreferGame := InferGame(Dir);
            T1.ReadFromFile(Path, PreferGame);
            T1.WriteToFile(TmpPath);
            Md5New := MD5OfFile(TmpPath);

            if Md5Orig = Md5New then
            begin
              Inc(BitId);
              Inc(FuncId);
            end
            else
            begin
              WriteLn('  DIFFER  ', SR.Name);
              T2.ReadFromFile(TmpPath, PreferGame);
              J1 := T1.ToJSON; J2 := T2.ToJSON;
              try
                if CompareJSON(J1, J2) then
                  Inc(FuncId)
                else
                begin
                  Inc(Bad);
                  if BadSamples.Count < 10 then
                    BadSamples.Add(SR.Name);
                end;
              finally J1.Free; J2.Free; end;
            end;
          finally
            T1.Free; T2.Free;
          end;
        except
          on E: Exception do
          begin
            Inc(Bad);
            if BadSamples.Count < 10 then
              BadSamples.Add(Format('%s: %s', [SR.Name, E.Message]));
          end;
        end;
        if FileExists(TmpPath) then DeleteFile(TmpPath);
      until FindNext(SR) <> 0;
      FindClose(SR);
    end;

    WriteLn;
    WriteLn(Format('Total:           %d', [Total]));
    if Total > 0 then
    begin
      WriteLn(Format('Bit-identical:   %d  (%.1f%%)',
                     [BitId, 100.0 * BitId / Total]));
      WriteLn(Format('Func-identical:  %d  (%.1f%%)',
                     [FuncId, 100.0 * FuncId / Total]));
    end;
    WriteLn(Format('Bad:             %d', [Bad]));
    if Bad > 0 then
    begin
      WriteLn('Bad samples:');
      for i := 0 to BadSamples.Count - 1 do
        WriteLn('  ', BadSamples[i]);
    end;
  finally
    Errs.Free;
    BadSamples.Free;
    DB.Free;
  end;
end.
