program teste2e;
{$mode objfpc}{$H+}

// Simulates the full plugin lifecycle WITHOUT Win32 GUI:
//
//   1. Plugin init
//        - schema DB load (= ListSetDefaultParams + ListLoad path)
//        - INI load (no-op if path empty)
//   2. Open file (ListLoad path)
//        - ReadFromFile
//        - BuildColumns for each section
//        - Grid bound to TJSONArray
//   3. User makes a scalar edit in grid (SetCellText)
//   4. User opens nested-summary cell, edits a leaf (SetCellText
//      against nested TJSONObject inside GetNestedArray)
//   5. User presses Ctrl+S in JSON tab
//        - GetViewerText (we simulate by serializing ToJSON)
//        - StripHeaderComment
//        - JSON parse with [] (no joUTF8) to preserve bytes
//        - FromJSON
//        - WriteToFile
//   6. F2 reload
//        - ReadFromFile fresh
//        - Both edits should still be visible
//   7. Close prompt: dirty=false (we just saved), no prompt fires.
//        We just verify the flag.
//
// On any FAIL we print the issue and Halt(1).

uses
  Classes, SysUtils, fpjson, jsonparser, jsonscanner,
  tbltypes, tblschemas, tblfile, gridmodel, inisettings;

procedure CheckOrFail(const Cond: Boolean; const Where: AnsiString);
begin
  if not Cond then
  begin
    WriteLn('FAIL: ', Where);
    Halt(1);
  end;
end;

function StripHeaderComment(const Text: AnsiString): AnsiString;
var
  i, n, LineStart: Integer;
begin
  n := Length(Text); i := 1;
  while i <= n do
  begin
    LineStart := i;
    while (i <= n) and (Text[i] <> #10) do Inc(i);
    if  ((i - LineStart >= 2) and (Text[LineStart] = '/') and
         (Text[LineStart+1] = '/'))
       or (Trim(Copy(Text, LineStart, i - LineStart)) = '') then
    begin
      if (i <= n) and (Text[i] = #10) then Inc(i);
      Continue;
    end;
    Result := Copy(Text, LineStart, n - LineStart + 1); Exit;
  end;
  Result := '';
end;

var
  DB: TSchemaDB; Errs: TStringList;
  T: TTBLFile;
  V: TSchemaVariant;
  Cols, SubCols: TGridColumnArray;
  Row0, NestedRow0: TJSONObject;
  NestedArr: TJSONArray;
  NestedColIdx, IdColIdx, V1ColIdx, i: Integer;
  Path, TmpPath: AnsiString;
  Js: TJSONObject;
  P: TJSONParser;
  HeaderText, JsonBody: AnsiString;
  Dirty: Boolean;
begin
  Path := GetEnvironmentVariable('TBL_CORPUS') + '/t_item.tbl';
  TmpPath := Path + '.e2e_test';

  // Step 1: plugin init
  WriteLn('STEP 1: plugin init');
  LoadINI('');  // no INI path supplied yet — defaults
  CheckOrFail(GetPreferredGame = '', 'INI default empty');
  DB := TSchemaDB.Create; Errs := TStringList.Create;
  DB.LoadFromDir(GetEnvironmentVariable('TBL_SCHEMAS'), Errs);
  CheckOrFail(DB.HeaderCount = 282, 'schemas loaded');

  // Step 2: open file
  WriteLn('STEP 2: ListLoad simulation');
  T := TTBLFile.Create(DB);
  T.ReadFromFile(Path, GetPreferredGame);
  CheckOrFail(Length(T.Sections) = 4, 't_item has 4 sections');
  CheckOrFail(T.Sections[0].Mode = smDecoded, 'sec 0 decoded');

  CheckOrFail(DB.FindVariant(T.Sections[0].Name,
                T.Sections[0].EntryLength, T.Sections[0].GameTag, V),
              'variant lookup');
  Cols := BuildColumns(V.Fields);
  WriteLn('  Built ', Length(Cols), ' columns for ItemTableData');

  // Find the columns we'll edit
  IdColIdx := -1; NestedColIdx := -1;
  for i := 0 to High(Cols) do
  begin
    if Cols[i].DisplayName = 'id' then IdColIdx := i;
    if Cols[i].Kind = ckNestedSummary then NestedColIdx := i;
  end;
  CheckOrFail(IdColIdx >= 0, 'found id column');
  CheckOrFail(NestedColIdx >= 0, 'found nested-summary column');

  // Step 3: scalar edit in grid (simulates grid.CommitEdit)
  WriteLn('STEP 3: grid scalar edit');
  Row0 := T.Sections[0].Rows.Objects[0];
  CheckOrFail(SetCellText(Row0, Cols[IdColIdx], '42424'),
              'SetCellText scalar');
  Dirty := True;  // would be set by MarkDirty callback

  // Step 4: nested leaf edit (simulates sub-grid edit)
  WriteLn('STEP 4: sub-grid nested edit');
  NestedArr := GetNestedArray(Row0, Cols[NestedColIdx]);
  CheckOrFail(NestedArr <> nil, 'GetNestedArray');
  CheckOrFail(NestedArr.Count >= 1, 'nested has rows');
  SubCols := BuildNestedColumns(
    TFieldList(Cols[NestedColIdx].NestedFT.NestedFields));
  V1ColIdx := -1;
  for i := 0 to High(SubCols) do
    if SubCols[i].DisplayName = 'value1' then V1ColIdx := i;
  CheckOrFail(V1ColIdx >= 0, 'found nested value1 column');
  NestedRow0 := TJSONObject(NestedArr.Items[0]);
  CheckOrFail(SetCellText(NestedRow0, SubCols[V1ColIdx], '1234'),
              'SetCellText nested leaf');
  Dirty := True;

  // Step 5: simulate Ctrl+S in JSON tab. The JSON tab text is what
  // ToJSON would produce (plus a header comment for visual cue).
  WriteLn('STEP 5: simulate Ctrl+S Save');
  Js := T.ToJSON;
  HeaderText := '// header line' + #10 + #10 + Js.FormatJSON();
  Js.Free;
  JsonBody := StripHeaderComment(HeaderText);
  CheckOrFail(JsonBody <> '', 'StripHeaderComment got body');

  P := TJSONParser.Create(JsonBody, []);
  try Js := TJSONObject(P.Parse); finally P.Free; end;
  CheckOrFail(Js <> nil, 'JSON parse');
  T.FromJSON(Js);
  Js.Free;
  T.WriteToFile(TmpPath);
  Dirty := False;
  T.Free;
  CheckOrFail(FileExists(TmpPath), 'file written');

  // Step 6: F2 reload simulation
  WriteLn('STEP 6: F2 reload simulation');
  T := TTBLFile.Create(DB);
  T.ReadFromFile(TmpPath, GetPreferredGame);
  Row0 := T.Sections[0].Rows.Objects[0];
  CheckOrFail(Row0.Get('id', Int64(-1)) = 42424,
              'scalar edit persisted');
  NestedArr := GetNestedArray(Row0, Cols[NestedColIdx]);
  CheckOrFail(NestedArr <> nil, 'reloaded nested array');
  CheckOrFail(TJSONObject(NestedArr.Items[0]).Get('value1', Int64(-1)) = 1234,
              'nested leaf edit persisted');
  T.Free;

  // Step 7: dirty flag check
  WriteLn('STEP 7: dirty flag');
  CheckOrFail(Dirty = False, 'dirty cleared after save');

  if FileExists(TmpPath) then DeleteFile(TmpPath);
  Errs.Free; DB.Free;
  WriteLn;
  WriteLn('PASS: full end-to-end pipeline OK');
end.
