program testini;
{$mode objfpc}{$H+}

// Verify inisettings API surface (validation + accessors) on Linux,
// where the actual file I/O is stubbed. The real read/write is
// exercised on Windows in TC.

uses Classes, SysUtils, inisettings;

procedure CheckOrFail(Cond: Boolean; const Where: AnsiString);
begin
  if not Cond then
  begin
    WriteLn('FAIL: ', Where);
    Halt(1);
  end;
end;

var
  X, Y, W, H: Integer;
  M: Boolean;
begin
  // Validation
  CheckOrFail(IsValidGameTag(''),         'empty is valid');
  CheckOrFail(IsValidGameTag('Kuro1'),    'Kuro1 is valid');
  CheckOrFail(IsValidGameTag('Kuro2'),    'Kuro2 is valid');
  CheckOrFail(IsValidGameTag('Sora1'),    'Sora1 is valid');
  CheckOrFail(IsValidGameTag('Ys_X'),     'Ys_X is valid');
  CheckOrFail(IsValidGameTag('Kai'),      'Kai is valid');
  CheckOrFail(not IsValidGameTag('garbage'), 'garbage is invalid');

  // Round-trip the in-memory value
  CheckOrFail(GetPreferredGame = '', 'default is empty');
  SetPreferredGame('Kuro2');
  CheckOrFail(GetPreferredGame = 'Kuro2', 'set Kuro2');
  SetPreferredGame('garbage');
  CheckOrFail(GetPreferredGame = 'Kuro2', 'invalid does not overwrite');
  SetPreferredGame('');
  CheckOrFail(GetPreferredGame = '', 'set back to empty');

  // No-op LoadINI/SaveINI when path is empty
  LoadINI('');
  SaveINI('');

  // DefaultEditMode round-trip
  CheckOrFail(GetDefaultEditMode = False, 'default edit mode is False');
  SetDefaultEditMode(True);
  CheckOrFail(GetDefaultEditMode = True, 'set edit mode True');
  SetDefaultEditMode(False);
  CheckOrFail(GetDefaultEditMode = False, 'set edit mode False');

  // Window-state flags round-trip
  CheckOrFail(GetRememberWindowSize = True,  'default remember=True');
  SetRememberWindowSize(False);
  CheckOrFail(GetRememberWindowSize = False, 'set remember=False');
  SetRememberWindowSize(True);

  CheckOrFail(GetMaximizeOnOpen = False, 'default maximize=False');
  SetMaximizeOnOpen(True);
  CheckOrFail(GetMaximizeOnOpen = True, 'set maximize=True');
  SetMaximizeOnOpen(False);

  // Last window state round-trip
  SetLastWindowState(100, 200, 800, 600, False);
  GetLastWindowState(X, Y, W, H, M);
  CheckOrFail((X = 100) and (Y = 200) and (W = 800) and (H = 600) and (not M),
              'window state round-trip');
  SetLastWindowState(0, 0, 0, 0, True);
  GetLastWindowState(X, Y, W, H, M);
  CheckOrFail(M, 'maximized flag round-trip');

  WriteLn('PASS: inisettings unit tests OK');
end.
