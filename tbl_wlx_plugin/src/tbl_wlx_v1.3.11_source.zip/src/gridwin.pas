unit gridwin;
{$mode objfpc}{$H+}

// Win32 grid widget built on a virtual ListView (LVS_OWNERDATA report
// view). One grid corresponds to one TBL section's row data; columns
// are derived from the section's schema via gridmodel.BuildColumns.
//
// Why virtual?  Real Falcom tables can have 2000+ rows and 50+
// columns — a normal "fill all items" ListView would take a noticeable
// time on every load. Virtual mode means we hand cell text to the
// listview only when it asks (LVN_GETDISPINFO).
//
// Editing model:
//   - Scalar / string cell: double-click opens a floating Edit
//     overlay positioned over the cell. Enter to commit, Escape to
//     cancel.
//   - Array cell: read-only (refused with MessageBeep).
//   - Nested-summary cell: double-click opens a SUB-GRID DIALOG
//     showing the nested array's rows in their own grid. The user
//     edits there normally, closes via OK to keep changes (in-place
//     in the parent JSON) or Cancel to revert.
//
// External callbacks:
//   - OnDirtyChange: invoked when a cell edit succeeds, so the host
//     window can mark the file as modified for the close-prompt.

interface

uses
  Windows, Messages, SysUtils, Classes, CommCtrl,
  fpjson, tbltypes, gridmodel, pluginstate;

type
  TGridDirtyCallback = procedure(GridWnd: HWND);

  // Per-grid state we attach to the ListView via SetWindowLongPtr.
  PGridState = ^TGridState;
  TGridState = record
    Cols:       TGridColumnArray;
    Rows:       TJSONArray;        // borrowed from TTBLSection.Rows
    EditWnd:    HWND;              // floating Edit overlay
    OrigEditProc: LONG_PTR;        // subclassed Edit proc
    EditingRow: Integer;
    EditingCol: Integer;
    DirtyCB:    TGridDirtyCallback;
    // For sub-grid (nested) instances we set IsSubGrid so the
    // edit-on-Ctrl+S path doesn't re-fire the parent's dirty cb
    // twice.
    IsSubGrid:  Boolean;
  end;

// Initialize Common Controls once. Call before CreateGridWindow.
procedure EnsureCommonControlsLoaded;

// Create the grid (a ListView) as a child of ParentWnd. Takes ownership
// of Cols (a deep copy in spirit — caller frees its own copy if any).
// Rows is borrowed; the grid never frees it.
function CreateGridWindow(ParentWnd: HWND;
                          const Cols: TGridColumnArray;
                          Rows: TJSONArray;
                          DirtyCB: TGridDirtyCallback): HWND;

// Free per-grid state. Called from the Lister window cleanup path.
procedure DestroyGridState(GridWnd: HWND);

// Forward a WM_NOTIFY received by the grid's parent. Returns the
// LRESULT value the parent should reply with.
function GridHandleNotify(Hdr: PNMHdr): LRESULT;

// Search the grid's cells for the first occurrence of Needle starting
// at (StartRow, StartCol). Returns True on hit (and selects the row,
// scrolls into view, sets focus); StartRow/StartCol are then updated
// to the position immediately *after* the hit so the next call
// continues forward. Returns False if no hit; StartRow is reset to 0
// in that case.
function GridSearchText(GridWnd: HWND; const Needle: AnsiString;
                       MatchCase: Boolean;
                       var StartRow, StartCol: Integer): Boolean;

implementation

const
  WC_LISTVIEWA: PChar = 'SysListView32';
  CC_INITED: Boolean = False;

procedure EnsureCommonControlsLoaded;
var
  ICCEX: TInitCommonControlsEx;
begin
  if CC_INITED then Exit;
  ICCEX.dwSize := SizeOf(ICCEX);
  ICCEX.dwICC  := ICC_LISTVIEW_CLASSES;
  InitCommonControlsEx(ICCEX);
  CC_INITED := True;
end;

// ---------------------------------------------------------------------
//   State storage helpers
// ---------------------------------------------------------------------

function GetState(GridWnd: HWND): PGridState;
begin
  Result := PGridState(GetWindowLongPtr(GridWnd, GWLP_USERDATA));
end;

procedure SetState(GridWnd: HWND; St: PGridState);
begin
  SetWindowLongPtr(GridWnd, GWLP_USERDATA, LONG_PTR(St));
end;

// ---------------------------------------------------------------------
//   Edit overlay (popup Edit positioned over the cell being edited)
// ---------------------------------------------------------------------

procedure CommitEdit(GridWnd: HWND; State: PGridState); forward;
procedure CancelEdit(State: PGridState); forward;

// One-shot snapshot of the original EDIT WNDPROC. All overlay Edits
// share the same standard window class so this is the same value
// every time. We store it globally so OverlayEditProc has a valid
// fallback even after a grid's TGridState has been disposed (which
// happens during ListCloseWindow teardown — the Edit may receive
// WM_NCDESTROY *after* its parent's state is gone).
var
  GlobalOrigEditProc: LONG_PTR = 0;

// Subclassed proc on the overlay Edit. We capture Enter (commit) and
// Escape (cancel) and forward everything else to the original.
function OverlayEditProc(Wnd: HWND; Msg: UINT;
                         wParam: WPARAM; lParam: LPARAM): LRESULT; stdcall;
var
  Grid: HWND;
  St: PGridState;
  Fallback: LONG_PTR;
begin
  Grid := GetParent(Wnd);
  St := GetState(Grid);
  // The state may already be gone if we're being torn down. In that
  // case skip our intercept logic and just forward to the original
  // window proc — never touch St^.
  if St <> nil then
  begin
    case Msg of
      WM_KEYDOWN:
        case wParam of
          VK_RETURN:
            begin
              CommitEdit(Grid, St);
              Result := 0;
              Exit;
            end;
          VK_ESCAPE:
            begin
              CancelEdit(St);
              Result := 0;
              Exit;
            end;
        end;
      WM_CHAR:
        if (wParam = VK_RETURN) or (wParam = VK_ESCAPE) then
        begin
          // Swallow these so the Edit doesn't beep
          Result := 0;
          Exit;
        end;
      WM_KILLFOCUS:
        // If user clicked elsewhere, treat that as cancel (don't
        // silently commit — it's confusing).
        CancelEdit(St);
    end;
  end;
  // Pick a valid fallback: prefer the per-grid one (set when this
  // particular Edit was subclassed); fall back to the module global;
  // last resort is DefWindowProc.
  if (St <> nil) and (St^.OrigEditProc <> 0) then
    Fallback := St^.OrigEditProc
  else
    Fallback := GlobalOrigEditProc;
  if Fallback <> 0 then
    Result := CallWindowProc(WNDPROC(Fallback), Wnd, Msg, wParam, lParam)
  else
    Result := DefWindowProc(Wnd, Msg, wParam, lParam);
end;

procedure CancelEdit(State: PGridState);
begin
  if (State = nil) or (State^.EditWnd = 0) then Exit;
  ShowWindow(State^.EditWnd, SW_HIDE);
  State^.EditingRow := -1;
  State^.EditingCol := -1;
end;

procedure CommitEdit(GridWnd: HWND; State: PGridState);
var
  WBuf: array[0..1023] of WideChar;
  L: Integer;
  NewVal: AnsiString;
  W: WideString;
  Row: TJSONObject;
  OK: Boolean;
begin
  if (State = nil) or (State^.EditWnd = 0) then Exit;
  if (State^.EditingRow < 0) or (State^.EditingCol < 0) then Exit;

  // Read user-entered text as UTF-16, then encode back to UTF-8
  // for storage (TBL files are UTF-8; our model preserves byte
  // fidelity).
  L := SendMessageW(State^.EditWnd, WM_GETTEXT,
                    Length(WBuf), LPARAM(@WBuf[0]));
  if L < 0 then L := 0;
  SetString(W, PWideChar(@WBuf[0]), L);
  NewVal := UTF8Encode(W);

  Row := State^.Rows.Objects[State^.EditingRow];
  OK := SetCellText(Row, State^.Cols[State^.EditingCol], NewVal);
  if OK and Assigned(State^.DirtyCB) then
    State^.DirtyCB(GridWnd);

  ShowWindow(State^.EditWnd, SW_HIDE);
  State^.EditingRow := -1;
  State^.EditingCol := -1;

  // Force the listview to re-fetch the cell text now that we changed it
  ListView_RedrawItems(GridWnd, 0, State^.Rows.Count - 1);
  UpdateWindow(GridWnd);
end;

// Forward declarations.
procedure OpenSubGrid(ParentGrid: HWND; State: PGridState;
                      Row, Col: Integer); forward;

procedure BeginEdit(GridWnd: HWND; Row, Col: Integer; State: PGridState);
var
  R: TRect;
  CurText: AnsiString;
  ColumnKind: TColumnKind;
  Host: HWND;
begin
  if (State = nil) or (Row < 0) or (Col < 0) then Exit;
  if Col >= Length(State^.Cols) then Exit;
  if Row >= State^.Rows.Count then Exit;

  // Read-only check (skipped for sub-grids: those live in a popup
  // and are entered explicitly from a parent grid that already
  // passed the read-only check). For top-level grids, walk up to
  // the host window and ask the per-instance edit-mode flag.
  if not State^.IsSubGrid then
  begin
    Host := GetParent(GridWnd);   // grid -> tab host
    if not GetInstanceEditMode(Host) then
    begin
      MessageBeep(0);
      Exit;
    end;
  end;

  ColumnKind := State^.Cols[Col].Kind;

  // Nested summary: open a sub-grid dialog instead of inline editing.
  if ColumnKind = ckNestedSummary then
  begin
    OpenSubGrid(GridWnd, State, Row, Col);
    Exit;
  end;

  // Arrays are read-only in v1.
  if ColumnKind = ckArray then
  begin
    MessageBeep(0);
    Exit;
  end;

  // Scalar / string: floating Edit overlay
  R.Left := LVIR_BOUNDS;   // tells ListView_GetSubItemRect what we want
  R.Top  := Col;
  if not BOOL(SendMessage(GridWnd, LVM_GETSUBITEMRECT, WPARAM(Row), LPARAM(@R))) then
    Exit;

  // Resize the floating Edit to cover the cell
  MoveWindow(State^.EditWnd, R.Left, R.Top,
             R.Right - R.Left, R.Bottom - R.Top, True);
  ShowWindow(State^.EditWnd, SW_SHOW);

  // Pre-populate with the cell's current text (UTF-8 → UTF-16) and
  // select all
  CurText := GetCellText(State^.Rows.Objects[Row], State^.Cols[Col]);
  SendMessageW(State^.EditWnd, WM_SETTEXT, 0,
               LPARAM(PWideChar(UTF8Decode(CurText))));
  SendMessage(State^.EditWnd, EM_SETSEL, 0, -1);
  SetFocus(State^.EditWnd);

  State^.EditingRow := Row;
  State^.EditingCol := Col;
end;

// ---------------------------------------------------------------------
//   ListView event handling — virtual data + double-click
// ---------------------------------------------------------------------

// We attach a parent-wndproc subclass via a helper window (the host).
// Easier route: since the grid IS the ListView, we listen to its
// WM_NOTIFY through a parent. But ListViews send notifications to
// their PARENT, so we need the parent to forward them. We solve this
// at the host-window level (viewerwin.HostWndProc handles WM_NOTIFY
// on behalf of any contained grid). To keep that clean, the grid
// exposes a HandleNotify() entry point.
//
// For v1 we put a custom subclass on the ListView itself that picks
// up WM_LBUTTONDBLCLK and WM_KEYDOWN locally, since those don't need
// to flow through WM_NOTIFY.

var
  OrigGridWndProc: LONG_PTR = 0;
  // Cast the LVM_GETNEXTITEM "before first" sentinel once at module
  // init. Inline `WPARAM(-1)` triggers a const-expression error in
  // FPC 3.2 because WPARAM is QWord, but a typed-constant declared
  // here works (FPC treats it as a runtime value with module-init
  // semantics).
  LV_BEFORE_FIRST: WPARAM = WPARAM(-1);

function GridSubclassProc(Wnd: HWND; Msg: UINT;
                          wParam: WPARAM; lParam: LPARAM): LRESULT; stdcall;
var
  St: PGridState;
  HitInfo: TLVHitTestInfo;
  Pt: TPoint;
  Idx: Integer;
  SubItem: Integer;
  SelItem: Integer;
  Host: HWND;
begin
  St := GetState(Wnd);
  case Msg of
    WM_KEYDOWN:
      begin
        // Esc on a top-level grid closes the Lister window.
        // Sub-grids handle Esc themselves (they close their own
        // popup), so skip them here.
        if (wParam = VK_ESCAPE) and (St <> nil) and (not St^.IsSubGrid) then
        begin
          Host := GetParent(Wnd);
          PostMessage(GetParent(Host), WM_KEYDOWN, VK_ESCAPE, lParam);
          Result := 0;
          Exit;
        end;
        // F3 / F7 / Ctrl+F: forward to the Lister parent so TC opens
        // its standard Find dialog (which then routes through our
        // ListSearchText). Without this, the keystroke is consumed
        // by the grid's default handler and never reaches TC.
        // Sub-grids skip this so the popup isn't navigated away from.
        if (St <> nil) and (not St^.IsSubGrid) and
           ((wParam = VK_F3) or (wParam = VK_F7) or
            ((wParam = $46 {F}) and ((GetKeyState(VK_CONTROL) and $8000) <> 0))) then
        begin
          Host := GetParent(Wnd);
          PostMessage(GetParent(Host), WM_KEYDOWN, wParam, lParam);
          Result := 0;
          Exit;
        end;
        // F4 toggles edit/read-only mode. Forward up to the host so
        // tabwin can do the cross-cutting UI updates (window title,
        // JSON Edit ES_READONLY style, etc.). Sub-grids skip this so
        // the popup stays editable while open.
        if (wParam = VK_F4) and (St <> nil) and (not St^.IsSubGrid) then
        begin
          Host := GetParent(Wnd);
          SendMessage(Host, WM_USER + 0, 0, 0); // see TabHostWndProc
          Result := 0;
          Exit;
        end;
      end;
  end;
  case Msg of
    WM_LBUTTONDBLCLK:
      if St <> nil then
      begin
        Pt.X := SmallInt(LOWORD(lParam));
        Pt.Y := SmallInt(HIWORD(lParam));
        FillChar(HitInfo, SizeOf(HitInfo), 0);
        HitInfo.pt := Pt;
        Idx := SendMessage(Wnd, LVM_SUBITEMHITTEST,
                           0, Windows.LPARAM(@HitInfo));
        if Idx >= 0 then
        begin
          SubItem := HitInfo.iSubItem;
          BeginEdit(Wnd, Idx, SubItem, St);
          Result := 0;
          Exit;
        end;
      end;
    WM_KEYDOWN:
      if (St <> nil) and (wParam = VK_RETURN) then
      begin
        SelItem := SendMessage(Wnd, LVM_GETNEXTITEM,
                               LV_BEFORE_FIRST,
                               LVNI_SELECTED);
        if SelItem >= 0 then
        begin
          // No reliable way to know the "active subitem" without
          // tracking it ourselves. v1: open editor on column 0.
          BeginEdit(Wnd, SelItem, 0, St);
          Result := 0;
          Exit;
        end;
      end;
  end;
  Result := CallWindowProc(WNDPROC(OrigGridWndProc), Wnd, Msg, wParam, lParam);
end;

// ---------------------------------------------------------------------
//   Grid creation
// ---------------------------------------------------------------------

function CreateGridWindow(ParentWnd: HWND;
                          const Cols: TGridColumnArray;
                          Rows: TJSONArray;
                          DirtyCB: TGridDirtyCallback): HWND;
var
  Grid: HWND;
  RC: TRect;
  i: Integer;
  LVColW: TLVColumnW;
  HdrCaption: WideString;
  St: PGridState;
  ExStyle: DWORD;
begin
  EnsureCommonControlsLoaded;
  GetClientRect(ParentWnd, RC);
  Grid := CreateWindowEx(0, WC_LISTVIEWA, nil,
            WS_CHILD or WS_VISIBLE or WS_BORDER or WS_TABSTOP or
            LVS_REPORT or LVS_OWNERDATA or LVS_SHOWSELALWAYS,
            0, 0, RC.Right, RC.Bottom,
            ParentWnd, 0, HInstance, nil);
  if Grid = 0 then Exit(0);

  // Force the listview into Unicode mode so it sends LVN_GETDISPINFOW
  // (with WCHAR text buffer) instead of …A, and so column headers
  // accept UTF-16 strings. TBL files store UTF-8 strings (Falcom
  // convention); without this the bytes get interpreted as cp1250
  // and non-ASCII characters render as mojibake (e.g. "Dantès"
  // shows as "DantÃ¨s"). Common control message — value 1 = Unicode.
  SendMessage(Grid, CCM_SETUNICODEFORMAT, 1, 0);

  ExStyle := SendMessage(Grid, LVM_GETEXTENDEDLISTVIEWSTYLE, 0, 0);
  ExStyle := ExStyle or LVS_EX_FULLROWSELECT or LVS_EX_GRIDLINES or
             LVS_EX_HEADERDRAGDROP;
  SendMessage(Grid, LVM_SETEXTENDEDLISTVIEWSTYLE, 0, ExStyle);

  // Add columns. DisplayName is AnsiString that may carry UTF-8
  // bytes (schemas can contain non-ASCII). Convert to UTF-16 first.
  for i := 0 to High(Cols) do
  begin
    HdrCaption := UTF8Decode(Cols[i].DisplayName);
    FillChar(LVColW, SizeOf(LVColW), 0);
    LVColW.mask := LVCF_TEXT or LVCF_WIDTH or LVCF_SUBITEM;
    LVColW.cx   := Cols[i].Width;
    LVColW.iSubItem := i;
    LVColW.pszText := PWideChar(HdrCaption);
    SendMessageW(Grid, LVM_INSERTCOLUMNW, WPARAM(i), LPARAM(@LVColW));
  end;

  // Tell the listview how many virtual rows to expect
  if Rows <> nil then
    SendMessage(Grid, LVM_SETITEMCOUNT, WPARAM(Rows.Count), 0);

  // Attach state
  New(St);
  FillChar(St^, SizeOf(St^), 0);
  St^.Cols := Cols;
  St^.Rows := Rows;
  St^.EditingRow := -1;
  St^.EditingCol := -1;
  St^.DirtyCB := DirtyCB;
  SetState(Grid, St);

  // Create the floating Edit overlay (initially hidden) in Unicode
  // mode so we can SetWindowText with UTF-16 / GetWindowText back
  // to UTF-16 — needed because cell text is UTF-8 and a plain ANSI
  // Edit would mangle non-ASCII characters during edit.
  St^.EditWnd := CreateWindowExW(0, 'EDIT', nil,
                                 WS_CHILD or ES_AUTOHSCROLL,
                                 0, 0, 100, 20,
                                 Grid, 0, HInstance, nil);
  if St^.EditWnd <> 0 then
  begin
    St^.OrigEditProc := GetWindowLongPtr(St^.EditWnd, GWLP_WNDPROC);
    if GlobalOrigEditProc = 0 then
      GlobalOrigEditProc := St^.OrigEditProc;
    SetWindowLongPtr(St^.EditWnd, GWLP_WNDPROC, LONG_PTR(@OverlayEditProc));
  end;

  // Subclass the ListView itself (one global proc reused per instance)
  if OrigGridWndProc = 0 then
    OrigGridWndProc := GetWindowLongPtr(Grid, GWLP_WNDPROC);
  SetWindowLongPtr(Grid, GWLP_WNDPROC, LONG_PTR(@GridSubclassProc));

  Result := Grid;
end;

procedure DestroyGridState(GridWnd: HWND);
var St: PGridState;
begin
  St := GetState(GridWnd);
  if St = nil then Exit;
  // Detach state from the window first — any subclass procs that
  // fire on subsequent teardown messages will then see St=nil and
  // route straight to the fallback, never dereferencing freed state.
  SetState(GridWnd, nil);
  // Unsubclass the overlay Edit before any further messages can
  // arrive on it. (The Edit will be destroyed by Windows as a child
  // of the grid; we just don't want our subclass on the road.)
  if (St^.EditWnd <> 0) and (St^.OrigEditProc <> 0) then
  begin
    SetWindowLongPtr(St^.EditWnd, GWLP_WNDPROC, St^.OrigEditProc);
    St^.OrigEditProc := 0;
  end;
  // Explicitly drop refs on managed-type fields. New(St) initialized
  // them; we re-zero so Dispose's Finalize sees a clean slate even if
  // the same dyn-array data is still referenced elsewhere (e.g. by
  // the parent tab entry's Cols copy).
  St^.Cols := nil;
  St^.Rows := nil;
  Dispose(St);
end;

// ---------------------------------------------------------------------
//   Notification handler — called by the host when WM_NOTIFY arrives
// ---------------------------------------------------------------------
//
// Virtual ListViews ask the parent for cell text via LVN_GETDISPINFO.
// Without this, every cell would be blank. The host window is the
// LV's parent, so it gets the WM_NOTIFY and forwards to us.
//
// We use a global helper (resolves the grid by hwndFrom).

function GridHandleNotify(Hdr: PNMHdr): LRESULT;
var
  DIW: LPNMLVDISPINFOW;
  DIA: LPNMLVDISPINFOA;
  St: PGridState;
  S: AnsiString;
  W: WideString;
  CopyLen: Integer;
begin
  Result := 0;
  if Hdr = nil then Exit;
  // Unicode (preferred path — we put the listview into Unicode mode
  // via CCM_SETUNICODEFORMAT, so this is what we actually receive).
  if Hdr^.code = LongWord(LVN_GETDISPINFOW) then
  begin
    DIW := LPNMLVDISPINFOW(Hdr);
    St := GetState(Hdr^.hwndFrom);
    if (St = nil) or (St^.Rows = nil) then Exit;
    if (DIW^.item.mask and LVIF_TEXT) <> 0 then
    begin
      if (DIW^.item.iItem >= 0) and
         (DIW^.item.iItem < St^.Rows.Count) and
         (DIW^.item.iSubItem >= 0) and
         (DIW^.item.iSubItem < Length(St^.Cols)) then
      begin
        // GetCellText returns UTF-8 bytes (RawByteString in our
        // model). Decode to UTF-16 for display.
        S := GetCellText(St^.Rows.Objects[DIW^.item.iItem],
                         St^.Cols[DIW^.item.iSubItem]);
        W := UTF8Decode(S);
        // pszText is a WCHAR buffer of cchTextMax WCHARs provided
        // by the control. Copy at most cchTextMax-1 chars + NUL.
        CopyLen := Length(W);
        if CopyLen >= DIW^.item.cchTextMax then
          CopyLen := DIW^.item.cchTextMax - 1;
        if CopyLen < 0 then CopyLen := 0;
        if CopyLen > 0 then
          Move(W[1], DIW^.item.pszText^, CopyLen * SizeOf(WideChar));
        DIW^.item.pszText[CopyLen] := WideChar(#0);
      end;
    end;
  end
  // ANSI fallback path — kept in case some older common-controls
  // version still sends A notifications even after CCM_SETUNICODEFORMAT.
  // We at least send the raw bytes; cp1250 chars will display, the
  // rest will mojibake.
  else if Hdr^.code = LongWord(LVN_GETDISPINFOA) then
  begin
    DIA := LPNMLVDISPINFOA(Hdr);
    St := GetState(Hdr^.hwndFrom);
    if (St = nil) or (St^.Rows = nil) then Exit;
    if (DIA^.item.mask and LVIF_TEXT) <> 0 then
    begin
      if (DIA^.item.iItem >= 0) and
         (DIA^.item.iItem < St^.Rows.Count) and
         (DIA^.item.iSubItem >= 0) and
         (DIA^.item.iSubItem < Length(St^.Cols)) then
      begin
        S := GetCellText(St^.Rows.Objects[DIA^.item.iItem],
                         St^.Cols[DIA^.item.iSubItem]);
        if Length(S) >= DIA^.item.cchTextMax then
          SetLength(S, DIA^.item.cchTextMax - 1);
        if Length(S) > 0 then
          Move(S[1], DIA^.item.pszText^, Length(S));
        DIA^.item.pszText[Length(S)] := #0;
      end;
    end;
  end;
end;

// ---------------------------------------------------------------------
//   Sub-grid dialog (for nested-summary cells)
// ---------------------------------------------------------------------
//
// We use the lowest-fuss modal route: create a top-level overlapped
// window with WS_POPUP|WS_CAPTION|WS_SYSMENU style, run a local
// message loop until the user closes it, then destroy. Inside the
// popup we embed a regular grid (same TGridState wiring as the
// parent grid) bound to the nested array.
//
// Edits inside the sub-grid happen against the live JSON nested
// array, so by the time the popup is dismissed the parent grid
// already reflects them via GetCellText. We just call the parent's
// dirty callback to mark the file modified.

const
  TBL_SUBGRID_CLASS_NAME : PChar = 'TBLLister.SubGridV1';

var
  SubGridClassRegistered: Boolean = False;

function SubGridWndProc(Wnd: HWND; Msg: UINT;
                        wParam: WPARAM; lParam: LPARAM): LRESULT; stdcall;
var
  Child: HWND;
  W, H: Integer;
begin
  case Msg of
    WM_SIZE:
      begin
        Child := GetWindow(Wnd, GW_CHILD);
        if Child <> 0 then
        begin
          W := LOWORD(lParam);
          H := HIWORD(lParam);
          MoveWindow(Child, 0, 0, W, H, True);
        end;
        Result := 0;
        Exit;
      end;
    WM_CLOSE:
      begin
        // Posting WM_QUIT breaks our nested message loop below
        PostMessage(Wnd, WM_USER + 1, 0, 0);
        Result := 0;
        Exit;
      end;
    WM_NOTIFY:
      // Forward to grid notify handler so virtual-list dispinfo
      // requests get answered for the embedded sub-grid.
      begin
        Result := GridHandleNotify(PNMHdr(lParam));
        Exit;
      end;
  end;
  Result := DefWindowProc(Wnd, Msg, wParam, lParam);
end;

procedure EnsureSubGridClassRegistered;
var WC: WNDCLASSA;
begin
  if SubGridClassRegistered then Exit;
  FillChar(WC, SizeOf(WC), 0);
  WC.style         := CS_HREDRAW or CS_VREDRAW;
  WC.lpfnWndProc   := @SubGridWndProc;
  WC.hInstance     := HInstance;
  WC.hCursor       := LoadCursor(0, IDC_ARROW);
  WC.hbrBackground := HBRUSH(COLOR_BTNFACE + 1);
  WC.lpszClassName := TBL_SUBGRID_CLASS_NAME;
  Windows.RegisterClassA(WC);
  SubGridClassRegistered := True;
end;

procedure OpenSubGrid(ParentGrid: HWND; State: PGridState;
                      Row, Col: Integer);
var
  PopupWnd, SubGrid: HWND;
  ParentRow: TJSONObject;
  NestedArr: TJSONArray;
  SubCols: TGridColumnArray;
  Inner: TFieldList;
  PopupTitle: AnsiString;
  Msg: TMSG;
  Done: Boolean;
  Rc: TRect;
begin
  ParentRow := State^.Rows.Objects[Row];
  NestedArr := GetNestedArray(ParentRow, State^.Cols[Col]);
  if NestedArr = nil then
  begin
    MessageBeep(0);
    Exit;
  end;
  Inner := TFieldList(State^.Cols[Col].NestedFT.NestedFields);
  if Inner = nil then Exit;
  SubCols := BuildNestedColumns(Inner);

  EnsureSubGridClassRegistered;

  PopupTitle := Format('%s — row %d (%d nested rows)',
                       [State^.Cols[Col].DisplayName, Row, NestedArr.Count]);
  // Center the popup on the parent's screen position
  GetWindowRect(ParentGrid, Rc);
  PopupWnd := CreateWindowEx(WS_EX_DLGMODALFRAME,
                             TBL_SUBGRID_CLASS_NAME,
                             PAnsiChar(PopupTitle),
                             WS_POPUP or WS_CAPTION or WS_SYSMENU or
                             WS_THICKFRAME or WS_VISIBLE,
                             Rc.Left + 50, Rc.Top + 50, 700, 400,
                             ParentGrid, 0, HInstance, nil);
  if PopupWnd = 0 then
  begin
    MessageBeep(0);
    Exit;
  end;

  // Create the sub-grid inside the popup. We pass the parent's
  // dirty callback so edits in the sub-grid still mark the file
  // dirty, but flag the state so we don't double-fire.
  SubGrid := CreateGridWindow(PopupWnd, SubCols, NestedArr,
                              State^.DirtyCB);
  if SubGrid <> 0 then
    PGridState(GetWindowLongPtr(SubGrid, GWLP_USERDATA))^.IsSubGrid := True;

  // Disable the parent so this is effectively modal.
  EnableWindow(GetParent(ParentGrid), False);

  // Run a local modal-ish message loop until our WM_USER+1 close
  // signal. We dispatch all messages so child windows still work,
  // but bail when the sentinel arrives.
  Done := False;
  while not Done do
  begin
    if not GetMessage(@Msg, 0, 0, 0) then Break;
    if (Msg.hwnd = PopupWnd) and (Msg.message = WM_USER + 1) then
    begin
      Done := True;
      Break;
    end;
    if not IsDialogMessage(PopupWnd, @Msg) then
    begin
      TranslateMessage(@Msg);
      DispatchMessage(@Msg);
    end;
  end;

  // Re-enable parent and clean up
  EnableWindow(GetParent(ParentGrid), True);
  if SubGrid <> 0 then DestroyGridState(SubGrid);
  DestroyWindow(PopupWnd);

  // Refresh the parent row's summary cell since the count may have
  // changed (it didn't in v1 — only values change — but redraw
  // anyway so a value-derived summary like text-preview would update).
  ListView_RedrawItems(ParentGrid, Row, Row);
  UpdateWindow(ParentGrid);
end;

// ---------------------------------------------------------------------
//   Grid cell search
// ---------------------------------------------------------------------

function GridSearchText(GridWnd: HWND; const Needle: AnsiString;
                       MatchCase: Boolean;
                       var StartRow, StartCol: Integer): Boolean;
var
  St: PGridState;
  RowCount, ColCount, Row, Col: Integer;
  RowObj: TJSONObject;
  Cell, Hay, Pin: AnsiString;
  RowItem: TJSONData;
  LV_Item: TLVItem;
begin
  Result := False;
  St := GetState(GridWnd);
  if (St = nil) or (St^.Rows = nil) or (Length(St^.Cols) = 0)
     or (Needle = '') then Exit;

  RowCount := St^.Rows.Count;
  ColCount := Length(St^.Cols);
  if RowCount = 0 then Exit;

  // Clamp start position
  if StartRow < 0 then StartRow := 0;
  if StartCol < 0 then StartCol := 0;
  if StartRow >= RowCount then StartRow := 0;
  if StartCol >= ColCount then StartCol := 0;

  // Case-insensitive: lowercase the needle once.
  if MatchCase then
    Pin := Needle
  else
    Pin := LowerCase(Needle);

  Row := StartRow;
  Col := StartCol;
  while Row < RowCount do
  begin
    RowItem := St^.Rows.Items[Row];
    if (RowItem <> nil) and (RowItem is TJSONObject) then
    begin
      RowObj := TJSONObject(RowItem);
      while Col < ColCount do
      begin
        Cell := GetCellText(RowObj, St^.Cols[Col]);
        if MatchCase then
          Hay := Cell
        else
          Hay := LowerCase(Cell);
        if Pos(Pin, Hay) > 0 then
        begin
          // Found. Select the row + scroll into view.
          FillChar(LV_Item, SizeOf(LV_Item), 0);
          LV_Item.mask     := LVIF_STATE;
          LV_Item.stateMask := LVIS_SELECTED or LVIS_FOCUSED;
          LV_Item.state    := LVIS_SELECTED or LVIS_FOCUSED;
          // Clear other selections first
          ListView_SetItemState(GridWnd, -1, 0,
                                LVIS_SELECTED or LVIS_FOCUSED);
          ListView_SetItemState(GridWnd, Row,
                                LVIS_SELECTED or LVIS_FOCUSED,
                                LVIS_SELECTED or LVIS_FOCUSED);
          ListView_EnsureVisible(GridWnd, Row, False);
          // Force a full repaint so the LVS_OWNERDATA cache re-queries
          // every visible cell. Without this, when search switched
          // tabs and the grid was hidden during SetItemState, only
          // the focused row paints and the rest stays blank until
          // the user manually scrolls or clicks.
          InvalidateRect(GridWnd, nil, True);
          UpdateWindow(GridWnd);
          SetFocus(GridWnd);

          // Continue from the cell *after* this hit on next call
          StartRow := Row;
          StartCol := Col + 1;
          if StartCol >= ColCount then
          begin
            StartCol := 0;
            Inc(StartRow);
          end;
          Result := True;
          Exit;
        end;
        Inc(Col);
      end;
    end;
    Col := 0;
    Inc(Row);
  end;
  // Wrap-around exhausted the search space
  StartRow := 0;
  StartCol := 0;
end;

end.
