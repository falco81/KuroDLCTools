unit viewerwin;
{$mode objfpc}{$H+}

// Win32 child window that hosts a read-only multi-line edit control
// displaying the formatted JSON view of an opened TBL file.
//
// We use a plain "EDIT" control — RichEdit would give nicer syntax
// highlighting but pulls in riched20.dll and complicates SearchText.
// A monospaced read-only Edit handles big files (1+ MB) acceptably
// well for the v1 plugin and keeps the DLL minimal.
//
// Two windows are involved:
//   HostWnd: a custom WS_CHILD window we create as a child of the
//            Lister parent. Lister sizes/positions this for us.
//   EditWnd: a child of HostWnd, sized to fill it. Holds the JSON
//            text. Receives keyboard focus.
//
// HostWnd is what we return from ListLoad. Lister will call
// MoveWindow on it when the Lister window is resized.

interface

uses Windows, Messages, SysUtils, StrUtils, Classes;

type
  // Callback fired when the user presses Ctrl+S in the Edit control.
  // Wnd is the Host window's HWND (= the key into pluginstate).
  TSaveCallback = procedure(Wnd: HWND);

const
  TBL_HOST_CLASS_NAME : PChar = 'TBLLister.HostV1';

// Register the host window class. Called once before the first
// CreateViewerWindow.
procedure EnsureHostClassRegistered;

// Install the global save callback. Called once at plugin init.
procedure SetSaveCallback(CB: TSaveCallback);

// Create the host window + its child Edit control. ParentWnd is
// the HWND TC passes us in ListLoad. Returns the host HWND and
// (out param) the Edit child HWND.
function CreateViewerWindow(ParentWnd: HWND;
                            out EditWnd: HWND): HWND;

// Set the displayed text. Called after ListLoad has finished
// parsing the TBL and built a JSON string.
procedure SetViewerText(EditWnd: HWND; const Text: AnsiString);

// Read back the current text from the Edit control. Used by the
// host on Ctrl+S to get the (possibly user-edited) JSON.
function GetViewerText(EditWnd: HWND): AnsiString;

// Mark/unmark the Edit's "dirty" flag.
procedure SetViewerDirty(EditWnd: HWND; Dirty: Boolean);
function  GetViewerDirty(EditWnd: HWND): Boolean;

// Search for a substring in the displayed text starting from the
// previous match (or 0 on FindFirst). Returns the position on
// success, -1 on miss. Selects+scrolls to the match on hit.
function ViewerFind(EditWnd: HWND; const Needle: AnsiString;
                    var FromPos: Integer; MatchCase: Boolean;
                    Backwards: Boolean): Boolean;

// Select-all (Ctrl+A from Lister).
procedure ViewerSelectAll(EditWnd: HWND);

implementation

var
  HostClassRegistered: Boolean = False;
  SaveCB: TSaveCallback = nil;
  // Original window proc of the Edit control we subclassed. We share
  // a single value because Edit instances created by us all behave
  // the same; if the OS ever returns a different proc per instance
  // this would need to be per-Edit.
  OrigEditWndProc: LONG_PTR = 0;

procedure SetSaveCallback(CB: TSaveCallback);
begin
  SaveCB := CB;
end;

// Subclassed Edit window proc. We peek at WM_KEYDOWN/WM_CHAR for the
// Ctrl+S accelerator and forward everything else to the original.
function EditSubclassProc(Wnd: HWND; Msg: UINT;
                          wParam: WPARAM; lParam: LPARAM): LRESULT; stdcall;
var
  Host: HWND;
begin
  case Msg of
    WM_KEYDOWN:
      // wParam is the virtual-key. 'S' = $53. GetKeyState test for
      // Ctrl: high bit set means pressed.
      if (wParam = $53 {S}) and ((GetKeyState(VK_CONTROL) and $8000) <> 0) then
      begin
        if Assigned(SaveCB) then
        begin
          Host := GetParent(Wnd);
          SaveCB(Host);
        end;
        Result := 0;
        Exit;
      end;
    WM_CHAR:
      // Some Edit controls also raise WM_CHAR for the same Ctrl+S
      // (it produces ASCII 0x13 = DC3). Swallow that to prevent the
      // Edit from beeping.
      if wParam = $13 then
      begin
        Result := 0;
        Exit;
      end;
  end;
  Result := CallWindowProc(WNDPROC(OrigEditWndProc), Wnd, Msg, wParam, lParam);
end;

function HostWndProc(Wnd: HWND; Msg: UINT; wParam: WPARAM; lParam: LPARAM): LRESULT; stdcall;
var
  Edit: HWND;
  W, H: Integer;
begin
  case Msg of
    WM_SIZE:
      begin
        // Forward our size to the child Edit so it always fills us.
        Edit := GetWindow(Wnd, GW_CHILD);
        if Edit <> 0 then
        begin
          W := LOWORD(lParam);
          H := HIWORD(lParam);
          MoveWindow(Edit, 0, 0, W, H, True);
        end;
        Result := 0;
        Exit;
      end;
    WM_SETFOCUS:
      begin
        Edit := GetWindow(Wnd, GW_CHILD);
        if Edit <> 0 then SetFocus(Edit);
        Result := 0;
        Exit;
      end;
    WM_DESTROY:
      begin
        // The child Edit gets destroyed automatically by Windows.
        Result := 0;
        Exit;
      end;
  end;
  Result := DefWindowProc(Wnd, Msg, wParam, lParam);
end;

procedure EnsureHostClassRegistered;
var
  WC: Windows.WNDCLASSA;
begin
  if HostClassRegistered then Exit;
  FillChar(WC, SizeOf(WC), 0);
  WC.style         := CS_HREDRAW or CS_VREDRAW;
  WC.lpfnWndProc   := @HostWndProc;
  WC.hInstance     := HInstance;
  WC.hCursor       := LoadCursor(0, IDC_ARROW);
  WC.hbrBackground := HBRUSH(COLOR_BTNFACE + 1);
  WC.lpszClassName := TBL_HOST_CLASS_NAME;
  Windows.RegisterClassA(WC);
  HostClassRegistered := True;
end;

function CreateViewerWindow(ParentWnd: HWND;
                            out EditWnd: HWND): HWND;
const
  // The Edit control is fully editable. Ctrl+S is intercepted by the
  // plugin's host window proc (see HostWndProc → WM_CHAR / WM_KEYDOWN
  // forwarded by Lister via WM_KEYDOWN to the focused child) so we
  // need WS_EX_CONTROLPARENT-style key forwarding to work — that
  // happens automatically because the Edit is a child of our Host
  // window, and our Host is a child of TC's Lister window.
  ES_STYLES = ES_MULTILINE or ES_AUTOVSCROLL or ES_AUTOHSCROLL or
              ES_NOHIDESEL or ES_WANTRETURN;
  WS_STYLES = WS_CHILD or WS_VISIBLE or WS_VSCROLL or WS_HSCROLL or
              WS_BORDER or WS_TABSTOP;
var
  Host: HWND;
  RC: TRect;
  ViewerFont: HFONT;
  LF: TLogFont;
begin
  EnsureHostClassRegistered;
  GetClientRect(ParentWnd, RC);
  Host := CreateWindowEx(0, TBL_HOST_CLASS_NAME, nil,
                         WS_CHILD or WS_VISIBLE,
                         0, 0, RC.Right, RC.Bottom,
                         ParentWnd, 0, HInstance, nil);
  if Host = 0 then
  begin
    EditWnd := 0;
    Exit(0);
  end;

  EditWnd := CreateWindowEx(0, 'EDIT', nil,
                            ES_STYLES or WS_STYLES,
                            0, 0, RC.Right, RC.Bottom,
                            Host, 0, HInstance, nil);
  if EditWnd = 0 then
  begin
    DestroyWindow(Host);
    Exit(0);
  end;

  // Subclass the Edit's WndProc once so we can intercept Ctrl+S.
  // We assume all Edit instances created by USER32 share the same
  // class proc — this is true on every Windows version we support.
  if OrigEditWndProc = 0 then
    OrigEditWndProc := GetWindowLongPtr(EditWnd, GWLP_WNDPROC);
  SetWindowLongPtr(EditWnd, GWLP_WNDPROC, LONG_PTR(@EditSubclassProc));

  // Use a fixed-pitch font (Consolas if available, falling back
  // to Courier New). 10pt at 96 DPI is fine for general use.
  FillChar(LF, SizeOf(LF), 0);
  LF.lfHeight := -13;       // ~10pt @ 96dpi
  LF.lfWeight := FW_NORMAL;
  LF.lfCharSet := DEFAULT_CHARSET;
  LF.lfPitchAndFamily := FIXED_PITCH or FF_MODERN;
  StrPCopy(LF.lfFaceName, 'Consolas');
  ViewerFont := CreateFontIndirect(LF);
  if ViewerFont = 0 then
  begin
    StrPCopy(LF.lfFaceName, 'Courier New');
    ViewerFont := CreateFontIndirect(LF);
  end;
  if ViewerFont <> 0 then
    SendMessage(EditWnd, WM_SETFONT, WPARAM(ViewerFont), 1);

  // Lister will MoveWindow our Host into place after ListLoad returns.
  Result := Host;
end;

procedure SetViewerText(EditWnd: HWND; const Text: AnsiString);
var
  P: PAnsiChar;
  Buf: AnsiString;
begin
  if EditWnd = 0 then Exit;
  // Edit control wants CRLF line endings on Windows. JSON FormatJSON
  // outputs LF only, so we convert.
  Buf := StringReplace(Text, #10, #13#10, [rfReplaceAll]);
  // Avoid double-CRLF if any LFs were already preceded by CR
  Buf := StringReplace(Buf, #13#13#10, #13#10, [rfReplaceAll]);
  P := PAnsiChar(Buf);
  SendMessageA(EditWnd, WM_SETTEXT, 0, LPARAM(P));
  // Move caret to start, clear modify flag (programmatic set ≠ user edit)
  SendMessage(EditWnd, EM_SETSEL, 0, 0);
  SendMessage(EditWnd, EM_SETMODIFY, 0, 0);
end;

function GetViewerText(EditWnd: HWND): AnsiString;
var
  Len: Integer;
  Buf: AnsiString;
begin
  Result := '';
  if EditWnd = 0 then Exit;
  Len := SendMessage(EditWnd, WM_GETTEXTLENGTH, 0, 0);
  if Len <= 0 then Exit;
  SetLength(Buf, Len);
  // WM_GETTEXT counts the null terminator in its char-count argument
  SendMessageA(EditWnd, WM_GETTEXT, WPARAM(Len + 1), LPARAM(PAnsiChar(Buf)));
  // Strip CRLF back to LF — JSON parser is happy with either, but our
  // round-trip prefers the canonical LF form for byte-stable output.
  Result := StringReplace(Buf, #13#10, #10, [rfReplaceAll]);
end;

procedure SetViewerDirty(EditWnd: HWND; Dirty: Boolean);
begin
  if EditWnd = 0 then Exit;
  if Dirty then
    SendMessage(EditWnd, EM_SETMODIFY, 1, 0)
  else
    SendMessage(EditWnd, EM_SETMODIFY, 0, 0);
end;

function GetViewerDirty(EditWnd: HWND): Boolean;
begin
  if EditWnd = 0 then Exit(False);
  Result := SendMessage(EditWnd, EM_GETMODIFY, 0, 0) <> 0;
end;

function ViewerFind(EditWnd: HWND; const Needle: AnsiString;
                    var FromPos: Integer; MatchCase: Boolean;
                    Backwards: Boolean): Boolean;
var
  Len, FoundPos: Integer;
  Buf: AnsiString;
  Hay, Pin: AnsiString;
begin
  Result := False;
  if (EditWnd = 0) or (Length(Needle) = 0) then Exit;
  Len := SendMessage(EditWnd, WM_GETTEXTLENGTH, 0, 0);
  if Len <= 0 then Exit;
  SetLength(Buf, Len);
  SendMessageA(EditWnd, WM_GETTEXT, WPARAM(Len + 1), LPARAM(PAnsiChar(Buf)));
  if MatchCase then
  begin
    Hay := Buf;
    Pin := Needle;
  end
  else
  begin
    Hay := AnsiLowerCase(Buf);
    Pin := AnsiLowerCase(Needle);
  end;
  if Backwards then
  begin
    // Pas: search backward from FromPos. Use RPos-like manual loop.
    if FromPos > Length(Hay) then FromPos := Length(Hay);
    if FromPos < 1 then Exit;
    FoundPos := 0;
    while FromPos > 0 do
    begin
      if Copy(Hay, FromPos, Length(Pin)) = Pin then
      begin
        FoundPos := FromPos;
        Break;
      end;
      Dec(FromPos);
    end;
    if FoundPos = 0 then Exit;
  end
  else
  begin
    if FromPos < 1 then FromPos := 1;
    FoundPos := PosEx(Pin, Hay, FromPos);
    if FoundPos = 0 then Exit;
  end;
  // Select the match and scroll to it
  SendMessage(EditWnd, EM_SETSEL,
              WPARAM(FoundPos - 1),
              LPARAM(FoundPos - 1 + Length(Needle)));
  SendMessage(EditWnd, EM_SCROLLCARET, 0, 0);
  FromPos := FoundPos + Length(Needle);
  Result := True;
end;

procedure ViewerSelectAll(EditWnd: HWND);
begin
  if EditWnd = 0 then Exit;
  SendMessage(EditWnd, EM_SETSEL, 0, -1);
end;

end.
