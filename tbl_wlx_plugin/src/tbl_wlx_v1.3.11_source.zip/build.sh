#!/bin/bash
# =====================================================================
#   build.sh — Cross-compile the TBL Lister plugin (Linux → Win64 DLL)
#
# Requires:
#   - Free Pascal Compiler 3.2.x with x86_64-win64 cross-compile target
#       Debian/Ubuntu:  apt install fpc fp-units-fcl fp-compiler-source
#       AlmaLinux:      see BUILD.md (no fpc package — install from
#                       freepascal.org or build from source)
#   - MinGW-w64 GCC (for ZSTD object compilation)
#       Debian/Ubuntu:  apt install gcc-mingw-w64-x86-64
#       AlmaLinux:      yum install mingw64-gcc
#   - FPC source tree (for fcl-base / fcl-json units)
#       Debian/Ubuntu:  /usr/share/fpcsrc/<version>/  (from
#                       fp-compiler-source package)
#       Other:          set FPCSRC env var to your fpc source root
#
# Output: tbl_wlx.wlx64 in this directory (also copied next to schemas)
# =====================================================================

set -e
cd "$(dirname "$0")"

# --- Configuration ---
FPC="${FPC:-fpc}"
CC="${CC:-x86_64-w64-mingw32-gcc}"

# Locate FPC source for cross-build of units
if [ -z "${FPCSRC:-}" ]; then
  for d in /usr/share/fpcsrc/3.2.2 /usr/share/fpcsrc/3.2.0 \
           /usr/share/fpcsrc/3.2.4 /usr/share/fpcsrc/*; do
    if [ -d "$d/packages" ]; then FPCSRC="$d"; break; fi
  done
fi
if [ -z "${FPCSRC:-}" ] || [ ! -d "$FPCSRC/packages" ]; then
  echo "error: FPC source tree not found. Install fp-compiler-source"
  echo "       (Debian/Ubuntu) or set FPCSRC env var manually:"
  echo "         export FPCSRC=/path/to/fpcsrc"
  echo "         ./build.sh"
  exit 1
fi
echo "Using FPC source at: $FPCSRC"

# Check tools
command -v "$FPC" >/dev/null 2>&1 || { echo "error: $FPC not found"; exit 1; }
command -v "$CC" >/dev/null 2>&1 || { echo "error: $CC not found (install gcc-mingw-w64-x86-64)"; exit 1; }

# --- Bootstrap Win64 fcl-base/fcl-json units ---
WIN64_UNITS="${WIN64_UNITS:-./win64_units}"
mkdir -p "$WIN64_UNITS"

NEED_REBUILD=0
for u in contnrs jsonscanner fpjson jsonreader jsonparser; do
  if [ ! -f "$WIN64_UNITS/${u}.ppu" ]; then NEED_REBUILD=1; fi
done

if [ "$NEED_REBUILD" = "1" ]; then
  echo
  echo "=== [1/4] Bootstrapping Win64 fcl-base / fcl-json units ==="
  echo "    (one-time; output: $WIN64_UNITS/*.ppu)"

  # fcl-base: contnrs.pp — output goes into WIN64_UNITS via -FU
  "$FPC" -O2 -Sh -Twin64 \
       -FU"$WIN64_UNITS" \
       -Fi"$FPCSRC/packages/fcl-base/inc" \
       "$FPCSRC/packages/fcl-base/src/contnrs.pp"

  # fcl-json: scanner first (no deps), then fpjson + reader + parser
  # which depend on contnrs (already in WIN64_UNITS).
  for u in jsonscanner fpjson jsonreader jsonparser; do
    "$FPC" -O2 -Sh -Twin64 \
         -FU"$WIN64_UNITS" \
         -Fu"$WIN64_UNITS" \
         -Fi"$FPCSRC/packages/fcl-json/src" \
         "$FPCSRC/packages/fcl-json/src/${u}.pp"
  done
  echo "    OK"
fi

# --- Build ZSTD objects ---
echo
echo "=== [2/4] Cross-compiling ZSTD reference C implementation ==="
echo "    Win64 (for the DLL):"
"$CC" -c -O2 -fno-stack-protector -DZSTDLIB_VISIBILITY= -DZSTD_DISABLE_ASM \
      -o src/zstdobj_win64.o src/zstd/zstddeclib.c

# A Linux ELF version is needed if the user wants to run the smoke
# tests via run-tests.sh. Cheap to build, so always make both.
if command -v gcc >/dev/null 2>&1; then
  echo "    Linux ELF (for run-tests.sh):"
  gcc -c -O2 -fno-stack-protector -DZSTDLIB_VISIBILITY= -DZSTD_DISABLE_ASM \
      -o src/zstdobj.o src/zstd/zstddeclib.c
fi

# --- Build DLL ---
echo
echo "=== [3/4] Cross-compiling Pascal plugin to Win64 ==="
cd src
"$FPC" -O2 -Sh -Twin64 -Fu"../$WIN64_UNITS" tbl_wlx.pas -otbl_wlx.wlx64
cd ..

if [ ! -f src/tbl_wlx.wlx64 ]; then
  echo "error: src/tbl_wlx.wlx64 was not produced"
  exit 1
fi
mv src/tbl_wlx.wlx64 tbl_wlx.wlx64

# --- Layout for distribution ---
echo
echo "=== [4/4] Layout ==="
echo "  tbl_wlx.wlx64      $(ls -la tbl_wlx.wlx64 | awk '{print $5}') bytes"
if command -v file >/dev/null; then
  file tbl_wlx.wlx64
fi
if [ -d schemas ]; then
  echo "  schemas/           $(find schemas -name '*.json' | wc -l) JSONs"
fi
if [ -f pluginst.inf ]; then
  echo "  pluginst.inf       (TC plugin installer manifest)"
fi

# --- Cleanup intermediate files ---
# Keep src/zstdobj.o (Linux ELF) — run-tests.sh needs it.
# Drop everything else.
rm -f src/*.ppu src/zstdobj_win64.o
find src -maxdepth 1 -name "*.o" ! -name "zstdobj.o" -delete 2>/dev/null || true
rm -f *.ppu
find . -maxdepth 1 -name "*.o" -delete 2>/dev/null || true

echo
echo "=== Done. ==="
echo
echo "Smoke test? Run ./run-tests.sh"
echo "Distribute? zip -r tbl_wlx_plugin.zip tbl_wlx.wlx64 schemas pluginst.inf README.md"
