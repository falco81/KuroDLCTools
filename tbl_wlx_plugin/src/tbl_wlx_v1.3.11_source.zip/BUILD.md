# How to build the TBL Lister Plugin from source

The plugin is written in Free Pascal and statically links the ZSTD
reference C implementation. So compilation needs **two tools**:

1. **Free Pascal Compiler (fpc)** version 3.2.x or newer
2. **C compiler** (MinGW-w64 GCC) — for the ZSTD decoder

Once both are installed, run `build.bat` (Windows native) or
`build.sh` (Linux/macOS cross-compile).

> The output is a 64-bit Windows DLL named `tbl_wlx.wlx64` (TC convention for 64-bit Lister plugins, ~728 KB). On
> Linux/macOS you cross-compile to Windows; the plugin only runs in
> Total Commander on Windows.

---

## Option A: native build on Windows (recommended)

### A.1 Install via Lazarus (easiest)

[Lazarus IDE](https://www.lazarus-ide.org/) bundles **fpc** and
**MinGW-w64 gcc**, so you don't need to install anything else.

1. Download **Lazarus 3.x for Win64** from
   https://www.lazarus-ide.org/index.php?page=downloads
   (installer like `lazarus-3.x.x-fpc-3.2.2-win64.exe`).
2. Install with default options. After install, `fpc.exe` should be in
   `C:\lazarus\fpc\3.2.2\bin\x86_64-win64\`.
3. **Add the Lazarus binaries to PATH**:
   - Win+Pause Break → Advanced system settings → Environment Variables
   - Edit `Path` (user or system) and add:
     - `C:\lazarus\fpc\3.2.2\bin\x86_64-win64`
     - `C:\lazarus\mingw\x86_64-win64\bin` *(or similar — find `gcc.exe`)*
4. Open a fresh **cmd.exe** and verify:
   ```cmd
   fpc -h
   gcc --version
   ```
   Both should print versions.
5. In this directory run:
   ```cmd
   build.bat
   ```
6. Done. `tbl_wlx.wlx64` will appear.

### A.2 Manual install (if you don't want Lazarus)

#### Free Pascal Compiler

1. Download **fpc 3.2.2 for Win64** from
   https://www.freepascal.org/download.html (choose "Win64 / FreePascal").
2. Install. Default location `C:\FPC\3.2.2\` is fine.
3. The installer should add `fpc.exe` to PATH automatically.
   Verify in cmd:
   ```cmd
   fpc -h
   ```

#### MinGW-w64 GCC

Three options, pick one:

- **WinLibs**: download from https://winlibs.com/ (e.g., `MinGW-w64 GCC
  13.x.x with MSVCRT runtime`). Extract somewhere, add the `bin` to PATH.
- **Chocolatey**: `choco install mingw`
- **MSYS2**: install MSYS2, then `pacman -S mingw-w64-x86_64-gcc`. Add
  `C:\msys64\mingw64\bin` to PATH.

Verify:
```cmd
gcc --version
```

After both are in PATH, run `build.bat`.

---

## Option B: cross-compile from Linux

Cross-compiling produces the same Win64 DLL from a Linux host. Useful
on CI or when you don't have a Windows machine handy.

### B.1 Debian / Ubuntu

```bash
sudo apt install fpc fp-units-fcl fp-compiler-source gcc-mingw-w64-x86-64 zip
```

Then in this directory:

```bash
./build.sh
```

`fp-compiler-source` brings the FPC source tree under
`/usr/share/fpcsrc/3.2.2/` — the build script auto-detects it and uses
it to produce Win64 cross-compiled `fcl-base` and `fcl-json` units
(those aren't shipped in the binary fpc package).

### B.2 AlmaLinux / RHEL / Rocky Linux

There is no `fpc` package in the official AlmaLinux repos. You'll
install fpc from the upstream tarball.

#### B.2.1 Install MinGW-w64

```bash
sudo dnf install epel-release
sudo dnf install mingw64-gcc zip
```

Verify:
```bash
x86_64-w64-mingw32-gcc --version
```

#### B.2.2 Install Free Pascal Compiler

The Linux 64-bit fpc tarball includes a `cross/` directory with
Win64 cross-compile support:

```bash
# Pick a stable directory (e.g. /opt)
cd /opt
sudo wget https://downloads.freepascal.org/fpc/dist/3.2.2/x86_64-linux/fpc-3.2.2.x86_64-linux.tar
sudo tar xf fpc-3.2.2.x86_64-linux.tar
cd fpc-3.2.2.x86_64-linux
sudo ./install.sh
# Default install location: /usr/local. Press Enter at all prompts.
```

If the installer asks about cross-compilers, accept Win64. If it
doesn't offer that, you'll need fpc source for the cross-build:

```bash
cd /opt
sudo wget https://downloads.freepascal.org/fpc/dist/3.2.2/source/fpc-3.2.2.source.tar.gz
sudo tar xzf fpc-3.2.2.source.tar.gz
# Builds the Win64 cross-compiler:
cd fpc-3.2.2/
sudo make all OS_TARGET=win64 CPU_TARGET=x86_64 CROSSBINDIR=/usr/x86_64-w64-mingw32/bin
sudo make crossinstall OS_TARGET=win64 CPU_TARGET=x86_64 INSTALL_PREFIX=/usr/local
```

Verify both targets:
```bash
fpc -h | head -3                              # native
fpc -Twin64 -i | head -1                      # cross
```

#### B.2.3 Set FPCSRC and run build

The build script needs the FPC source tree to compile cross-Win64 units
of `fcl-base` / `fcl-json`. If you used the source-tarball path above,
those sources are already on disk:

```bash
export FPCSRC=/opt/fpc-3.2.2
./build.sh
```

If you only have the binary fpc install (no source), download the
source separately:

```bash
cd /opt
sudo wget https://downloads.freepascal.org/fpc/dist/3.2.2/source/fpc-3.2.2.source.tar.gz
sudo tar xzf fpc-3.2.2.source.tar.gz
export FPCSRC=/opt/fpc-3.2.2
./build.sh
```

### B.3 Fedora

```bash
sudo dnf install fpc fpc-src mingw64-gcc zip
```

`fpc-src` provides the FPC source tree. Run:

```bash
./build.sh
```

(The build script auto-detects `/usr/share/fpcsrc/<version>/`.)

### B.4 Arch Linux

```bash
sudo pacman -S fpc mingw-w64-gcc zip
# fpc-src needs to come from AUR:
yay -S fpc-src   # or paru, or build manually
./build.sh
```

### B.5 macOS

`fpc` for macOS doesn't ship with a Win64 cross-compiler in the
homebrew package, so you'll need the source-tarball install path:

```bash
brew install mingw-w64
# Get fpc binary
curl -LO https://downloads.freepascal.org/fpc/dist/3.2.2/macosx/fpc-3.2.2.intelarm64-macosx.dmg
# Mount the dmg, run the installer
# Get fpc source
curl -LO https://downloads.freepascal.org/fpc/dist/3.2.2/source/fpc-3.2.2.source.tar.gz
tar xzf fpc-3.2.2.source.tar.gz
# Build cross to win64 (see B.2.2 instructions, adapt paths)
```

---

## How the build works

```
build.{sh,bat}
   │
   ├── [1/3 or 4]  Bootstrap Win64 fcl-base + fcl-json (.ppu)
   │               (Linux only — Windows-native fpc has these
   │                built-in.)
   │
   ├── [2/3 or 4]  C compile zstddeclib.c → zstdobj_win64.o
   │               (single-file ZSTD decoder, statically linked)
   │
   ├── [3/3 or 4]  Pascal compile tbl_wlx.pas + everything in src/
   │               → tbl_wlx.wlx64 (Win64 PE32+)
   │
   └── [4/4 — Linux only]  Layout final tree
```

The plugin links zstd statically — no runtime DLL dependency
beyond standard Win32 (`kernel32`, `user32`, `comctl32`, `comdlg32`).

---

## Verifying the build

```bash
# Linux
file tbl_wlx.wlx64
# expected: PE32+ executable (DLL) ... x86-64 ... for MS Windows

# Windows
dir tbl_wlx.wlx64
```

Optional smoke test (Linux only — exercises the parser + edit pipeline
without Win32 GUI):

```bash
./run-tests.sh
```

---

## Distributing

The end-user package is just:

```
tbl_wlx_plugin.zip
├── tbl_wlx.wlx64           ← the built DLL
├── pluginst.inf          ← TC plugin installer manifest
├── README.md             ← end-user docs (rename README.txt to .md)
└── schemas/              ← KuroTools header schemas
    ├── headers/
    │   └── *.json (282 files)
    └── t_*.json (81 files)
```

Build it with:

```bash
zip -r tbl_wlx_plugin.zip tbl_wlx.wlx64 pluginst.inf README.md schemas
```

End users open the zip from inside Total Commander; TC reads the
`pluginst.inf` and offers to install automatically.

---

## Troubleshooting

### "fpc: file not found" on Linux

Install the package: `apt install fpc` (Debian/Ubuntu) or
`dnf install fpc` (Fedora). On AlmaLinux/RHEL there's no package — see
B.2 above.

### "Can't find unit Windows" or "Can't find unit fpjson" on Linux build

You're missing the Win64 cross-compiled units. The build script tries
to bootstrap them automatically, but it needs the FPC source tree.
Set `FPCSRC=/path/to/fpcsrc` and re-run.

### "x86_64-w64-mingw32-gcc: command not found"

Install MinGW-w64. See B.1 (Debian), B.2.1 (AlmaLinux), or B.4 (Arch).

### "zstddeclib.c:20:10: fatal error: zstd.h: No such file or directory"

The header should be in `src/zstd/zstd.h` (shipped with this source
package). Check the file is present.

### "warning: missing .note.GNU-stack section implies executable stack"

Cosmetic on Linux cross-compile only — does not affect the Windows DLL.
Caused by zstddeclib.c's lack of GNU-stack note. Safe to ignore.

### Pascal compile error: "Identifier not found 'TJSONObject'"

Your fcl-json units weren't picked up. The build script's
`-Fu./win64_units` flag should resolve this; if it doesn't, run:

```bash
ls win64_units/
```

You should see `fpjson.ppu`, `jsonparser.ppu`, `jsonscanner.ppu`,
`jsonreader.ppu`, `contnrs.ppu`. If they're missing, the bootstrap step
failed — re-check `FPCSRC` and the bootstrap output above.

### DLL runs but Total Commander says "no detection"

The `pluginst.inf` ships a default detection rule
(`EXT="TBL" | (FIND("#TBL")...)`). If it doesn't match, verify in TC:
Configuration → Options → Plugins → Lister (WLX) → Configure →
select `tbl_wlx.wlx64` and check the "Detection string" field.

---

## Reference: source layout

```
src/                   Pascal source (~5400 lines)
  blowfish.pas         Blowfish ECB+CTR (CLE crypto)
  cle.pas              CLE wrap detect + unwrap
  zstddec.pas          ZSTD decoder bridge to the C library
  crc32pac.pas         CRC32 used by section directory CRCs
  libc_stubs.pas       Memory functions zstd needs at link time

  tbltypes.pas         14 primitive types + nested struct
  tblschemas.pas       KuroTools schema DB (282 headers, 346 variants)
  tblfile.pas          TBL file read/write + JSON wire format

  wlx_api.pas          Total Commander Lister WLX SDK constants
  pluginstate.pas      Per-instance state, schema-DB singleton
  inisettings.pas      INI persistence (PreferredGame)
  viewerwin.pas        Legacy single-Edit JSON viewer (kept for search)
  gridmodel.pas        Schema → column list + cell get/set
  gridwin.pas          Win32 ListView grid + sub-grid for nested fields
  tabwin.pas           Tab strip (one tab per section + JSON tab)
  tbl_wlx.pas          DLL exports + entry points + Save/Reload glue

  zstd/
    zstddeclib.c       Single-file ZSTD decoder (Facebook BSD/GPL)
    zstd.h
    LICENSE

tests/                 Pascal regression tests (Linux smoke, ~1700 lines)
schemas/               KuroTools header schemas (363 JSONs)
build.sh / build.bat   Build scripts
run-tests.sh           Linux smoke test runner
pluginst.inf           TC plugin installer manifest
```
