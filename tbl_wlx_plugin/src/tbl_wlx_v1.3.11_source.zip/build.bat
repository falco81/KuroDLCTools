@echo off
REM ===================================================================
REM   build.bat — Native Windows build of the TBL Lister plugin
REM
REM   Requires:
REM     - Free Pascal Compiler 3.2.x for Win64 (fpc.exe in PATH)
REM       Easiest install: Lazarus IDE bundle:
REM         https://www.lazarus-ide.org/index.php?page=downloads
REM     - MinGW-w64 GCC (for ZSTD object compilation; bundled in
REM       Lazarus, or install from https://winlibs.com/)
REM
REM   Output: tbl_wlx.wlx64 in this directory
REM ===================================================================

setlocal enabledelayedexpansion
cd /d "%~dp0"

REM --- Configure tools (override here if needed) ---
if "%FPC%"=="" set FPC=fpc
if "%CC%"==""  set CC=gcc

REM --- Sanity checks ---
where %FPC% >nul 2>&1
if errorlevel 1 (
    echo.
    echo ERROR: %FPC% not found in PATH.
    echo.
    echo Install Lazarus from https://www.lazarus-ide.org/ ^(it bundles fpc^),
    echo or install fpc directly from https://www.freepascal.org/download.html
    echo.
    echo After install, add the fpc bin directory to PATH, e.g.:
    echo     C:\lazarus\fpc\3.2.2\bin\x86_64-win64
    exit /b 1
)
where %CC% >nul 2>&1
if errorlevel 1 (
    echo.
    echo ERROR: %CC% not found.
    echo.
    echo Install MinGW-w64 GCC. Lazarus bundles it ^(in C:\lazarus\mingw\^),
    echo or get a standalone build from https://winlibs.com/ and add the
    echo gcc bin directory to PATH.
    exit /b 1
)

echo.
echo === [1/3] Compiling ZSTD reference C implementation ===
echo.
%CC% -c -O2 -fno-stack-protector -DZSTDLIB_VISIBILITY= -DZSTD_DISABLE_ASM ^
     -o src\zstdobj_win64.o src\zstd\zstddeclib.c
if errorlevel 1 (
    echo.
    echo ERROR: failed to compile src\zstd\zstddeclib.c
    exit /b 1
)

echo.
echo === [2/3] Compiling Pascal plugin to DLL ===
echo.
cd src
%FPC% -O2 -Sh tbl_wlx.pas -otbl_wlx.wlx64
set FPCERR=%errorlevel%
cd ..
if not "%FPCERR%"=="0" (
    echo.
    echo ERROR: Pascal compilation failed
    echo Make sure Free Pascal 3.2.x for Win64 is installed.
    exit /b 1
)

if exist src\tbl_wlx.wlx64 move /Y src\tbl_wlx.wlx64 . > nul

if not exist tbl_wlx.wlx64 (
    echo.
    echo ERROR: tbl_wlx.wlx64 was not produced
    exit /b 1
)

echo.
echo === [3/3] Done. ===
echo.
echo Output: tbl_wlx.wlx64
dir /B tbl_wlx.wlx64

REM Clean up intermediate files
del /Q src\*.ppu 2>nul
del /Q src\*.o 2>nul
del /Q src\zstdobj_win64.o 2>nul
del /Q *.ppu 2>nul
del /Q *.o 2>nul

echo.
echo Distribute via:
echo   zip -r tbl_wlx_plugin.zip tbl_wlx.wlx64 schemas pluginst.inf README.md
echo.
echo or simply copy tbl_wlx.wlx64 + the schemas folder to your TC plugin
echo directory and register the WLX in TC.

exit /b 0
