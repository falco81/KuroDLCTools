@echo off
REM ===================================================================
REM   build.bat - Self-contained Windows build of the TBL Lister plugin
REM
REM   What it does (analogous to build.sh on Linux):
REM     1. Locates Free Pascal Compiler. Looks at PATH first, then
REM        tries common Lazarus install paths.
REM     2. Locates a working GCC (with stdlib headers). FPC's bundled
REM        cc.exe does NOT count - it lacks include paths. We test
REM        an existing gcc by trying to compile a stub that includes
REM        <limits.h> + <stddef.h>.
REM     3. If no working GCC is present, downloads w64devkit
REM        (portable mingw-w64) into .\tools\ and uses that. The
REM        download is cached for subsequent builds.
REM     4. Compiles ZSTD reference C implementation -> zstdobj_win64.o
REM     5. Compiles Pascal plugin -> tbl_wlx.wlx64
REM
REM   Required by the user:
REM     - Free Pascal Compiler 3.2.x for Win64 (typically via Lazarus)
REM     - Internet connection on first run only (for w64devkit
REM       download, ~110 MB). Skipped if you already have a working
REM       gcc in PATH or if .\tools\w64devkit\ already exists.
REM
REM   Output: tbl_wlx.wlx64 in this directory.
REM ===================================================================

setlocal enabledelayedexpansion
cd /d "%~dp0"

set "SCRIPT_DIR=%~dp0"
if "%SCRIPT_DIR:~-1%"=="\" set "SCRIPT_DIR=%SCRIPT_DIR:~0,-1%"

REM ===================================================================
REM   [1/4] Locate FPC
REM ===================================================================
echo.
echo === [1/4] Locating Free Pascal Compiler ===
where fpc >nul 2>&1
if not errorlevel 1 (
    for /f "delims=" %%I in ('where fpc') do echo Found fpc: %%I
    goto fpc_ok
)

REM Try common Lazarus / FPC install paths.
for %%P in (
    "C:\lazarus\fpc\3.2.2\bin\x86_64-win64"
    "C:\lazarus\fpc\3.2.0\bin\x86_64-win64"
    "C:\fpcupdeluxe\fpc\bin\x86_64-win64"
    "C:\FPC\3.2.2\bin\x86_64-win64"
    "%ProgramFiles%\Lazarus\fpc\3.2.2\bin\x86_64-win64"
    "%ProgramFiles(x86)%\Lazarus\fpc\3.2.2\bin\x86_64-win64"
) do (
    if exist "%%~P\fpc.exe" (
        echo Found fpc: %%~P\fpc.exe
        set "PATH=%%~P;!PATH!"
        goto fpc_ok
    )
)

echo.
echo ERROR: Free Pascal Compiler ^(fpc.exe^) not found.
echo.
echo Install Lazarus from https://www.lazarus-ide.org/ ^(it bundles fpc^),
echo or install FPC directly from https://www.freepascal.org/download.html
echo.
echo If FPC is installed at a custom path, add its bin directory to PATH:
echo     set PATH=C:\path\to\fpc\bin\x86_64-win64;%%PATH%%
echo and re-run this script.
exit /b 1

:fpc_ok

REM ===================================================================
REM   [2/4] Locate (or download) a working GCC
REM ===================================================================
echo.
echo === [2/4] Locating C compiler for ZSTD ===

set "GCC_OK=0"

REM First try: an existing gcc in PATH (TDM-GCC, MinGW-w64, etc.).
where gcc >nul 2>&1
if not errorlevel 1 (
    REM Verify it has working stdlib headers - FPC's internal cc.exe
    REM is also called gcc-like and would fail this test.
    > tmp_gcc_test.c echo #include ^<limits.h^>
    >>tmp_gcc_test.c echo #include ^<stddef.h^>
    >>tmp_gcc_test.c echo int main^(void^) { return 0; }
    gcc -c tmp_gcc_test.c -o tmp_gcc_test.o >nul 2>&1
    if not errorlevel 1 (
        for /f "delims=" %%I in ('where gcc') do echo Found working gcc: %%I
        set "GCC_OK=1"
    ) else (
        echo Existing gcc lacks stdlib headers - will fall back to bundled toolchain.
    )
    if exist tmp_gcc_test.c del /Q tmp_gcc_test.c >nul 2>&1
    if exist tmp_gcc_test.o del /Q tmp_gcc_test.o >nul 2>&1
)

REM Second try: a previously downloaded w64devkit cached in .\tools\
if "!GCC_OK!"=="0" (
    if exist "tools\w64devkit\bin\gcc.exe" (
        echo Found cached w64devkit at tools\w64devkit\
        set "PATH=!SCRIPT_DIR!\tools\w64devkit\bin;!PATH!"
        set "GCC_OK=1"
    )
)

REM Third try: download w64devkit.
if "!GCC_OK!"=="0" (
    echo.
    echo No working C toolchain found. Downloading w64devkit...
    echo This is a one-time bootstrap. The toolchain is cached in
    echo .\tools\w64devkit\ for subsequent builds.
    echo.

    where curl >nul 2>&1
    if errorlevel 1 (
        echo ERROR: curl.exe not found. curl is built into Windows 10
        echo 1803 and later. Either update Windows, or manually
        echo install w64devkit and re-run this script:
        echo   https://github.com/skeeto/w64devkit/releases
        exit /b 1
    )

    if not exist tools mkdir tools

    echo Downloading w64devkit-x64-2.7.0.7z.exe ^(~56 MB^)...
    curl -L --fail --progress-bar ^
         --output tools\w64devkit-installer.exe ^
         https://github.com/skeeto/w64devkit/releases/download/v2.7.0/w64devkit-x64-2.7.0.7z.exe
    if errorlevel 1 (
        echo ERROR: download failed. Check your internet connection
        echo or download w64devkit-x64-2.7.0.7z.exe manually from
        echo https://github.com/skeeto/w64devkit/releases/tag/v2.7.0
        echo and place it in the tools\ directory ^(rename it to
        echo w64devkit-installer.exe^), then re-run this script.
        exit /b 1
    )

    echo Extracting...
    pushd tools
    w64devkit-installer.exe -y >nul 2>&1
    if errorlevel 1 (
        popd
        echo ERROR: w64devkit extraction failed
        exit /b 1
    )
    del /Q w64devkit-installer.exe >nul 2>&1
    popd

    if not exist "tools\w64devkit\bin\gcc.exe" (
        echo ERROR: tools\w64devkit\bin\gcc.exe missing after extraction.
        echo Try deleting the tools\ folder and running this script again.
        exit /b 1
    )

    echo w64devkit installed at tools\w64devkit\
    set "PATH=!SCRIPT_DIR!\tools\w64devkit\bin;!PATH!"
    set "GCC_OK=1"
)

REM ===================================================================
REM   [3/4] Compile ZSTD reference C implementation
REM ===================================================================
echo.
echo === [3/4] Compiling ZSTD reference C implementation ===
gcc -c -O2 -fno-stack-protector -DZSTDLIB_VISIBILITY= -DZSTD_DISABLE_ASM ^
    -o src\zstdobj_win64.o src\zstd\zstddeclib.c
if errorlevel 1 (
    echo.
    echo ERROR: failed to compile src\zstd\zstddeclib.c
    exit /b 1
)
echo Built: src\zstdobj_win64.o

REM ===================================================================
REM   [4/4] Compile Pascal plugin
REM ===================================================================
echo.
echo === [4/4] Compiling Pascal plugin to DLL ===
cd src
fpc -O2 -Sh tbl_wlx.pas -otbl_wlx.wlx64
set "FPCERR=!errorlevel!"
cd ..
if not "!FPCERR!"=="0" (
    echo.
    echo ERROR: Pascal compilation failed
    exit /b 1
)

if exist src\tbl_wlx.wlx64 move /Y src\tbl_wlx.wlx64 . >nul

if not exist tbl_wlx.wlx64 (
    echo.
    echo ERROR: tbl_wlx.wlx64 was not produced
    exit /b 1
)

echo.
echo === Done ===
echo.
for %%F in (tbl_wlx.wlx64) do echo   tbl_wlx.wlx64    %%~zF bytes
echo   schemas\         (363 JSON files)
echo   pluginst.inf     (TC plugin installer manifest)
echo.

REM Clean up intermediate files
del /Q src\*.ppu >nul 2>&1
del /Q src\*.o >nul 2>&1
del /Q *.ppu >nul 2>&1
del /Q *.o >nul 2>&1

echo Smoke test: open Total Commander, F3 over a .tbl file.
echo Distribute:
echo   - Right-click pluginst.inf in Total Commander - Install plugin
echo   - Or copy tbl_wlx.wlx64 + schemas\ to your TC plugin folder
echo     and register the WLX manually in TC's settings.
echo.
exit /b 0
