#!/bin/bash
# =====================================================================
#   build.sh — Cross-compile the TBL Lister plugin (Linux → Win64 DLL)
#
# Tested on: Debian/Ubuntu, AlmaLinux 8/9, RHEL 8/9, Fedora.
#
# Requires:
#   - Free Pascal Compiler 3.2.x with x86_64-win64 target available
#       Debian/Ubuntu:    apt install fpc fp-units-fcl fp-compiler-source
#       AlmaLinux/RHEL:   manual install — see BUILD.md (no fpc package)
#
#   - MinGW-w64 GCC (for ZSTD object compilation)
#       Debian/Ubuntu:    apt install gcc-mingw-w64-x86-64
#       AlmaLinux/RHEL:   dnf install epel-release && dnf install mingw64-gcc
#
#   - FPC source tree (for fcl-base / fcl-json + cross-build of any
#     missing Win64 units)
#       Debian/Ubuntu:    /usr/share/fpcsrc/<version>/
#                         (from fp-compiler-source package)
#       Other:            wget the source tarball — see BUILD.md
#                         OR set FPCSRC env var to your fpc source root
#
#   - Win64 RTL units. The Linux FPC distribution typically ships only
#     Linux RTL; Win64 cross-units may need to be built locally.
#     This script will auto-detect and bootstrap them if needed.
#
# Output: tbl_wlx.wlx64 in this directory (also copied next to schemas)
# =====================================================================

set -e
cd "$(dirname "$0")"

# --- Configuration ---
FPC="${FPC:-fpc}"
CC="${CC:-x86_64-w64-mingw32-gcc}"

# --- Locate FPC source tree ---
if [ -z "${FPCSRC:-}" ]; then
  for d in /usr/share/fpcsrc/3.2.2 /usr/share/fpcsrc/3.2.0 \
           /usr/share/fpcsrc/3.2.4 /usr/share/fpcsrc/*; do
    if [ -d "$d/packages" ]; then FPCSRC="$d"; break; fi
  done
fi
if [ -z "${FPCSRC:-}" ] || [ ! -d "$FPCSRC/packages" ]; then
  cat >&2 << 'EOF'
error: FPC source tree not found.

Debian/Ubuntu:
    sudo apt install fp-compiler-source

AlmaLinux/RHEL/manual:
    cd /opt
    wget https://downloads.freepascal.org/fpc/dist/3.2.2/source/fpc-3.2.2.source.tar.gz
    sudo mkdir -p /usr/share/fpcsrc/3.2.2
    sudo tar xzf fpc-3.2.2.source.tar.gz \
                 -C /usr/share/fpcsrc/3.2.2 --strip-components=1

Or set FPCSRC env var:
    export FPCSRC=/path/to/fpcsrc
    ./build.sh
EOF
  exit 1
fi
echo "Using FPC source at: $FPCSRC"

# --- Check tools ---
command -v "$FPC" >/dev/null 2>&1 || {
  echo "error: $FPC not found in PATH" >&2; exit 1; }
command -v "$CC" >/dev/null 2>&1 || {
  echo "error: $CC not found (install gcc-mingw-w64-x86-64 or mingw64-gcc)" >&2
  exit 1; }

# --- Locate FPC install dir (so we know where Win64 RTL units live) ---
FPC_VERSION="$("$FPC" -iV 2>/dev/null | tr -d '[:space:]')"
if [ -z "$FPC_VERSION" ]; then
  echo "error: cannot determine FPC version (fpc -iV failed)" >&2
  exit 1
fi

FPC_BIN="$(command -v "$FPC")"
FPC_REAL="$(readlink -f "$FPC_BIN")"
# Walk back from the binary to find the lib/fpc/<ver> root.
# Common layouts:
#   /opt/fpc-3.2.2/{bin/fpc, lib/fpc/3.2.2/}            (manual install)
#   /usr/{bin/fpc, lib/fpc/3.2.2/}                       (rpm/apt: AlmaLinux)
#   /usr/{bin/fpc, lib/x86_64-linux-gnu/fpc/3.2.2/}      (Debian multi-arch)
# Override via FPC_LIB env var if your install is non-standard.
if [ -z "${FPC_LIB:-}" ]; then
  for candidate in \
      "$(dirname "$(dirname "$FPC_REAL")")/lib/fpc/$FPC_VERSION" \
      "/opt/fpc-$FPC_VERSION/lib/fpc/$FPC_VERSION" \
      "/usr/lib/fpc/$FPC_VERSION" \
      "/usr/lib/x86_64-linux-gnu/fpc/$FPC_VERSION" \
      "/usr/local/lib/fpc/$FPC_VERSION"; do
    if [ -d "$candidate" ]; then
      FPC_LIB="$candidate"
      break
    fi
  done
fi
if [ -z "${FPC_LIB:-}" ] || [ ! -d "$FPC_LIB" ]; then
  echo "error: cannot locate FPC lib dir for version $FPC_VERSION" >&2
  echo "       Set FPC_LIB env var manually if your install is non-standard:" >&2
  echo "         export FPC_LIB=/path/to/lib/fpc/$FPC_VERSION" >&2
  exit 1
fi
WIN64_RTL="$FPC_LIB/units/x86_64-win64/rtl"
WIN64_WINUNITS="$FPC_LIB/units/x86_64-win64/winunits-base"
# Debian/Ubuntu splits some objpas units (strutils, variants, dateutils,
# fmtbcd, ...) into a separate rtl-objpas subdir. AlmaLinux/manual
# bootstrap puts them in rtl/. We pass both paths to fpc.
WIN64_RTL_OBJPAS="$FPC_LIB/units/x86_64-win64/rtl-objpas"
echo "FPC lib dir:    $FPC_LIB"

# =====================================================================
#   Bootstrap missing Win64 cross-build units
#   On Debian/Ubuntu these come from the package; on AlmaLinux/RHEL/
#   manual installs they have to be built locally from FPC source.
# =====================================================================

bootstrap_win64_rtl() {
  echo
  echo "=== Bootstrapping Win64 RTL units (one-time) ==="
  echo "    Output: $WIN64_RTL"
  echo "    This builds the Pascal runtime for the Win64 target from FPC source."
  echo "    Takes 1-3 minutes."
  ( cd "$FPCSRC/rtl" && \
    make all OS_TARGET=win64 CPU_TARGET=x86_64 PP="$FPC_BIN" \
        >/tmp/fpc_rtl_build.log 2>&1 ) || {
    echo "error: RTL build failed. Tail of log:"
    tail -30 /tmp/fpc_rtl_build.log
    exit 1
  }
  # `make install` requires fpcmake which the Linux tarball doesn't ship.
  # Just copy the .ppu/.o files manually — that's all install does.
  mkdir -p "$WIN64_RTL"
  cp "$FPCSRC/rtl/units/x86_64-win64/"*.ppu "$WIN64_RTL/" 2>/dev/null || true
  cp "$FPCSRC/rtl/units/x86_64-win64/"*.o   "$WIN64_RTL/" 2>/dev/null || true
  echo "    OK: $(ls "$WIN64_RTL" 2>/dev/null | wc -l) files installed"
}

bootstrap_extra_rtl_unit() {
  # Build a unit from the FPC source tree into the RTL units dir.
  # $1 = source file path under $FPCSRC
  # $2 = optional include path under $FPCSRC
  local src="$FPCSRC/$1"
  local inc_flag=""
  if [ -n "${2:-}" ]; then inc_flag="-Fi$FPCSRC/$2"; fi
  if [ ! -f "$src" ]; then
    echo "warning: $src not found, skipping" >&2
    return 1
  fi
  "$FPC" -Twin64 -O2 -Sh \
    -Fu"$WIN64_RTL" $inc_flag \
    -FU"$WIN64_RTL" "$src" >/dev/null 2>&1 || {
      echo "warning: failed to build $1" >&2
      return 1
    }
}

bootstrap_winunits() {
  echo
  echo "=== Bootstrapping winunits-base (commctrl, commdlg, activex) ==="
  echo "    Output: $WIN64_WINUNITS"
  mkdir -p "$WIN64_WINUNITS"
  # commctrl pulls in activex which needs variants → varutils.
  # Build the dependency chain in order (silently — these are well-tested).
  bootstrap_extra_rtl_unit \
    "packages/rtl-objpas/src/win/varutils.pp" \
    "packages/rtl-objpas/src/inc"
  bootstrap_extra_rtl_unit \
    "packages/rtl-objpas/src/inc/variants.pp"
  bootstrap_extra_rtl_unit \
    "packages/rtl-objpas/src/inc/strutils.pp"
  bootstrap_extra_rtl_unit \
    "packages/rtl-objpas/src/inc/dateutils.pp" || true
  # Now winunits themselves.
  for u in commdlg commctrl; do
    local src="$FPCSRC/packages/winunits-base/src/${u}.pp"
    if [ ! -f "$src" ]; then
      echo "warning: $src not found, skipping" >&2
      continue
    fi
    "$FPC" -Twin64 -O2 -Sh \
      -Fu"$WIN64_RTL" \
      -Fu"$WIN64_WINUNITS" \
      -FU"$WIN64_WINUNITS" \
      "$src" >/dev/null 2>&1 || {
        echo "warning: failed to build $u (will continue)" >&2
      }
  done
  echo "    OK: $(ls "$WIN64_WINUNITS" 2>/dev/null | wc -l) files installed"
}

# Detect & bootstrap as needed.
if [ ! -f "$WIN64_RTL/system.ppu" ]; then
  echo "Win64 RTL units not found at $WIN64_RTL — bootstrapping…"
  if [ ! -w "$(dirname "$WIN64_RTL")" ] && [ "$(id -u)" -ne 0 ]; then
    echo "error: $WIN64_RTL is not writable. Run as root or pre-create:" >&2
    echo "    sudo mkdir -p $WIN64_RTL && sudo chown -R \$USER $FPC_LIB" >&2
    exit 1
  fi
  bootstrap_win64_rtl
fi
if [ ! -f "$WIN64_WINUNITS/commdlg.ppu" ] || [ ! -f "$WIN64_WINUNITS/commctrl.ppu" ]; then
  echo "winunits-base (commdlg/commctrl) not found — bootstrapping…"
  if [ ! -w "$FPC_LIB/units/x86_64-win64" ] && [ "$(id -u)" -ne 0 ]; then
    echo "error: $WIN64_WINUNITS is not writable. Run as root or pre-create." >&2
    exit 1
  fi
  bootstrap_winunits
fi

# Sanity check. strutils may live in rtl/ (manual bootstrap) or
# rtl-objpas/ (Debian split package); accept either.
for required in "$WIN64_RTL/system.ppu" "$WIN64_RTL/sysutils.ppu" \
                "$WIN64_RTL/classes.ppu" "$WIN64_RTL/windows.ppu" \
                "$WIN64_WINUNITS/commctrl.ppu" "$WIN64_WINUNITS/commdlg.ppu"; do
  if [ ! -f "$required" ]; then
    echo "error: missing required Win64 unit: $required" >&2
    echo "       Bootstrap failed. Inspect /tmp/fpc_rtl_build.log if present." >&2
    exit 1
  fi
done
if [ ! -f "$WIN64_RTL/strutils.ppu" ] && [ ! -f "$WIN64_RTL_OBJPAS/strutils.ppu" ]; then
  echo "error: strutils.ppu not found in $WIN64_RTL or $WIN64_RTL_OBJPAS" >&2
  exit 1
fi

# =====================================================================
#   Bootstrap fcl-base / fcl-json (used by the plugin for JSON I/O)
# =====================================================================
WIN64_UNITS="${WIN64_UNITS:-./win64_units}"
mkdir -p "$WIN64_UNITS"

NEED_FCL_REBUILD=0
for u in contnrs jsonscanner fpjson jsonreader jsonparser; do
  if [ ! -f "$WIN64_UNITS/${u}.ppu" ]; then NEED_FCL_REBUILD=1; fi
done

if [ "$NEED_FCL_REBUILD" = "1" ]; then
  echo
  echo "=== [1/4] Bootstrapping Win64 fcl-base / fcl-json units ==="
  echo "    (one-time; output: $WIN64_UNITS/*.ppu)"

  # fcl-base: contnrs.pp
  "$FPC" -O2 -Sh -Twin64 \
       -Fu"$WIN64_RTL" \
       -Fu"$WIN64_RTL_OBJPAS" \
       -FU"$WIN64_UNITS" \
       -Fi"$FPCSRC/packages/fcl-base/inc" \
       "$FPCSRC/packages/fcl-base/src/contnrs.pp"

  # fcl-json: scanner first (no deps), then fpjson + reader + parser.
  for u in jsonscanner fpjson jsonreader jsonparser; do
    "$FPC" -O2 -Sh -Twin64 \
         -Fu"$WIN64_RTL" \
         -Fu"$WIN64_RTL_OBJPAS" \
         -FU"$WIN64_UNITS" \
         -Fu"$WIN64_UNITS" \
         -Fi"$FPCSRC/packages/fcl-json/src" \
         "$FPCSRC/packages/fcl-json/src/${u}.pp"
  done
  echo "    OK"
fi

# =====================================================================
#   Build ZSTD reference C objects (one for Win64 DLL, one for Linux
#   smoke tests if gcc is available).
# =====================================================================
echo
echo "=== [2/4] Cross-compiling ZSTD reference C implementation ==="
echo "    Win64 (for the DLL):"
"$CC" -c -O2 -fno-stack-protector -DZSTDLIB_VISIBILITY= -DZSTD_DISABLE_ASM \
      -o src/zstdobj_win64.o src/zstd/zstddeclib.c

if command -v gcc >/dev/null 2>&1; then
  echo "    Linux ELF (for run-tests.sh):"
  gcc -c -O2 -fno-stack-protector -DZSTDLIB_VISIBILITY= -DZSTD_DISABLE_ASM \
      -o src/zstdobj.o src/zstd/zstddeclib.c
fi

# =====================================================================
#   Build the plugin DLL.
#   -Fu paths: our local fcl-units, FPC's Win64 RTL, rtl-objpas (Debian
#   splits some units there), winunits-base.
# =====================================================================
echo
echo "=== [3/4] Cross-compiling Pascal plugin to Win64 ==="
cd src
"$FPC" -O2 -Sh -Twin64 \
       -Fu"../$WIN64_UNITS" \
       -Fu"$WIN64_RTL" \
       -Fu"$WIN64_RTL_OBJPAS" \
       -Fu"$WIN64_WINUNITS" \
       tbl_wlx.pas -otbl_wlx.wlx64
cd ..

if [ ! -f src/tbl_wlx.wlx64 ]; then
  echo "error: src/tbl_wlx.wlx64 was not produced"
  exit 1
fi
mv src/tbl_wlx.wlx64 tbl_wlx.wlx64

# --- Layout for distribution ---
echo
echo "=== [4/4] Layout ==="
echo "  tbl_wlx.wlx64      $(ls -la tbl_wlx.wlx64 | awk '{print $5}') bytes"
if command -v file >/dev/null; then
  file tbl_wlx.wlx64
fi
if [ -d schemas ]; then
  echo "  schemas/           $(find schemas -name '*.json' | wc -l) JSONs"
fi
if [ -f pluginst.inf ]; then
  echo "  pluginst.inf       (TC plugin installer manifest)"
fi

# --- Cleanup intermediate files ---
# Keep src/zstdobj.o (Linux ELF) — run-tests.sh needs it.
rm -f src/*.ppu src/zstdobj_win64.o
find src -maxdepth 1 -name "*.o" ! -name "zstdobj.o" -delete 2>/dev/null || true
rm -f *.ppu
find . -maxdepth 1 -name "*.o" -delete 2>/dev/null || true

echo
echo "=== Done. ==="
echo
echo "Smoke test? Run ./run-tests.sh"
echo "Distribute?"
echo "  zip -r tbl_wlx_plugin.zip tbl_wlx.wlx64 schemas pluginst.inf README.md"
