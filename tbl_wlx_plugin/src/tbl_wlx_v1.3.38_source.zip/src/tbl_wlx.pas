library tbl_wlx;

{$mode objfpc}{$H+}

// Total Commander Lister (.wlx) plugin for Falcom #TBL files.
// v1: read-only JSON view. F3/F7 search. Auto-detects CLE-wrapped
// (F9BA/D9BA) files.
//
// Exports the standard WLX entry-point set:
//   ListLoad, ListLoadW, ListSendCommand, ListCloseWindow,
//   ListGetDetectString, ListSearchText, ListSearchTextW,
//   ListSearchDialog, ListPrint, ListSetDefaultParams,
//   ListNotificationReceived
//
// Build: fpc -O2 -Twin64 tbl_wlx.pas
// Result: tbl_wlx.dll which TC loads when the user views a .tbl
// file. Schemas live in `schemas/` next to the DLL.

uses
  Windows, SysUtils, Classes, CommDlg,
  fpjson, jsonparser, jsonscanner,
  wlx_api,
  tbltypes, tblschemas, tblfile,
  pluginstate, inisettings,
  viewerwin,
  gridmodel, gridwin, tabwin;

// ---------------------------------------------------------------------
//   Helpers
// ---------------------------------------------------------------------

function IfThen(Cond: Boolean; const ATrue, AFalse: AnsiString): AnsiString;
begin
  if Cond then Result := ATrue else Result := AFalse;
end;

// Build a formatted JSON string from a TBL file. Includes a tiny
// header line that tells the user which game variant was matched
// for each section, since that's hard to spot otherwise.
function BuildJSONView(const Tbl: TTBLFile): AnsiString;
var
  Js: TJSONObject;
  Body: AnsiString;
  Header: AnsiString;
  Warnings: AnsiString;
  i: Integer;
begin
  Js := Tbl.ToJSON;
  try
    Body := Js.FormatJSON();
  finally
    Js.Free;
  end;

  Header := '// Falcom #TBL viewer  —  ' + IntToStr(Length(Tbl.Sections)) + ' section(s)' + #10;
  if Tbl.WasCLEWrapped then
    Header := Header + '// (file was CLE-wrapped — decrypted/decompressed automatically)' + #10;
  for i := 0 to High(Tbl.Sections) do
    Header := Header + Format(
      '//   [%d] %s  len=%d, mode=%s%s%s',
      [i, Tbl.Sections[i].Name, Tbl.Sections[i].EntryLength,
       IfThen(Tbl.Sections[i].Mode = smDecoded, 'decoded', 'raw'),
       IfThen(Tbl.Sections[i].GameTag <> '',
              ', game=' + Tbl.Sections[i].GameTag, ''),
       #10]);

  if Tbl.SchemaWarnings.Count > 0 then
  begin
    Warnings := '// Schema warnings:' + #10;
    for i := 0 to Tbl.SchemaWarnings.Count - 1 do
      Warnings := Warnings + '//   ' + Tbl.SchemaWarnings[i] + #10;
  end
  else
    Warnings := '';

  Result := Header + Warnings + #10 + Body;
end;

// Helper: write small string to a fixed PAnsiChar buffer with size limit.
procedure CopyToBuf(P: PAnsiChar; MaxLen: Integer; const S: AnsiString);
var L: Integer;
begin
  if (P = nil) or (MaxLen <= 0) then Exit;
  L := Length(S);
  if L >= MaxLen then L := MaxLen - 1;
  if L > 0 then Move(S[1], P^, L);
  P[L] := #0;
end;

// ---------------------------------------------------------------------
//   Save handler  (Ctrl+S in the Edit control)
// ---------------------------------------------------------------------

// Strip our header comment lines back out of the Edit text. The `//`
// lines we prepended in BuildJSONView aren't valid JSON; we add them
// fresh on each load and re-strip on save. Strip rule: skip leading
// lines that begin with "//" and any blank lines between the header
// block and the first `{` of the body.
function StripHeaderComment(const Text: AnsiString): AnsiString;
var
  i, n: Integer;
  LineStart: Integer;
begin
  n := Length(Text);
  i := 1;
  // Walk over header comment lines + blank lines.
  while i <= n do
  begin
    LineStart := i;
    // Find end of current line
    while (i <= n) and (Text[i] <> #10) do Inc(i);
    // Now Text[LineStart..i-1] is the line content (without LF).
    // Skip if it starts with "//" or is whitespace-only.
    if  ((i - LineStart >= 2) and (Text[LineStart] = '/') and
         (Text[LineStart+1] = '/'))
       or (Trim(Copy(Text, LineStart, i - LineStart)) = '') then
    begin
      // consume the LF too (if any) and continue
      if (i <= n) and (Text[i] = #10) then Inc(i);
      Continue;
    end;
    // Hit a real content line — stop here.
    Result := Copy(Text, LineStart, n - LineStart + 1);
    Exit;
  end;
  Result := '';
end;

// Pre-save consistency check: the JSON the user typed must have
// "headers" and "data" arrays of the same length as the original
// model, with matching section names. (We can't round-trip an
// arbitrary JSON because the TBL writer uses the original
// schema/section mapping.)
// Returns True if structurally OK; otherwise pops a MessageBox and
// returns False.
// Forward — definition is below SaveInstance. Used from SaveInstance
// to refresh all tabs from the current model after a successful save.
procedure BuildTabsForInstance(TabHost: HWND; Inst: TInstance; DB: TSchemaDB); forward;
function ValidateJSONStructure(Js: TJSONObject; Tbl: TTBLFile;
                               HostWnd: HWND): Boolean; forward;

// ---------------------------------------------------------------------
//   Tab-switch sync (JSON ↔ grid coherence)
// ---------------------------------------------------------------------
//
// The JSON tab and the grid tabs are two views over the same model
// (Inst.Tbl). Edits in one don't propagate to the other in real time
// because the JSON Edit holds raw text and the grids hold TJSONArray
// references — keeping them tied each keystroke would mean a full
// re-serialize on every WM_CHAR.
//
// Instead we sync at tab-switch time:
//   * Leaving JSON  → if dirty, parse the Edit text, run FromJSON on
//                     the model, then ClearAllTabs + BuildTabsForInstance
//                     (because FromJSON replaces section.Rows arrays,
//                     making any held grid references stale). The
//                     newly-built tabs include the destination tab,
//                     which we re-select.
//   * Leaving grid  → re-run BuildJSONView on the model and push the
//                     new text into the JSON Edit. Existing grid Rows
//                     references stay valid (FromJSON wasn't called),
//                     so no rebuild needed.
//
// Returns True if the function rebuilt + reselected tabs itself
// (caller should skip its own ShowTabAt). Returns False otherwise.
function BeforeTabSwitchSync(HostWnd: HWND; FromIdx, ToIdx: Integer): Boolean;
var
  Inst: TInstance;
  FromKind, ToKind: TTabContentKind;
  JsonEdit: HWND;
  Text, JsonBody: AnsiString;
  P: TJSONParser;
  D: TJSONData;
  Js: TJSONObject;
begin
  Result := False;
  // First-time tab activation (no prior tab) — nothing to sync.
  if FromIdx < 0 then Exit;
  if FromIdx = ToIdx then Exit;
  Inst := FindInstance(HostWnd);
  if (Inst = nil) or (Inst.Tbl = nil) then Exit;
  // No edits yet → nothing to push around.
  if not Inst.Dirty then Exit;

  FromKind := GetTabKind(HostWnd, FromIdx);
  ToKind   := GetTabKind(HostWnd, ToIdx);

  // ---- Leaving JSON tab: parse Edit text into the model ----------
  if FromKind = tcJSON then
  begin
    JsonEdit := GetTabChild(HostWnd, FromIdx);
    if JsonEdit = 0 then Exit;
    Text := GetViewerText(JsonEdit);
    if Text = '' then Exit;
    JsonBody := StripHeaderComment(Text);
    if JsonBody = '' then Exit;
    D := nil;
    try
      P := TJSONParser.Create(JsonBody, []);
      try
        D := P.Parse;
      finally
        P.Free;
      end;
    except
      // Bad JSON — leave it alone, user will see the parse error
      // when they try to save.
      Exit;
    end;
    if not (D is TJSONObject) then
    begin
      if D <> nil then D.Free;
      Exit;
    end;
    Js := TJSONObject(D);
    try
      if not ValidateJSONStructure(Js, Inst.Tbl, HostWnd) then Exit;
      try
        Inst.Tbl.FromJSON(Js);
      except
        // FromJSON failed — leave model alone.
        Exit;
      end;
    finally
      Js.Free;
    end;
    // Model is now fresh from JSON. Old grid tabs reference now-freed
    // arrays — must rebuild. ClearAllTabs unsubclasses our JSON Edit
    // too, so we lose the current Edit's text, but that's fine: we
    // just parsed it into the model.
    ClearAllTabs(HostWnd);
    BuildTabsForInstance(HostWnd, Inst, GetSchemaDB);
    SelectTabAt(HostWnd, ToIdx);
    Result := True;  // tabwin should not call ShowTabAt
    Exit;
  end;

  // ---- Entering JSON tab from a grid: refresh the JSON text -------
  if (FromKind = tcGrid) and (ToKind = tcJSON) then
  begin
    JsonEdit := GetTabChild(HostWnd, ToIdx);
    if JsonEdit = 0 then Exit;
    SuppressJSONChange;
    try
      SetViewerText(JsonEdit, BuildJSONView(Inst.Tbl));
    finally
      UnsuppressJSONChange;
    end;
    // Model is unchanged; tabwin's ShowTabAt is what we want.
    // Result stays False.
    Exit;
  end;

  // Grid → grid, Config → anything, anything → Config: nothing to sync.
end;

// "Export current TBL as JSON" — bound to the Config tab button.
// Shows a Save File dialog; writes BuildJSONView() output (which
// includes the header comment) to the chosen path. Suggested
// filename is the current TBL's basename with ".json" extension.
procedure ExportCurrentJSON(HostWnd: HWND);
var
  Inst: TInstance;
  OFN: TOpenFilenameA;
  FileBuf: array[0..1023] of AnsiChar;
  Filter: AnsiString;
  Initial: AnsiString;
  Json: AnsiString;
  FS: TFileStream;
begin
  Inst := FindInstance(HostWnd);
  if (Inst = nil) or (Inst.Tbl = nil) then
  begin
    MessageBoxA(HostWnd, 'No file is currently open.',
                'TBL Plugin - export', MB_ICONWARNING);
    Exit;
  end;

  // Pre-fill with <basename>.json next to the source TBL
  Initial := ChangeFileExt(ExtractFileName(Inst.FilePath), '.json');
  FillChar(FileBuf, SizeOf(FileBuf), 0);
  StrPLCopy(FileBuf, Initial, SizeOf(FileBuf) - 1);

  // OFN's filter is a doubled-null-terminated, internally-NUL-
  // separated string. Build it by hand: "JSON files\0*.json\0
  //   All files\0*.*\0\0".
  Filter := 'JSON files'#0'*.json'#0'All files'#0'*.*'#0#0;

  FillChar(OFN, SizeOf(OFN), 0);
  OFN.lStructSize     := SizeOf(OFN);
  OFN.hWndOwner       := HostWnd;
  OFN.lpstrFilter     := PAnsiChar(Filter);
  OFN.nFilterIndex    := 1;
  OFN.lpstrFile       := @FileBuf[0];
  OFN.nMaxFile        := SizeOf(FileBuf);
  OFN.lpstrTitle      := 'Export TBL as JSON';
  OFN.lpstrDefExt     := 'json';
  OFN.Flags           := OFN_OVERWRITEPROMPT or OFN_PATHMUSTEXIST or
                         OFN_HIDEREADONLY or OFN_NOCHANGEDIR;

  if not GetSaveFileNameA(@OFN) then Exit;   // user cancelled

  // Same JSON the JSON tab shows (with header comment).
  Json := BuildJSONView(Inst.Tbl);
  try
    FS := TFileStream.Create(StrPas(@FileBuf[0]), fmCreate);
    try
      if Length(Json) > 0 then
        FS.WriteBuffer(Json[1], Length(Json));
    finally
      FS.Free;
    end;
  except
    on E: Exception do
    begin
      MessageBoxA(HostWnd,
        PAnsiChar('Export failed:' + #13#10 + E.Message),
        'TBL Plugin - export', MB_ICONERROR);
      Exit;
    end;
  end;
end;

function ValidateJSONStructure(Js: TJSONObject; Tbl: TTBLFile;
                               HostWnd: HWND): Boolean;
var
  Hdrs, Data: TJSONData;
  ArrHdrs, ArrData: TJSONArray;
  i: Integer;
  ItemObj: TJSONObject;
  Name: AnsiString;
  Msg: AnsiString;
begin
  // The JSON shape produced by tblfile.ToJSON is:
  //   { "headers": [ {"name", "schema"}, ... ],
  //     "data":    [ {"name", "data": [...rows...]}, ... ] }
  // Both arrays should have one entry per section. We check that
  // the user hasn't added/removed/renamed sections — anything else
  // (row content, types, even row counts) is up to FromJSON to
  // validate later.
  Result := False;
  Hdrs := Js.Find('headers');
  Data := Js.Find('data');
  if (Hdrs = nil) or (Data = nil) then
  begin
    MessageBoxA(HostWnd,
      'JSON missing "headers" or "data" array - refusing to save.',
      'TBL Plugin - consistency check', MB_ICONERROR);
    Exit;
  end;
  if (not (Hdrs is TJSONArray)) or (not (Data is TJSONArray)) then
  begin
    MessageBoxA(HostWnd,
      '"headers" or "data" is not a JSON array - refusing to save.',
      'TBL Plugin - consistency check', MB_ICONERROR);
    Exit;
  end;
  ArrHdrs := TJSONArray(Hdrs);
  ArrData := TJSONArray(Data);
  if (ArrHdrs.Count <> Length(Tbl.Sections)) or
     (ArrData.Count <> Length(Tbl.Sections)) then
  begin
    Msg := Format(
      'Section count mismatch: original has %d, edited JSON has %d headers / %d data.' +
      #13#10 + 'You cannot add or remove sections - refusing to save.',
      [Length(Tbl.Sections), ArrHdrs.Count, ArrData.Count]);
    MessageBoxA(HostWnd, PAnsiChar(Msg),
      'TBL Plugin - consistency check', MB_ICONERROR);
    Exit;
  end;
  for i := 0 to ArrHdrs.Count - 1 do
  begin
    if not (ArrHdrs.Items[i] is TJSONObject) then
    begin
      Msg := Format('headers[%d] is not an object.', [i]);
      MessageBoxA(HostWnd, PAnsiChar(Msg),
        'TBL Plugin - consistency check', MB_ICONERROR);
      Exit;
    end;
    ItemObj := TJSONObject(ArrHdrs.Items[i]);
    Name := ItemObj.Get('name', AnsiString(''));
    if Name <> Tbl.Sections[i].Name then
    begin
      Msg := Format(
        'Section name mismatch at index %d:' + #13#10 +
        '  original: %s' + #13#10 +
        '  edited:   %s' + #13#10 +
        'You cannot rename sections - refusing to save.',
        [i, Tbl.Sections[i].Name, Name]);
      MessageBoxA(HostWnd, PAnsiChar(Msg),
        'TBL Plugin - consistency check', MB_ICONERROR);
      Exit;
    end;
  end;
  Result := True;
end;

procedure SaveInstance(HostWnd: HWND);
var
  Inst: TInstance;
  ActiveTab: Integer;
  ActiveKind: TTabContentKind;
  JsonEdit: HWND;
  Text, JsonBody: AnsiString;
  P: TJSONParser;
  D: TJSONData;
  Js: TJSONObject;
  SavedTabIdx: Integer;
begin
  Inst := FindInstance(HostWnd);
  if Inst = nil then Exit;
  if Inst.Tbl = nil then Exit;
  if not Inst.EditMode then
  begin
    // Defensive — Ctrl+S etc. should already have been blocked.
    MessageBeep(0);
    Exit;
  end;

  ActiveTab := GetActiveTabIndex(HostWnd);
  if ActiveTab < 0 then Exit;
  ActiveKind := GetTabKind(HostWnd, ActiveTab);

  // Path 1: active tab is a JSON edit. Parse it, run FromJSON,
  // then write. Edits in any grid tabs that the user has touched
  // are NOT reflected in the JSON tab's text (we don't auto-sync),
  // so saving from JSON means "the JSON is the source of truth".
  if ActiveKind = tcJSON then
  begin
    JsonEdit := GetJSONTabEditWnd(HostWnd);
    if JsonEdit = 0 then Exit;
    Text := GetViewerText(JsonEdit);
    if Text = '' then
    begin
      MessageBoxA(HostWnd, 'Nothing to save (empty document).',
                  'TBL Plugin', MB_ICONWARNING);
      Exit;
    end;
    JsonBody := StripHeaderComment(Text);
    if JsonBody = '' then
    begin
      MessageBoxA(HostWnd, 'JSON body is empty after stripping header.',
                  'TBL Plugin', MB_ICONWARNING);
      Exit;
    end;
    D := nil;
    try
      P := TJSONParser.Create(JsonBody, []);
      try
        D := P.Parse;
      finally P.Free; end;
    except
      on E: Exception do
      begin
        MessageBoxA(HostWnd,
          PAnsiChar('JSON parse error:' + #13#10 + E.Message),
          'TBL Plugin - cannot save', MB_ICONERROR);
        Exit;
      end;
    end;
    if not (D is TJSONObject) then
    begin
      if D <> nil then D.Free;
      MessageBoxA(HostWnd, 'JSON root is not an object - cannot save.',
                  'TBL Plugin', MB_ICONERROR);
      Exit;
    end;
    Js := TJSONObject(D);

    // Consistency check: the parsed JSON must have a "sections"
    // array whose length matches the original. We can't safely
    // round-trip a JSON whose structure has been truncated or
    // section-renamed — TBL writer needs the original schema/section
    // mapping. Reject early with a clear message instead of letting
    // FromJSON raise a deep error.
    if not ValidateJSONStructure(Js, Inst.Tbl, HostWnd) then
    begin
      Js.Free;
      Exit;
    end;

    try
      try
        Inst.Tbl.FromJSON(Js);
      except
        on E: Exception do
        begin
          MessageBoxA(HostWnd,
            PAnsiChar('FromJSON failed:' + #13#10 + E.Message),
            'TBL Plugin', MB_ICONERROR);
          Exit;
        end;
      end;
    finally
      Js.Free;
    end;
  end;
  // Path 2: active tab is a grid. Grid cell edits already updated
  // Inst.Tbl.Sections[i].Rows in place via SetCellText, so we just
  // write the file directly.

  try
    Inst.Tbl.WriteToFile(Inst.FilePath);
  except
    on E: Exception do
    begin
      MessageBoxA(HostWnd,
        PAnsiChar('Save failed:' + #13#10 + E.Message),
        'TBL Plugin', MB_ICONERROR);
      Exit;
    end;
  end;

  Inst.Dirty := False;

  // Re-sync all views from the model so JSON ↔ grid stay
  // consistent. After a JSON-save, the grid tabs need to reflect
  // the parsed JSON (Path 1 above replaced the model). After a
  // grid-save the JSON tab needs to reflect the latest scalar/array
  // edits (Path 2 only updated the grid). Cheapest correct way is
  // to tear down and rebuild every tab from the current Tbl, the
  // same path F2 reload uses.
  try
    SavedTabIdx := GetActiveTabIndex(HostWnd);
    ClearAllTabs(HostWnd);
    BuildTabsForInstance(HostWnd, Inst, GetSchemaDB);
    if (SavedTabIdx >= 0) then
      SetActiveTab(HostWnd, SavedTabIdx)
    else
      ShowFirstTab(HostWnd);
  except
    // If anything in the rebuild fails (very unusual — we just
    // wrote then re-read the same model), the file on disk is
    // already saved correctly, so we silently swallow.
    on E: Exception do
      MessageBoxA(HostWnd,
        PAnsiChar('Saved OK, but view refresh failed:' + #13#10 + E.Message),
        'TBL Plugin', MB_ICONWARNING);
  end;
end;

// ---------------------------------------------------------------------
//   ListLoad / ListLoadW — open a TBL, build the viewer window
// ---------------------------------------------------------------------

// Mark the file as dirty (called from grid edit commits AND from
// JSON Edit Ctrl+S — the latter is actually our save trigger; we
// special-case it inside SaveInstance which is the same callback).
//
// Wait: actually we have TWO different reasons to call back to the
// host:
//   - "user changed something"           (mark dirty)
//   - "user pressed Ctrl+S"              (save now)
// In viewerwin and tabwin we used a single TGridDirtyCallback for
// Ctrl+S. Grid cells edit-commits also need to mark dirty. We solve
// this by having two callbacks: one for save, one for dirty mark.
// To keep code paths simple we have the single-arg callback do both:
// SaveInstance is called both by Ctrl+S handlers and by grid cell
// commits. Inside it we always set dirty=true; if the call came
// from Ctrl+S, the JSON-edit Ctrl+S handler sets a flag we check
// before returning. Easier route: provide a tiny wrapper for the
// dirty-only path.
// Mark the file as dirty. May be called with either:
//   - the TabHost HWND (from the JSON tab's Ctrl+S handler — but
//     that path actually calls SaveInstance not MarkDirty)
//   - a grid HWND (when a grid cell is committed)
// We resolve to the registered TabHost by walking up the parent chain
// until FindInstance succeeds.
procedure MarkDirty(MaybeChildWnd: HWND);
var
  W: HWND;
  Inst: TInstance;
  Hops: Integer;
begin
  W := MaybeChildWnd;
  Hops := 0;
  while (W <> 0) and (Hops < 8) do
  begin
    Inst := FindInstance(W);
    if Inst <> nil then
    begin
      Inst.Dirty := True;
      Exit;
    end;
    W := GetParent(W);
    Inc(Hops);
  end;
end;

// Populate a tab-host with one tab per TBL section + a JSON tab.
// Caller is responsible for ensuring the host is empty (e.g. via
// ClearAllTabs before rebuilding for an F2 reload).
procedure BuildTabsForInstance(TabHost: HWND; Inst: TInstance; DB: TSchemaDB);
var
  i: Integer;
  Variant: TSchemaVariant;
  Cols: TGridColumnArray;
  TabCaption: AnsiString;
  Json: AnsiString;
begin
  Json := BuildJSONView(Inst.Tbl);
  Inst.JsonText := Json;
  for i := 0 to High(Inst.Tbl.Sections) do
  begin
    TabCaption := Inst.Tbl.Sections[i].Name;
    TabCaption := TabCaption + Format(' [%d]', [i]);
    if Inst.Tbl.Sections[i].Mode = smDecoded then
    begin
      if DB.FindVariant(Inst.Tbl.Sections[i].Name,
                        Inst.Tbl.Sections[i].EntryLength,
                        Inst.Tbl.Sections[i].GameTag, Variant) then
      begin
        Cols := BuildColumns(Variant.Fields);
        AddGridTab(TabHost, TabCaption, Cols,
                   Inst.Tbl.Sections[i].Rows);
      end
      else
        AddJSONTab(TabHost, TabCaption,
          '// Section "' + Inst.Tbl.Sections[i].Name +
          '" decoded but no schema variant available' + #10);
    end
    else
      AddJSONTab(TabHost, TabCaption,
        '// Section "' + Inst.Tbl.Sections[i].Name +
        '" is in raw passthrough mode — no schema match.' + #10 +
        '// Bytes: ' + IntToStr(Length(Inst.Tbl.Sections[i].RawBytes)) + #10);
  end;
  AddJSONTab(TabHost, 'JSON', Json);
  AddConfigTab(TabHost, 'Config');
end;

function DoListLoad(ParentWnd: HWND; const FilePath: AnsiString;
                   ShowFlags: Integer): HWND;
var
  Inst: TInstance;
  TabHost: HWND;
  DB: TSchemaDB;
begin
  Result := 0;
  EnsureGlobalsInit;
  DB := GetSchemaDB;
  if DB = nil then Exit;

  TabHost := CreateTabHost(ParentWnd, @MarkDirty, @SaveInstance);
  if TabHost = 0 then Exit;

  // Wire the "Export current TBL as JSON" Config-tab button to our
  // ExportCurrentJSON proc. Module-global, so registering once would
  // suffice — but it's cheap to do on every load and we don't have
  // a one-time init hook.
  tabwin.SetExportJSONCallback(@ExportCurrentJSON);
  // Register the JSON ↔ grid sync handler for tab switches.
  tabwin.SetBeforeTabSwitchCallback(@BeforeTabSwitchSync);

  Inst := TInstance.Create;
  Inst.HostWnd       := TabHost;
  Inst.EditWnd       := 0;
  Inst.FilePath      := FilePath;
  Inst.Mode          := vmGrid;
  Inst.Dirty         := False;
  Inst.GridSectionIdx := 0;

  try
    Inst.Tbl := TTBLFile.Create(DB);
    Inst.Tbl.ReadFromFile(FilePath, GetPreferredGame);
    BuildTabsForInstance(TabHost, Inst, DB);
    ShowFirstTab(TabHost);
  except
    on E: Exception do
    begin
      AddJSONTab(TabHost, 'Error',
        '// Could not parse this file as #TBL.' + #10 +
        '// ' + E.ClassName + ': ' + E.Message + #10);
      ShowFirstTab(TabHost);
      Inst.JsonText := '';
    end;
  end;

  RegisterInstance(TabHost, Inst);

  // Initial mode strip text (depends on EditMode flag we just set
  // from the INI default).
  tabwin.ApplyEditModeUI(TabHost);

  // Defer window-state apply until after we return from ListLoad.
  // Calling ShowWindow/SetWindowPos on TC's Lister parent *during*
  // ListLoad reentrantly fires WM_SHOWWINDOW into TC while it's
  // still in the middle of its plugin-loading state machine, which
  // can crash TC outright (observed on first F3 of a session). The
  // 100ms timer in SchedulePostLoadWindowApply lets TC settle first.
  tabwin.SchedulePostLoadWindowApply(TabHost);

  Result := TabHost;
end;

function ListLoad(ParentWnd: HWND; FileToLoad: PAnsiChar;
                  ShowFlags: Integer): HWND; stdcall;
begin
  Result := 0;
  if FileToLoad = nil then Exit;
  // Wrap the entire load in try/except: an unhandled Pascal
  // exception travelling across the DLL/host boundary would crash
  // Lister. Returning 0 instead lets TC fall back to its default
  // viewer.
  try
    Result := DoListLoad(ParentWnd, AnsiString(FileToLoad), ShowFlags);
  except
    on E: Exception do
      Result := 0;
  end;
end;

function ListLoadW(ParentWnd: HWND; FileToLoad: PWideChar;
                   ShowFlags: Integer): HWND; stdcall;
var
  WS: WideString;
  AS_: AnsiString;
begin
  Result := 0;
  if FileToLoad = nil then Exit;
  try
    WS := WideString(FileToLoad);
    AS_ := AnsiString(WS);
    Result := DoListLoad(ParentWnd, AS_, ShowFlags);
  except
    on E: Exception do
      Result := 0;
  end;
end;

// ---------------------------------------------------------------------
//   ListSendCommand
// ---------------------------------------------------------------------

function ListSendCommand(ListWin: HWND; Command: Integer;
                         Parameter: Integer): Integer; stdcall;
var
  Inst: TInstance;
begin
  Result := LISTPLUGIN_ERROR;
  try
    Inst := FindInstance(ListWin);
    if Inst = nil then Exit;

    case Command of
    LCMD_RELOAD:
      begin
        // F2 in Lister: re-read the file from disk and rebuild all
        // tabs. Any unsaved grid edits in memory are lost (they're
        // tied to the old TJSONArray instances which we replace).
        // The user is offered a save prompt first if dirty.
        if Inst.FilePath = '' then Exit;
        if Inst.Dirty then
        begin
          if MessageBoxA(ListWin,
              'Reload will discard unsaved changes. Continue?',
              'TBL Plugin — reload', MB_YESNO or MB_ICONWARNING) <> IDYES then
            Exit;
        end;
        try
          ClearAllTabs(ListWin);
          if Inst.Tbl <> nil then FreeAndNil(Inst.Tbl);
          Inst.Tbl := TTBLFile.Create(GetSchemaDB);
          Inst.Tbl.ReadFromFile(Inst.FilePath, GetPreferredGame);
          BuildTabsForInstance(ListWin, Inst, GetSchemaDB);
          ShowFirstTab(ListWin);
          Inst.Dirty := False;
          Inst.LastSearchPos := 0;
          Result := LISTPLUGIN_OK;
        except
          on E: Exception do
            MessageBoxA(ListWin,
              PAnsiChar('Reload failed:' + #13#10 + E.Message),
              'TBL Plugin', MB_ICONERROR);
        end;
      end;
    LCMD_SELECTALL:
      begin
        // If the JSON tab is active, select all in its Edit.
        // Grid-tab "select all" is uncommon; we ignore for v1.
        if (GetActiveTabIndex(ListWin) >= 0) and
           (GetTabKind(ListWin, GetActiveTabIndex(ListWin)) = tcJSON) then
        begin
          ViewerSelectAll(GetJSONTabEditWnd(ListWin));
          Result := LISTPLUGIN_OK;
        end;
      end;
    LCMD_NEWPARAMS,
    LCMD_QUICKVIEW:
      begin
        Result := LISTPLUGIN_OK;
      end;
    end;
  except
    // Any unexpected exception → ERROR result, never re-thrown
    on E: Exception do Result := LISTPLUGIN_ERROR;
  end;
end;

// ---------------------------------------------------------------------
//   ListSearchText / ListSearchTextW
// ---------------------------------------------------------------------

function DoSearch(ListWin: HWND; const Needle: AnsiString;
                  SearchParam: Integer): Integer;
var
  Inst: TInstance;
  MatchCase, Backwards, FindFirst, NeedleChanged: Boolean;
  StartPos: Integer;
  JsonEdit, Grid, ActiveChild: HWND;
  ActiveTab, NumTabs, SearchRow, SearchCol: Integer;
  ActiveKind: TTabContentKind;
begin
  Result := LISTPLUGIN_ERROR;
  Inst := FindInstance(ListWin);
  if Inst = nil then Exit;

  MatchCase := (SearchParam and lcs_matchcase) <> 0;
  Backwards := (SearchParam and lcs_backwards) <> 0;
  FindFirst := (SearchParam and lcs_findfirst) <> 0;
  NeedleChanged := (Needle <> Inst.GridSearchNeedle);

  // For grid search we always search forward — TC's lcs_backwards
  // makes more sense for text, less for tabular data. JSON tab
  // path honors Backwards as before.

  // Reset cursors when a new search starts.
  if FindFirst or NeedleChanged then
  begin
    Inst.LastSearchPos := 0;
    Inst.GridSearchTab := -1;
    Inst.GridSearchRow := 0;
    Inst.GridSearchCol := 0;
    Inst.GridSearchNeedle := Needle;
  end;

  ActiveTab := GetActiveTabIndex(ListWin);
  NumTabs := GetTabCount(ListWin);
  if NumTabs = 0 then Exit;

  ActiveKind := GetTabKind(ListWin, ActiveTab);

  // ---- Path A: active tab is JSON, and either we're starting a new
  // search there OR we're continuing inside it. Use ViewerFind. ----
  if (ActiveKind = tcJSON) and (Inst.GridSearchTab < 0) then
  begin
    JsonEdit := GetTabChild(ListWin, ActiveTab);
    if JsonEdit = 0 then Exit;
    if Inst.LastSearchPos = 0 then Inst.LastSearchPos := 1;
    StartPos := Inst.LastSearchPos;
    if StartPos < 1 then StartPos := 1;
    if ViewerFind(JsonEdit, Needle, StartPos, MatchCase, Backwards) then
    begin
      Inst.LastSearchPos := StartPos;
      Inst.GridSearchTab := ActiveTab;   // remember we hit on JSON
      Inst.GridSearchRow := 0;
      Inst.GridSearchCol := 0;
      Result := LISTPLUGIN_OK;
    end
    else
    begin
      Inst.LastSearchPos := 0;
      Inst.GridSearchTab := -1;
      Result := LISTPLUGIN_ERROR;
    end;
    Exit;
  end;

  // ---- Path B: scan only the active tab. We deliberately don't wrap
  // through other tabs anymore — search is scoped to whatever the
  // user is currently looking at. This matches what the typical
  // "find" user expects: stay in this view. ----
  ActiveChild := GetTabChild(ListWin, ActiveTab);
  if ActiveChild = 0 then Exit;
  if ActiveKind = tcGrid then
  begin
    Grid := ActiveChild;
    SearchRow := Inst.GridSearchRow;
    SearchCol := Inst.GridSearchCol;
    if GridSearchText(Grid, Needle, MatchCase, SearchRow, SearchCol) then
    begin
      Inst.GridSearchTab := ActiveTab;
      Inst.GridSearchRow := SearchRow;
      Inst.GridSearchCol := SearchCol;
      Result := LISTPLUGIN_OK;
      Exit;
    end;
  end
  else if ActiveKind = tcJSON then
  begin
    // JSON tab path. We already handled it above when GridSearchTab<0
    // (Path A), but we may also reach here when the user changes
    // tabs between hits. Do a fresh ViewerFind from the top.
    JsonEdit := ActiveChild;
    StartPos := 1;
    if ViewerFind(JsonEdit, Needle, StartPos, MatchCase, Backwards) then
    begin
      Inst.GridSearchTab := ActiveTab;
      Inst.LastSearchPos := StartPos;
      Inst.GridSearchRow := 0;
      Inst.GridSearchCol := 0;
      Result := LISTPLUGIN_OK;
      Exit;
    end;
  end;

  // No hits in this tab; reset cursors so the next F3 starts fresh.
  Inst.GridSearchTab := -1;
  Inst.GridSearchRow := 0;
  Inst.GridSearchCol := 0;
  Inst.LastSearchPos := 0;
  Result := LISTPLUGIN_ERROR;
end;

function ListSearchText(ListWin: HWND; SearchString: PAnsiChar;
                        SearchParameter: Integer): Integer; stdcall;
begin
  Result := LISTPLUGIN_ERROR;
  if SearchString = nil then Exit;
  try
    Result := DoSearch(ListWin, AnsiString(SearchString), SearchParameter);
  except
    Result := LISTPLUGIN_ERROR;
  end;
end;

function ListSearchTextW(ListWin: HWND; SearchString: PWideChar;
                         SearchParameter: Integer): Integer; stdcall;
var WS: WideString; AS_: AnsiString;
begin
  Result := LISTPLUGIN_ERROR;
  if SearchString = nil then Exit;
  try
    WS := WideString(SearchString);
    AS_ := AnsiString(WS);
    Result := DoSearch(ListWin, AS_, SearchParameter);
  except
    Result := LISTPLUGIN_ERROR;
  end;
end;

// ---------------------------------------------------------------------
//   ListCloseWindow
// ---------------------------------------------------------------------

procedure ListCloseWindow(ListWin: HWND); stdcall;
var
  Inst: TInstance;
  Resp: Integer;
  IniPath: AnsiString;
begin
  if ListWin = 0 then Exit;
  // Wrap cleanup in try/except so a single corrupt instance can't
  // wedge TC's Lister teardown — we'd rather leak some memory than
  // crash the host on close.
  try
    Inst := FindInstance(ListWin);
    if (Inst <> nil) and Inst.Dirty and Inst.EditMode then
    begin
      Resp := MessageBoxA(ListWin,
        'The TBL file has unsaved changes. Save before closing?',
        'TBL Plugin', MB_YESNO or MB_ICONQUESTION);
      if Resp = IDYES then
        SaveInstance(ListWin);
    end;

    // Snapshot window state into INI memory (and flush to disk)
    // *before* TC tears the window down. We only persist when
    // RememberWindowSize is enabled — if the user disabled it,
    // we don't want to overwrite previously-saved good values.
    if inisettings.GetRememberWindowSize then
    begin
      try
        tabwin.CaptureWindowStateOnClose(ListWin);
        IniPath := pluginstate.GetIniPath;
        if IniPath <> '' then inisettings.SaveINI(IniPath);
      except end;
    end;

    // Tear down our state BEFORE destroying the window. Order matters:
    // ClearAllTabs unsubclasses + destroys all grid/edit children
    // while our state is still attached, so any messages they receive
    // during teardown route through our nil-state fallback paths.
    if Inst <> nil then
    begin
      try
        ClearAllTabs(ListWin);
      except end;
      try
        DestroyTabHostState(ListWin);
      except end;
    end;
    // Now destroy the host. Guard with IsWindow in case TC has
    // already destroyed it (some TC paths do that defensively).
    if IsWindow(ListWin) then
      DestroyWindow(ListWin);
    UnregisterInstance(ListWin);
  except
    // Swallow.
  end;
end;

// ---------------------------------------------------------------------
//   ListGetDetectString
//
// TC uses this string to decide which files we can handle. We claim
// only .tbl files (by extension) plus files whose first bytes are an
// exact match for one of our magic headers:
//   "#TBL"  (plain)         — bytes 35, 84, 66, 76  ('#','T','B','L')
//   F9 BA … (CLE encrypted) — bytes 249, 186
//   D9 BA … (CLE encrypted+compressed) — bytes 217, 186
// We deliberately do NOT use FIND() here — FIND scans the first 8 KB
// of the file and would mis-detect any random text file (.md, .ini,
// etc.) that happens to mention "#TBL" anywhere in its content.
// ---------------------------------------------------------------------

procedure ListGetDetectString(DetectString: PAnsiChar;
                              maxlen: Integer); stdcall;
const
  DETECT: AnsiString =
    'EXT="TBL" | ([0]=35 & [1]=84 & [2]=66 & [3]=76)' +
    ' | ([0]=249 & [1]=186) | ([0]=217 & [1]=186)';
begin
  try
    CopyToBuf(DetectString, maxlen, DETECT);
  except
    if (DetectString <> nil) and (maxlen > 0) then DetectString[0] := #0;
  end;
end;

// ---------------------------------------------------------------------
//   ListSetDefaultParams — receive INI path on first load
// ---------------------------------------------------------------------

procedure ListSetDefaultParams(dps: PListDefaultParamStruct); stdcall;
var
  IniPath: AnsiString;
begin
  try
    if (dps = nil) or (dps^.Size < LISTDEFAULTPARAMS_DEFAULT_SIZE) then Exit;
    IniPath := AnsiString(StrPas(dps^.DefaultIniName));
    SetIniPath(IniPath);  // also loads PreferredGame from the INI
  except
    // Bad pointer or other surprise — stay default-empty.
  end;
end;

// ---------------------------------------------------------------------
//   Stubs: notification, search dialog, print
// ---------------------------------------------------------------------

procedure ListNotificationReceived(ListWin: HWND; Message_: Integer;
                                   wParam: WPARAM; lParam: LPARAM); stdcall;
begin
  // No-op (and exception-safe by being empty).
end;

function ListSearchDialog(ListWin: HWND; FindNext: Integer): Integer; stdcall;
begin
  // We let TC use its built-in F7 dialog (returns LISTPLUGIN_ERROR
  // means "use default"). Plugin authors who need a custom dialog
  // can return LISTPLUGIN_OK after running their own UI.
  Result := LISTPLUGIN_ERROR;
end;

function ListPrint(ListWin: HWND; FileToPrint, DefPrinter: PAnsiChar;
                   PrintFlags: Integer; Margins: PRect): Integer; stdcall;
begin
  // No printing in v1.
  Result := LISTPLUGIN_ERROR;
end;

// ---------------------------------------------------------------------
//   Exports
// ---------------------------------------------------------------------

exports
  ListLoad,
  ListLoadW,
  ListSendCommand,
  ListCloseWindow,
  ListGetDetectString,
  ListSearchText,
  ListSearchTextW,
  ListSearchDialog,
  ListPrint,
  ListSetDefaultParams,
  ListNotificationReceived;

begin
  // Legacy: viewerwin.SetSaveCallback exists for the single-Edit
  // viewer architecture (no longer used by ListLoad). We register
  // here for safety in case some code path falls back to that.
  SetSaveCallback(@SaveInstance);
end.
