unit tblschemas;
{$mode objfpc}{$H+}

// Schema database for the TBL plugin. Loads everything from a
// `schemas/` directory that mirrors KuroTools' layout:
//
//   schemas/
//     t_dlc.json                   -> {"headers": ["DLCTableData", ...]}
//     t_item.json                  -> {"headers": ["ItemTableData", ...]}
//     t_npc_c%d%d%d%d.json         -> filename template (digit-wildcards)
//     headers/
//       DLCTableData.json          -> {"FALCOM_PS4": {"game":"Kuro1", ...},
//                                      "CLE_PC":     {"game":"Kuro2", ...}}
//       ItemTableData.json
//
// The plugin fetches a schema in two steps:
//
//   1. Take the TBL filename (without .tbl). Replace each ASCII digit
//      with "%d". Look for matching `schemas/<that>.json`. If present,
//      its `headers` array tells us which header *names* are expected
//      to live in this TBL — but not their layout.
//
//   2. For each header name encountered while parsing the TBL, look in
//      `schemas/headers/<HeaderName>.json`. That file lists every
//      known game/platform variant for that header along with field
//      definitions and total byte size. Match the variant whose size
//      equals the on-disk entry_length. If multiple variants tie, the
//      caller-supplied "preferred game" wins (or the first match if
//      no preference).
//
// The schema files are read into memory once and cached; lookups by
// header name are O(1).

interface

uses Classes, SysUtils, fpjson, jsonparser, tbltypes;

type
  // One game/platform variant of a single header.
  TSchemaVariant = record
    PlatformKey: AnsiString;     // 'FALCOM_PS4', 'CLE_PC', 'NISA_PC', ...
    GameTag:     AnsiString;     // 'Kuro1', 'Kuro2', 'Sora1', 'Ys_X' (informational)
    Size:        Integer;        // byte size of one row (= sum of field sizes)
    Fields:      TFieldList;     // owned by the schema cache
  end;
  TSchemaVariantArray = array of TSchemaVariant;

  // All known variants for one header name.
  TSchemaHeader = class
  private
    FName: AnsiString;
    FVariants: TSchemaVariantArray;
  public
    destructor Destroy; override;
    property Name: AnsiString read FName;
    property Variants: TSchemaVariantArray read FVariants;
  end;

  // Top-level container of every loaded schema.
  TSchemaDB = class
  private
    FHeaders:        TStringList;        // owns TSchemaHeader values, sorted by name
    FTblHeaderLists: TStringList;        // file-pattern -> TStringList of header names
    function GetOrCreateHeader(const Name: AnsiString): TSchemaHeader;
  public
    constructor Create;
    destructor Destroy; override;

    // Scan a `schemas/` directory and load everything inside it.
    // Errors are accumulated in Errors (caller-owned) but loading
    // continues; partial schemas are usable.
    procedure LoadFromDir(const Dir: AnsiString; Errors: TStrings);

    // Find header schema by exact name. nil if unknown.
    function FindHeader(const Name: AnsiString): TSchemaHeader;

    // Find one specific variant of a header by entry length, with an
    // optional preferred game tag. Returns False if none of the
    // variants match Length.
    function FindVariant(const HeaderName: AnsiString;
                         EntryLength: Integer;
                         const PreferGame: AnsiString;
                         out V: TSchemaVariant): Boolean;

    // Look up the list of headers expected in a TBL file given its
    // filename (with or without .tbl extension). Returns nil if no
    // schema file matches.
    function FindTblHeaders(const TblFileName: AnsiString): TStringList;

    // Cosmetic stats — used by tests.
    function HeaderCount: Integer;
    function VariantCount: Integer;
  end;

implementation

// ---------------------------------------------------------------------
//   Local helpers — ReadFile, dedup-aware JSON parse
// ---------------------------------------------------------------------

function ReadFileAll(const Path: AnsiString): AnsiString;
var FS: TFileStream; L: Int64;
begin
  Result := '';
  FS := TFileStream.Create(Path, fmOpenRead or fmShareDenyWrite);
  try
    L := FS.Size;
    SetLength(Result, L);
    if L > 0 then FS.ReadBuffer(Result[1], L);
  finally FS.Free; end;
end;

// Pre-process JSON text to handle duplicate object keys. Some KuroTools
// schema files have the same platform key listed twice (e.g.
// ConditionInfoTableData.json has two FALCOM_PS4 entries). Python's
// json.load silently keeps the LAST one; FPC's parser raises by
// default. We rename later occurrences to "<name>__dupN" so the JSON
// is parseable, and the schema layer treats them as additional
// variants (caller may still need them when doing entry-length
// auto-detection).
function DedupJSONKeys(const Src: AnsiString): AnsiString;
type
  TLevel = record Names: TStringList; end;
var
  Out_: AnsiString;
  i, n, depth: Integer;
  ch: AnsiChar;
  InString, ExpectingKey: Boolean;
  Levels: array of TLevel;
  CurStr, NewKey: AnsiString;
  StartIdx, DupCounter, k: Integer;
begin
  Out_ := '';
  n := Length(Src);
  i := 1;
  depth := 0;
  InString := False;
  ExpectingKey := False;
  StartIdx := 0;
  SetLength(Levels, 16);
  for k := 0 to High(Levels) do Levels[k].Names := nil;

  while i <= n do
  begin
    ch := Src[i];
    if InString then
    begin
      if ch = '\' then
      begin
        Out_ := Out_ + ch;
        Inc(i);
        if i <= n then
        begin
          Out_ := Out_ + Src[i];
          Inc(i);
        end;
        Continue;
      end;
      if ch = '"' then
      begin
        InString := False;
        if ExpectingKey then
        begin
          CurStr := Copy(Out_, StartIdx + 1, Length(Out_) - StartIdx);
          if Levels[depth].Names = nil then
            Levels[depth].Names := TStringList.Create;
          DupCounter := 0;
          NewKey := CurStr;
          while Levels[depth].Names.IndexOf(NewKey) >= 0 do
          begin
            Inc(DupCounter);
            NewKey := CurStr + '__dup' + IntToStr(DupCounter);
          end;
          Levels[depth].Names.Add(NewKey);
          if NewKey <> CurStr then
          begin
            SetLength(Out_, StartIdx);
            Out_ := Out_ + NewKey;
          end;
          ExpectingKey := False;
        end;
        Out_ := Out_ + ch;
        Inc(i);
        Continue;
      end;
      Out_ := Out_ + ch;
      Inc(i);
      Continue;
    end;
    case ch of
      '"': begin
        InString := True;
        if ExpectingKey then StartIdx := Length(Out_) + 1;
        Out_ := Out_ + ch;
        Inc(i);
      end;
      '{': begin
        Inc(depth);
        if depth >= Length(Levels) then
          SetLength(Levels, Length(Levels) * 2);
        if Levels[depth].Names <> nil then Levels[depth].Names.Clear
        else Levels[depth].Names := TStringList.Create;
        ExpectingKey := True;
        Out_ := Out_ + ch;
        Inc(i);
      end;
      '}': begin
        if (depth >= 0) and (depth < Length(Levels)) and
           (Levels[depth].Names <> nil) then
          Levels[depth].Names.Clear;
        Dec(depth);
        ExpectingKey := False;
        Out_ := Out_ + ch;
        Inc(i);
      end;
      '[': begin
        Inc(depth);
        if depth >= Length(Levels) then
          SetLength(Levels, Length(Levels) * 2);
        if Levels[depth].Names <> nil then Levels[depth].Names.Clear
        else Levels[depth].Names := TStringList.Create;
        ExpectingKey := False;
        Out_ := Out_ + ch;
        Inc(i);
      end;
      ']': begin
        if (depth < Length(Levels)) and (Levels[depth].Names <> nil) then
          Levels[depth].Names.Clear;
        Dec(depth);
        ExpectingKey := False;
        Out_ := Out_ + ch;
        Inc(i);
      end;
      ',': begin
        if (depth >= 0) and (depth < Length(Levels)) and
           (Levels[depth].Names <> nil) and
           (Levels[depth].Names.Count > 0) then
          ExpectingKey := True
        else
          ExpectingKey := False;
        Out_ := Out_ + ch;
        Inc(i);
      end;
      ':': begin
        ExpectingKey := False;
        Out_ := Out_ + ch;
        Inc(i);
      end;
    else
      Out_ := Out_ + ch;
      Inc(i);
    end;
  end;

  for k := 0 to High(Levels) do
    if Levels[k].Names <> nil then Levels[k].Names.Free;
  Result := Out_;
end;

function ParseJSON(const Path: AnsiString): TJSONData;
var Raw: AnsiString;
begin
  Raw := ReadFileAll(Path);
  Raw := DedupJSONKeys(Raw);
  Result := GetJSON(Raw);
end;

// ---------------------------------------------------------------------
//   TSchemaHeader
// ---------------------------------------------------------------------

destructor TSchemaHeader.Destroy;
var i: Integer;
begin
  for i := 0 to High(FVariants) do
    if FVariants[i].Fields <> nil then
      FVariants[i].Fields.Free;
  inherited;
end;

// ---------------------------------------------------------------------
//   TSchemaDB
// ---------------------------------------------------------------------

constructor TSchemaDB.Create;
begin
  inherited;
  FHeaders := TStringList.Create;
  FHeaders.OwnsObjects := True;
  FHeaders.Sorted := True;
  FHeaders.Duplicates := dupIgnore;
  FHeaders.CaseSensitive := True;

  FTblHeaderLists := TStringList.Create;
  FTblHeaderLists.OwnsObjects := True;
  FTblHeaderLists.Sorted := True;
  FTblHeaderLists.Duplicates := dupIgnore;
  FTblHeaderLists.CaseSensitive := False;
end;

destructor TSchemaDB.Destroy;
begin
  FHeaders.Free;
  FTblHeaderLists.Free;
  inherited;
end;

function TSchemaDB.GetOrCreateHeader(const Name: AnsiString): TSchemaHeader;
var Idx: Integer;
begin
  Idx := FHeaders.IndexOf(Name);
  if Idx >= 0 then
    Result := TSchemaHeader(FHeaders.Objects[Idx])
  else
  begin
    Result := TSchemaHeader.Create;
    Result.FName := Name;
    FHeaders.AddObject(Name, Result);
  end;
end;

procedure TSchemaDB.LoadFromDir(const Dir: AnsiString; Errors: TStrings);
var
  SR: TSearchRec;
  Path, BaseName, HeaderDir: AnsiString;
  Root, GameDef, SchemaObj: TJSONData;
  TopObj: TJSONObject;
  GamePlatformKey, GameTag: AnsiString;
  i, p: Integer;
  Hdr: TSchemaHeader;
  V: TSchemaVariant;
  HeadersArr: TJSONArray;
  HdrNames: TStringList;
  RealKey: AnsiString;
begin
  // 1) Load t_*.json files at top of dir — header-name lists
  if FindFirst(IncludeTrailingPathDelimiter(Dir) + '*.json',
               faAnyFile and not faDirectory, SR) = 0 then
  begin
    repeat
      Path := IncludeTrailingPathDelimiter(Dir) + SR.Name;
      BaseName := ChangeFileExt(SR.Name, '');
      try
        Root := ParseJSON(Path);
        try
          if Root is TJSONObject then
          begin
            HeadersArr := TJSONObject(Root).Get('headers', TJSONArray(nil));
            if HeadersArr <> nil then
            begin
              HdrNames := TStringList.Create;
              HdrNames.CaseSensitive := True;
              for i := 0 to HeadersArr.Count - 1 do
                if HeadersArr.Items[i] is TJSONString then
                  HdrNames.Add(HeadersArr.Items[i].AsString);
              FTblHeaderLists.AddObject(BaseName, HdrNames);
            end;
          end;
        finally Root.Free; end;
      except
        on E: Exception do
          if Errors <> nil then
            Errors.Add(Format('%s: %s', [SR.Name, E.Message]));
      end;
    until FindNext(SR) <> 0;
    FindClose(SR);
  end;

  // 2) Load headers/*.json — actual field schemas
  HeaderDir := IncludeTrailingPathDelimiter(Dir) + 'headers';
  if not DirectoryExists(HeaderDir) then
    Exit;

  if FindFirst(IncludeTrailingPathDelimiter(HeaderDir) + '*.json',
               faAnyFile and not faDirectory, SR) = 0 then
  begin
    repeat
      Path := IncludeTrailingPathDelimiter(HeaderDir) + SR.Name;
      BaseName := ChangeFileExt(SR.Name, '');  // header name
      try
        Root := ParseJSON(Path);
        try
          if not (Root is TJSONObject) then
          begin
            if Errors <> nil then
              Errors.Add(Format('%s: top-level JSON not an object', [SR.Name]));
            Continue;
          end;
          TopObj := TJSONObject(Root);
          Hdr := GetOrCreateHeader(BaseName);
          for i := 0 to TopObj.Count - 1 do
          begin
            GamePlatformKey := TopObj.Names[i];
            // Strip __dupN to recover canonical platform name
            p := Pos('__dup', GamePlatformKey);
            if p > 0 then RealKey := Copy(GamePlatformKey, 1, p - 1)
            else          RealKey := GamePlatformKey;

            if not (TopObj.Items[i] is TJSONObject) then Continue;
            GameDef := TopObj.Items[i];
            GameTag := TJSONObject(GameDef).Get('game', '');
            SchemaObj := TJSONObject(GameDef).Find('schema');
            if not (SchemaObj is TJSONObject) then Continue;

            V := Default(TSchemaVariant);
            V.PlatformKey := RealKey;
            V.GameTag := GameTag;
            try
              V.Fields := ParseFieldList(TJSONObject(SchemaObj));
              V.Size := FieldListSize(V.Fields);
              SetLength(Hdr.FVariants, Length(Hdr.FVariants) + 1);
              Hdr.FVariants[High(Hdr.FVariants)] := V;
            except
              on EX: Exception do
                if Errors <> nil then
                  Errors.Add(Format('%s [%s]: %s',
                                    [SR.Name, RealKey, EX.Message]));
            end;
          end;
        finally Root.Free; end;
      except
        on E: Exception do
          if Errors <> nil then
            Errors.Add(Format('%s: %s', [SR.Name, E.Message]));
      end;
    until FindNext(SR) <> 0;
    FindClose(SR);
  end;
end;

function TSchemaDB.FindHeader(const Name: AnsiString): TSchemaHeader;
var Idx: Integer;
begin
  Idx := FHeaders.IndexOf(Name);
  if Idx >= 0 then
    Result := TSchemaHeader(FHeaders.Objects[Idx])
  else
    Result := nil;
end;

function TSchemaDB.FindVariant(const HeaderName: AnsiString;
                               EntryLength: Integer;
                               const PreferGame: AnsiString;
                               out V: TSchemaVariant): Boolean;
var
  Hdr: TSchemaHeader;
  i, FirstMatch: Integer;
begin
  Result := False;
  V := Default(TSchemaVariant);
  Hdr := FindHeader(HeaderName);
  if Hdr = nil then Exit;
  FirstMatch := -1;
  for i := 0 to High(Hdr.Variants) do
  begin
    if Hdr.Variants[i].Size <> EntryLength then Continue;
    // Preferred game wins over any other size-matching variant
    if (PreferGame <> '') and (Hdr.Variants[i].GameTag = PreferGame) then
    begin
      V := Hdr.Variants[i];
      Result := True;
      Exit;
    end;
    if FirstMatch < 0 then FirstMatch := i;
  end;
  if FirstMatch >= 0 then
  begin
    V := Hdr.Variants[FirstMatch];
    Result := True;
  end;
end;

// Return list of header names expected in a TBL file. The file name
// is normalized by replacing each ASCII digit with '%d' (matching
// KuroTools' Python regex r"\d" -> "%d") before lookup.
function TSchemaDB.FindTblHeaders(const TblFileName: AnsiString): TStringList;
var
  Stem, Norm: AnsiString;
  i, Idx: Integer;
  ch: AnsiChar;
begin
  Result := nil;
  Stem := ChangeFileExt(ExtractFileName(TblFileName), '');
  // Replace each digit with '%d'
  Norm := '';
  for i := 1 to Length(Stem) do
  begin
    ch := Stem[i];
    if (ch >= '0') and (ch <= '9') then Norm := Norm + '%d'
    else Norm := Norm + ch;
  end;
  Idx := FTblHeaderLists.IndexOf(Norm);
  if Idx >= 0 then
    Result := TStringList(FTblHeaderLists.Objects[Idx])
  else
  begin
    // Try the unnormalized stem too (some schemas don't have digits)
    Idx := FTblHeaderLists.IndexOf(Stem);
    if Idx >= 0 then
      Result := TStringList(FTblHeaderLists.Objects[Idx]);
  end;
end;

function TSchemaDB.HeaderCount: Integer;
begin
  Result := FHeaders.Count;
end;

function TSchemaDB.VariantCount: Integer;
var i: Integer;
begin
  Result := 0;
  for i := 0 to FHeaders.Count - 1 do
    Inc(Result, Length(TSchemaHeader(FHeaders.Objects[i]).Variants));
end;

end.
