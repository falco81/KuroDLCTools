unit gridmodel;
{$mode objfpc}{$H+}

// Convert a TBL section schema into a column list for a grid view.
//
// The TBL type system has 14 primitive scalar types plus arrays plus
// nested struct dicts. For a grid we want columns. For each column we
// remember:
//
//   - DisplayName: what to show in the header
//   - JsonPath:    how to fetch and store the value
//   - Kind:        scalar / string / array (read-only summary) /
//                  nested-summary (opens a sub-grid on dblclick)
//
// Nested struct fields are NOT expanded inline. They get a single
// summary column showing "[<count> items]" and a dblclick on that
// cell pops up a separate grid window (a sub-grid) on those rows.

interface

uses
  Classes, SysUtils, fpjson,
  tbltypes;

type
  TColumnKind = (
    ckScalar,         // primitive number / float
    ckString,         // toffset string
    ckArray,          // u8/u16/u32 array — shown as [a,b,c]
    ckNestedSummary   // nested struct — opens sub-grid on dblclick
  );

  TGridColumn = record
    DisplayName: AnsiString;     // e.g. "id"
    JsonPath:    AnsiString;     // top-level field name
    Kind:        TColumnKind;
    BaseKind:    TTBLBaseKind;          // primitive type at the leaf
    NestedFT:    TTBLDataType;          // tbkNested type, valid for ckNestedSummary
    Width:       Integer;               // suggested grid column width in pixels
  end;
  TGridColumnArray = array of TGridColumn;

// Build the column list for a top-level section. Each schema field
// becomes exactly one column. Nested struct fields get a summary
// column with their TFieldList referenced via NestedFT for sub-grid
// rendering.
function BuildColumns(Fields: TFieldList): TGridColumnArray;

// Build columns for a sub-grid: one row per element of the nested
// array, columns derived from the nested TFieldList. The nested
// fields are scalars only by current schema convention (no nested-
// of-nested in any KuroTools schema), but if any do appear they get
// rendered as another ckNestedSummary that can recurse.
function BuildNestedColumns(Inner: TFieldList): TGridColumnArray;

// Read the cell value for column Col from a row JSON object. Returns
// '' for missing fields. For arrays returns "[v1, v2, ...]"; for
// strings the string itself; for numbers IntToStr / FloatToStr; for
// nested-summary "[N rows]".
function GetCellText(Row: TJSONObject; const Col: TGridColumn): AnsiString;

// Write a textual edit back into the row JSON object. Returns False
// if the input couldn't be parsed for the column's type. Arrays and
// nested-summary cells are read-only via this entry — those use
// dedicated sub-grid editing.
function SetCellText(Row: TJSONObject; const Col: TGridColumn;
                     const NewText: AnsiString): Boolean;

// Get the JSON array of nested rows for a ckNestedSummary cell.
// Returns nil if the field is missing or not an array. Used by the
// sub-grid editor to bind to live data.
function GetNestedArray(Row: TJSONObject; const Col: TGridColumn): TJSONArray;

implementation

// ---------------------------------------------------------------------
//   Internal helpers
// ---------------------------------------------------------------------

function PrimSuggestedWidth(Kind: TTBLBaseKind): Integer;
begin
  case Kind of
    tbkByte, tbkUByte:                       Result := 50;
    tbkShort, tbkUShort:                     Result := 60;
    tbkInt,  tbkUInt:                        Result := 80;
    tbkLong, tbkULong:                       Result := 100;
    tbkFloat:                                Result := 90;
    tbkTOffset:                              Result := 200;
    tbkU8Array, tbkU16Array, tbkU32Array:    Result := 200;
  else
    Result := 80;
  end;
end;

procedure AppendCol(var A: TGridColumnArray; const C: TGridColumn);
begin
  SetLength(A, Length(A) + 1);
  A[High(A)] := C;
end;

function MakeScalarColumn(const Name: AnsiString;
                          const FT: TTBLDataType): TGridColumn;
begin
  Result := Default(TGridColumn);
  Result.DisplayName := Name;
  Result.JsonPath    := Name;
  Result.BaseKind    := FT.Kind;
  Result.Width       := PrimSuggestedWidth(FT.Kind);
  case FT.Kind of
    tbkTOffset:
      Result.Kind := ckString;
    tbkU8Array, tbkU16Array, tbkU32Array:
      Result.Kind := ckArray;
  else
    Result.Kind := ckScalar;
  end;
end;

function MakeNestedSummaryColumn(const Name: AnsiString;
                                 const FT: TTBLDataType): TGridColumn;
begin
  Result := Default(TGridColumn);
  Result.DisplayName := Name;
  Result.JsonPath    := Name;
  Result.Kind        := ckNestedSummary;
  Result.NestedFT    := FT;
  Result.Width       := 110;
end;

// ---------------------------------------------------------------------
//   BuildColumns / BuildNestedColumns
// ---------------------------------------------------------------------

function BuildColumns(Fields: TFieldList): TGridColumnArray;
var
  i: Integer;
  FT: TTBLDataType;
  C: TGridColumn;
begin
  SetLength(Result, 0);
  if Fields = nil then Exit;
  for i := 0 to High(Fields.Fields) do
  begin
    FT := Fields.Fields[i].DataType;
    if FT.Kind = tbkNested then
      C := MakeNestedSummaryColumn(Fields.Fields[i].Name, FT)
    else
      C := MakeScalarColumn(Fields.Fields[i].Name, FT);
    AppendCol(Result, C);
  end;
end;

function BuildNestedColumns(Inner: TFieldList): TGridColumnArray;
begin
  // Same path as BuildColumns: scalars become real columns; any
  // nested-of-nested would also become a summary that the user
  // could double-click to dive deeper.
  Result := BuildColumns(Inner);
end;

// ---------------------------------------------------------------------
//   Cell text I/O
// ---------------------------------------------------------------------

function FormatArray(J: TJSONArray): AnsiString;
var i: Integer;
begin
  Result := '[';
  for i := 0 to J.Count - 1 do
  begin
    if i > 0 then Result := Result + ', ';
    if J.Items[i] is TJSONString then
      Result := Result + '"' + J.Items[i].AsString + '"'
    else if J.Items[i].JSONType = jtNumber then
      Result := Result + IntToStr(J.Items[i].AsInt64)
    else
      Result := Result + J.Items[i].AsJSON;
  end;
  Result := Result + ']';
end;

function GetCellText(Row: TJSONObject; const Col: TGridColumn): AnsiString;
var
  J: TJSONData;
begin
  if Row = nil then Exit('');
  J := Row.Find(Col.JsonPath);
  if J = nil then Exit('');
  case Col.Kind of
    ckString:
      if J is TJSONString then Result := J.AsString
      else                     Result := '';
    ckArray:
      if J is TJSONArray then  Result := FormatArray(TJSONArray(J))
      else                     Result := '';
    ckNestedSummary:
      if J is TJSONArray then
        Result := Format('[%d rows]', [TJSONArray(J).Count])
      else
        Result := '[no data]';
    ckScalar:
      if J.JSONType = jtNumber then
      begin
        if Col.BaseKind = tbkFloat then
          Result := FloatToStrF(J.AsFloat, ffGeneral, 7, 0)
        else
          Result := IntToStr(J.AsInt64);
      end
      else
        Result := J.AsString;
  end;
end;

function SetCellText(Row: TJSONObject; const Col: TGridColumn;
                     const NewText: AnsiString): Boolean;
var
  J: TJSONData;
  IV: Int64;
  FV: Double;
  Arr: TJSONArray;
  Parts: TStringList;
  Trimmed, Item: AnsiString;
  i: Integer;
begin
  Result := False;
  if Row = nil then Exit;
  // Nested-summary is edited through the sub-grid popup, not here.
  if Col.Kind = ckNestedSummary then Exit;

  case Col.Kind of
    ckString:
      J := TJSONString.Create(NewText);
    ckScalar:
      begin
        try
          if Col.BaseKind = tbkFloat then
          begin
            FV := StrToFloat(NewText);
            J := TJSONFloatNumber.Create(FV);
          end
          else
          begin
            IV := StrToInt64(NewText);
            J := TJSONInt64Number.Create(IV);
          end;
        except
          Exit;  // bad input
        end;
      end;
    ckArray:
      begin
        // Accept formats:
        //   [1, 2, 3]    (JSON-array notation, with or without spaces)
        //   1, 2, 3      (bare comma-separated)
        //   1 2 3        (whitespace-separated)
        //   []           (empty array)
        // Strip outer brackets if present, then split on comma/space.
        Trimmed := Trim(NewText);
        if (Length(Trimmed) >= 2) and (Trimmed[1] = '[') and
           (Trimmed[Length(Trimmed)] = ']') then
          Trimmed := Copy(Trimmed, 2, Length(Trimmed) - 2);
        Trimmed := Trim(Trimmed);

        Arr := TJSONArray.Create;
        if Trimmed <> '' then
        begin
          Parts := TStringList.Create;
          try
            Parts.Delimiter := ',';
            Parts.StrictDelimiter := True;
            Parts.DelimitedText := Trimmed;
            try
              for i := 0 to Parts.Count - 1 do
              begin
                Item := Trim(Parts[i]);
                if Item = '' then Continue;
                if Col.BaseKind = tbkFloat then
                  Arr.Add(StrToFloat(Item))
                else
                  Arr.Add(StrToInt64(Item));
              end;
            except
              // Bad item — abort, don't mutate the row.
              Arr.Free;
              Exit;
            end;
          finally
            Parts.Free;
          end;
        end;
        J := Arr;
      end;
  else
    Exit;
  end;

  // Replace by name. fpjson 3.2 has no SetItem; remove + add.
  // Note: this moves the field to the end of the object's key order,
  // but TBL writer looks up by name not by position, so write output
  // is unaffected.
  Row.Delete(Col.JsonPath);
  Row.Add(Col.JsonPath, J);
  Result := True;
end;

function GetNestedArray(Row: TJSONObject; const Col: TGridColumn): TJSONArray;
var
  J: TJSONData;
begin
  Result := nil;
  if (Row = nil) or (Col.Kind <> ckNestedSummary) then Exit;
  J := Row.Find(Col.JsonPath);
  if J is TJSONArray then
    Result := TJSONArray(J);
end;

end.

