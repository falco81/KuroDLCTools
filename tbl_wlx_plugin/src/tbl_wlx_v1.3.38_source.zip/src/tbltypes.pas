unit tbltypes;
{$mode objfpc}{$H+}

// Type system used by KuroTools' TBL schemas. Schema fields are
// either:
//
//   - a primitive type name string:
//       byte,  short,  int,  long,  float    (signed integers + IEEE-754)
//       ubyte, ushort, uint, ulong            (unsigned integers)
//       toffset                                (8-byte offset to NUL-term UTF-8)
//       toffset<encoding>                      (e.g. "toffsetlatin-1")
//       u8array, u16array, u32array            (8-byte offset + 4-byte count)
//
//   - a nested record:
//       { "size": N, "schema": { key1: type1, key2: type2, ... } }
//
// This unit provides:
//   1. TTBLDataType — the parsed shape of any schema element.
//   2. TBLDataTypeSize() — recursive in-place byte size of a row cell.
//   3. ReadField()/WriteField() — read/write a single field from/to a
//      byte buffer, recursively walking nested records, with help from
//      a TStringBuilder-like data2 area for variable-length payloads.
//
// Built on top of FPC's fpjson so each value can be a TJSONData node
// (TJSONIntegerNumber, TJSONFloatNumber, TJSONString, TJSONArray,
// TJSONObject) for direct serialization to and from JSON.
//
// No I/O happens here — this unit is pure data structure manipulation.
// File-level reading/writing lives in tblfile.pas.

interface

uses Classes, SysUtils, fpjson;

type
  // Discriminator for the union below. Order matters because we test
  // these in order during parsing (most specific first).
  TTBLBaseKind = (
    tbkByte, tbkUByte,                  // 1 byte signed/unsigned
    tbkShort, tbkUShort,                // 2 byte
    tbkInt, tbkUInt,                    // 4 byte
    tbkLong, tbkULong,                  // 8 byte
    tbkFloat,                           // 4 byte IEEE-754
    tbkTOffset,                         // 8-byte offset → NUL-term string
    tbkU8Array, tbkU16Array, tbkU32Array,  // 8-byte offset + 4-byte count
    tbkNested                           // nested fixed-count record
  );

  // A parsed schema field can be a primitive or a nested struct.
  // Field-type structures are held by TFieldType; nested structures
  // recursively hold a list of TNamedField.
  TTBLDataType = record
    Kind: TTBLBaseKind;
    Encoding: AnsiString;     // tbkTOffset only (default 'utf-8')
    NestedSize: Integer;      // tbkNested only
    NestedFields: TObject;    // tbkNested only — TFieldList, opaque to outside
  end;
  PTTBLDataType = ^TTBLDataType;

  TNamedField = record
    Name: AnsiString;
    DataType: TTBLDataType;
  end;
  TNamedFieldArray = array of TNamedField;

  TFieldList = class
    Fields: TNamedFieldArray;
    destructor Destroy; override;
  end;

  EBadType = class(Exception);

// Parse a schema-field value (TJSONData) into a TTBLDataType.
// Caller is responsible for calling FreeDataType when done.
procedure ParseFieldType(JData: TJSONData; out FT: TTBLDataType);

// Recursively free any heap memory owned by FT (TFieldList for nested).
procedure FreeFieldType(var FT: TTBLDataType);

// Recursively compute the in-place byte size of a field. Primitive
// types return their fixed size; nested records return Size * sum of
// child sizes; arrays/strings return 12/8 bytes (the offset+count cell).
function FieldTypeSize(const FT: TTBLDataType): Integer;

// Sum sizes of every field in a list — useful for top-level row size.
function FieldListSize(L: TFieldList): Integer;

// ---------------------------------------------------------------------
//  Primitive read/write — fixed-width values from/to a byte buffer.
//  Offsets are absolute within the file. All multi-byte values are
//  little-endian (TBL convention; CLE engine matches).
// ---------------------------------------------------------------------

// Read a single primitive value at byte offset Off in B. Returns a
// freshly-created TJSONNumber/TJSONString that the caller owns.
// Used for reading row cells (1/2/4/8-byte int + float). For toffset
// and arrays the caller resolves the offset/count separately and uses
// these helpers to fetch the underlying string/array elements.
function ReadPrim(const B: TBytes; Off: PtrUInt;
                  Kind: TTBLBaseKind): TJSONNumber;

// Read NUL-terminated bytes at absolute Off in B and return them as a
// RawByteString with codepage CP_NONE — no implicit conversion happens
// when the result is assigned to AnsiString or UTF8String, so byte
// fidelity is preserved when these strings flow into fpjson (which
// internally uses UTF8String). Files in the wild are already UTF-8
// (or latin-1 when the schema flags toffset<latin-1>); we just pass
// the bytes through unchanged.
function ReadStringZ(const B: TBytes; Off: PtrUInt;
                     const Encoding: AnsiString): RawByteString;

// Pack a primitive value into the byte buffer B at the END (appended).
// J may be a TJSONNumber, TJSONString, or anything coercible.
procedure WritePrim(var B: TBytes; J: TJSONData; Kind: TTBLBaseKind);

// Append a Word (u16) to B at the end.
procedure AppendU8 (var B: TBytes; V: Byte);
procedure AppendU16(var B: TBytes; V: Word);
procedure AppendU32(var B: TBytes; V: LongWord);
procedure AppendU64(var B: TBytes; V: QWord);
procedure AppendF32(var B: TBytes; V: Single);

// Read primitives directly without TJSON allocation (faster path for
// internal use — returns Int64; floats are bit-cast and packed into
// the result, caller separates).
function ReadPrimInt(const B: TBytes; Off: PtrUInt;
                     Kind: TTBLBaseKind): Int64;
function ReadPrimFloat(const B: TBytes; Off: PtrUInt): Single;

// Parse the top-level "schema" object (key -> type) into TFieldList.
function ParseFieldList(SchemaObj: TJSONObject): TFieldList;

implementation

destructor TFieldList.Destroy;
var i: Integer;
begin
  for i := 0 to High(Fields) do
    FreeFieldType(Fields[i].DataType);
  inherited;
end;

// ---------------------------------------------------------------------
//   ParseFieldType
// ---------------------------------------------------------------------

procedure ParseFieldType(JData: TJSONData; out FT: TTBLDataType);
var
  S: AnsiString;
  Obj: TJSONObject;
  SchemaObj: TJSONObject;
  Inner: TFieldList;
begin
  FT := Default(TTBLDataType);
  if JData = nil then
    raise EBadType.Create('field type is nil');

  // String → primitive type
  if JData is TJSONString then
  begin
    S := JData.AsString;
    if      S = 'byte'   then FT.Kind := tbkByte
    else if S = 'ubyte'  then FT.Kind := tbkUByte
    else if S = 'short'  then FT.Kind := tbkShort
    else if S = 'ushort' then FT.Kind := tbkUShort
    else if S = 'int'    then FT.Kind := tbkInt
    else if S = 'uint'   then FT.Kind := tbkUInt
    else if S = 'long'   then FT.Kind := tbkLong
    else if S = 'ulong'  then FT.Kind := tbkULong
    else if S = 'float'  then FT.Kind := tbkFloat
    else if S = 'toffset' then
    begin
      FT.Kind := tbkTOffset;
      FT.Encoding := 'utf-8';
    end
    else if (Length(S) > 7) and (Copy(S, 1, 7) = 'toffset') then
    begin
      FT.Kind := tbkTOffset;
      FT.Encoding := Copy(S, 8, Length(S) - 7);
    end
    else if S = 'u8array'  then FT.Kind := tbkU8Array
    else if S = 'u16array' then FT.Kind := tbkU16Array
    else if S = 'u32array' then FT.Kind := tbkU32Array
    else
      raise EBadType.CreateFmt('unsupported primitive type "%s"', [S]);
    Exit;
  end;

  // Object → nested record
  if JData is TJSONObject then
  begin
    Obj := TJSONObject(JData);
    FT.Kind := tbkNested;
    if Obj.IndexOfName('size') < 0 then
      raise EBadType.Create('nested record missing "size"');
    FT.NestedSize := Obj.Get('size', 0);
    SchemaObj := Obj.Get('schema', TJSONObject(nil));
    if SchemaObj = nil then
      raise EBadType.Create('nested record missing "schema"');
    Inner := ParseFieldList(SchemaObj);
    FT.NestedFields := Inner;
    Exit;
  end;

  raise EBadType.CreateFmt('field type must be string or object, got %d',
                           [Ord(JData.JSONType)]);
end;

procedure FreeFieldType(var FT: TTBLDataType);
begin
  if (FT.Kind = tbkNested) and (FT.NestedFields <> nil) then
  begin
    TFieldList(FT.NestedFields).Free;
    FT.NestedFields := nil;
  end;
end;

// ---------------------------------------------------------------------
//   ParseFieldList — top-level schema object → list of named fields
// ---------------------------------------------------------------------

function ParseFieldList(SchemaObj: TJSONObject): TFieldList;
var
  i: Integer;
begin
  Result := TFieldList.Create;
  SetLength(Result.Fields, SchemaObj.Count);
  for i := 0 to SchemaObj.Count - 1 do
  begin
    Result.Fields[i].Name := SchemaObj.Names[i];
    try
      ParseFieldType(SchemaObj.Items[i], Result.Fields[i].DataType);
    except
      on E: Exception do
      begin
        // Free what we already built before re-raising
        SetLength(Result.Fields, i);
        Result.Free;
        Result := nil;
        raise EBadType.CreateFmt(
          'failed to parse field "%s": %s',
          [SchemaObj.Names[i], E.Message]);
      end;
    end;
  end;
end;

// ---------------------------------------------------------------------
//   Size computation
// ---------------------------------------------------------------------

function FieldTypeSize(const FT: TTBLDataType): Integer;
var
  i, NestedRowSize: Integer;
  L: TFieldList;
begin
  case FT.Kind of
    tbkByte, tbkUByte:                   Result := 1;
    tbkShort, tbkUShort:                 Result := 2;
    tbkInt, tbkUInt, tbkFloat:           Result := 4;
    tbkLong, tbkULong:                   Result := 8;
    tbkTOffset:                          Result := 8;
    tbkU8Array, tbkU16Array, tbkU32Array: Result := 12;  // 8 offset + 4 count
    tbkNested:
      begin
        L := TFieldList(FT.NestedFields);
        if L = nil then
          raise EBadType.Create('nested record has no field list');
        NestedRowSize := 0;
        for i := 0 to High(L.Fields) do
          Inc(NestedRowSize, FieldTypeSize(L.Fields[i].DataType));
        Result := FT.NestedSize * NestedRowSize;
      end;
  else
    raise EBadType.CreateFmt('unknown TBLBaseKind %d', [Ord(FT.Kind)]);
  end;
end;

function FieldListSize(L: TFieldList): Integer;
var i: Integer;
begin
  Result := 0;
  if L = nil then Exit;
  for i := 0 to High(L.Fields) do
    Inc(Result, FieldTypeSize(L.Fields[i].DataType));
end;

// ---------------------------------------------------------------------
//   Primitive read/write
// ---------------------------------------------------------------------

function ReadU8 (const B: TBytes; Off: PtrUInt): Byte;       inline; begin Result := B[Off]; end;
function ReadS8 (const B: TBytes; Off: PtrUInt): ShortInt;   inline; begin Result := ShortInt(B[Off]); end;
function ReadU16(const B: TBytes; Off: PtrUInt): Word;       inline;
begin Result := Word(B[Off]) or (Word(B[Off+1]) shl 8); end;
function ReadS16(const B: TBytes; Off: PtrUInt): SmallInt;   inline;
begin Result := SmallInt(ReadU16(B, Off)); end;
function ReadU32(const B: TBytes; Off: PtrUInt): LongWord;   inline;
begin
  Result :=  LongWord(B[Off])
         or (LongWord(B[Off+1]) shl 8)
         or (LongWord(B[Off+2]) shl 16)
         or (LongWord(B[Off+3]) shl 24);
end;
function ReadS32(const B: TBytes; Off: PtrUInt): LongInt;    inline;
begin Result := LongInt(ReadU32(B, Off)); end;
function ReadU64(const B: TBytes; Off: PtrUInt): QWord;
var Lo, Hi: LongWord;
begin
  Lo := ReadU32(B, Off);
  Hi := ReadU32(B, Off + 4);
  Result := QWord(Lo) or (QWord(Hi) shl 32);
end;
function ReadS64(const B: TBytes; Off: PtrUInt): Int64;      inline;
begin Result := Int64(ReadU64(B, Off)); end;

function ReadPrimFloat(const B: TBytes; Off: PtrUInt): Single;
var u: LongWord; r: Single absolute u;
begin
  u := ReadU32(B, Off);
  Result := r;
end;

function ReadPrimInt(const B: TBytes; Off: PtrUInt;
                     Kind: TTBLBaseKind): Int64;
begin
  case Kind of
    tbkByte:  Result := ReadS8(B, Off);
    tbkUByte: Result := ReadU8(B, Off);
    tbkShort: Result := ReadS16(B, Off);
    tbkUShort:Result := ReadU16(B, Off);
    tbkInt:   Result := ReadS32(B, Off);
    tbkUInt:  Result := ReadU32(B, Off);
    tbkLong:  Result := ReadS64(B, Off);
    tbkULong: Result := Int64(ReadU64(B, Off));
  else
    raise EBadType.CreateFmt('ReadPrimInt called on non-int kind %d',
                             [Ord(Kind)]);
  end;
end;

function ReadPrim(const B: TBytes; Off: PtrUInt;
                  Kind: TTBLBaseKind): TJSONNumber;
begin
  case Kind of
    tbkByte:   Result := TJSONIntegerNumber.Create(ReadS8(B, Off));
    tbkUByte:  Result := TJSONIntegerNumber.Create(ReadU8(B, Off));
    tbkShort:  Result := TJSONIntegerNumber.Create(ReadS16(B, Off));
    tbkUShort: Result := TJSONIntegerNumber.Create(ReadU16(B, Off));
    tbkInt:    Result := TJSONIntegerNumber.Create(ReadS32(B, Off));
    tbkUInt:   Result := TJSONInt64Number.Create(ReadU32(B, Off));
    tbkLong:   Result := TJSONInt64Number.Create(ReadS64(B, Off));
    tbkULong:  Result := TJSONInt64Number.Create(Int64(ReadU64(B, Off)));
    tbkFloat:  Result := TJSONFloatNumber.Create(ReadPrimFloat(B, Off));
  else
    raise EBadType.CreateFmt('ReadPrim called on non-primitive kind %d',
                             [Ord(Kind)]);
  end;
end;

function ReadStringZ(const B: TBytes; Off: PtrUInt;
                     const Encoding: AnsiString): RawByteString;
var L: PtrUInt;
begin
  Result := '';
  L := 0;
  // Read bytes up to NUL or end of buffer
  while (Off + L < PtrUInt(Length(B))) and (B[Off + L] <> 0) do Inc(L);
  if L = 0 then Exit;
  SetLength(Result, L);
  Move(B[Off], Result[1], L);
  // Encoding is currently informational. Real Falcom files are UTF-8
  // (or Latin-1 when the schema flags toffset<latin-1>); we keep the
  // bytes raw and let downstream JSON serializers treat them as UTF-8
  // text. CP_NONE prevents any auto-conversion on assignment.
end;

procedure AppendU8 (var B: TBytes; V: Byte);
begin SetLength(B, Length(B)+1); B[High(B)] := V; end;

procedure AppendU16(var B: TBytes; V: Word);
begin
  SetLength(B, Length(B)+2);
  B[Length(B)-2] := Byte(V and $FF);
  B[Length(B)-1] := Byte((V shr 8) and $FF);
end;

procedure AppendU32(var B: TBytes; V: LongWord);
begin
  SetLength(B, Length(B)+4);
  B[Length(B)-4] := Byte(V and $FF);
  B[Length(B)-3] := Byte((V shr 8) and $FF);
  B[Length(B)-2] := Byte((V shr 16) and $FF);
  B[Length(B)-1] := Byte((V shr 24) and $FF);
end;

procedure AppendU64(var B: TBytes; V: QWord);
begin
  AppendU32(B, LongWord(V and $FFFFFFFF));
  AppendU32(B, LongWord((V shr 32) and $FFFFFFFF));
end;

procedure AppendF32(var B: TBytes; V: Single);
var u: LongWord; r: Single absolute u;
begin
  r := V;
  AppendU32(B, u);
end;

procedure WritePrim(var B: TBytes; J: TJSONData; Kind: TTBLBaseKind);
var IV: Int64; FV: Double;
begin
  if Kind = tbkFloat then
  begin
    if (J <> nil) and (J.JSONType = jtNumber) then FV := J.AsFloat
    else if J <> nil then FV := StrToFloat(J.AsString)
    else FV := 0;
    AppendF32(B, Single(FV));
    Exit;
  end;
  if (J <> nil) and (J.JSONType = jtNumber) then IV := J.AsInt64
  else if J <> nil then IV := StrToInt64(J.AsString)
  else IV := 0;
  case Kind of
    tbkByte, tbkUByte:   AppendU8 (B, Byte(IV));
    tbkShort, tbkUShort: AppendU16(B, Word(IV));
    tbkInt, tbkUInt:     AppendU32(B, LongWord(IV));
    tbkLong, tbkULong:   AppendU64(B, QWord(IV));
  else
    raise EBadType.CreateFmt('WritePrim called on non-int kind %d',
                             [Ord(Kind)]);
  end;
end;

end.
