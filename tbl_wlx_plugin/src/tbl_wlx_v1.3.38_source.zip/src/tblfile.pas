unit tblfile;
{$mode objfpc}{$H+}

// Whole-file TBL reader/writer matching KuroTools' on-disk format
// exactly. Builds on:
//   tbltypes.pas    — primitive read/write, type-tree node
//   tblschemas.pas  — schema database with header lookup
//   crc32pac.pas    — zlib CRC32 (used for header-name CRC)
//   cle.pas         — CLE crypto wrapping (for Kuro 2 / Sora encrypted files)
//
// Wire format (verified against tbl2json.py / json2tbl.py):
//
//   8 bytes        '#TBL' + uint32 num_sections
//   N x 80 bytes   per-section directory entry:
//                    64B  name (NUL-padded UTF-8)
//                     4B  uint32  CRC32(name)
//                     4B  uint32  start_offset (absolute)
//                     4B  uint32  entry_length (bytes per row)
//                     4B  uint32  num_entries
//   ...rows...     each section's row data, packed back-to-back
//   ...data2...    variable-length payload area: NUL-term strings,
//                  array contents (with mid-area padding for u16 / u32
//                  alignment).
//
// In-memory model preserves duplicate section names and full ordering.
// Each section keeps either a TJSONArray of decoded rows (when a
// schema applies) or a raw TBytes blob (passthrough for unknown).
//
// JSON serialization matches KuroTools' shape:
//   { "headers": [{"name": ..., "schema": ...}, ...],
//     "data":    [{"name": ..., "data": [...]}, ...] }

interface

uses
  Classes, SysUtils, fpjson, jsonparser,
  tbltypes, tblschemas;

type
  ETBL = class(Exception);

  TTBLSectionMode = (smDecoded, smRaw);

  TTBLSection = record
    Name:        AnsiString;
    Mode:        TTBLSectionMode;
    EntryLength: Integer;        // bytes per row, as on disk
    GameTag:     AnsiString;     // chosen schema variant's game tag (informational)
    PlatformKey: AnsiString;     // chosen schema variant's platform key
    Rows:        TJSONArray;     // smDecoded — owned by this record
    RawBytes:    TBytes;         // smRaw — verbatim bytes
  end;
  TTBLSectionArray = array of TTBLSection;

  TTBLFile = class
  private
    FSchemaDB: TSchemaDB;
    FSections: TTBLSectionArray;
    FWasCLEWrapped: Boolean;
    FSchemaWarnings: TStringList;
    // If any section couldn't be decoded against a known schema, we
    // can't safely re-emit the file via fresh encoding (raw sections'
    // offset cells point into the OLD data2 area, which would be wrong
    // after any decoded section is rewritten). In that case writeback
    // dumps the original on-disk plaintext verbatim — it's the only
    // way to round-trip a partially-known file losslessly.
    FAnyRawSection: Boolean;
    FOrigPlainBytes: TBytes;
    procedure FreeAllSections;
    function DecodeRow(const Buf: TBytes; RowOff: Integer;
                       Fields: TFieldList): TJSONObject;
    function DecodeNested(const Buf: TBytes; RowOff: Integer;
                          NestedSize: Integer; Fields: TFieldList): TJSONArray;
  public
    constructor Create(SchemaDB: TSchemaDB);
    destructor Destroy; override;

    // Read a TBL file from disk. Auto-detects CLE-wrapped files
    // (F9BA / C9BA / D9BA magic) and unwraps them before parsing.
    // PreferGame guides schema variant selection when multiple
    // variants share the same entry_length (e.g. "Kuro1" vs "Kuro2").
    procedure ReadFromFile(const Path: AnsiString;
                           const PreferGame: AnsiString = '';
                           const TblHeaderHint: AnsiString = '');

    // Write the in-memory state back to disk as a plain (uncompressed,
    // unencrypted) #TBL file. Re-encryption to CLE is not done here —
    // the plugin layer handles that if it wants to.
    procedure WriteToFile(const Path: AnsiString);

    // Serialize the in-memory state to a TJSONObject in KuroTools'
    // wire shape. Caller owns the returned object.
    function ToJSON: TJSONObject;

    // Inverse: replace section data with what's in the JSON. Section
    // structure (count, names, entry_lengths) must match what was read.
    // For now this is a placeholder; full implementation lands when
    // we wire the editor.
    procedure FromJSON(JObj: TJSONObject);

    property Sections: TTBLSectionArray read FSections;
    property WasCLEWrapped: Boolean read FWasCLEWrapped;
    property SchemaWarnings: TStringList read FSchemaWarnings;
  end;

implementation

uses
  cle, crc32pac;

// ---------------------------------------------------------------------
//   TByteBuilder — append-only buffer used by writer
// ---------------------------------------------------------------------

type
  TByteBuilder = object
    Buf: TBytes;
    Len: PtrUInt;
    procedure Init(InitialCap: PtrUInt);
    procedure EnsureCap(Want: PtrUInt);
    procedure WrU8(V: Byte);
    procedure WrU16(V: Word);
    procedure WrU32(V: LongWord);
    procedure WrU64(V: QWord);
    procedure WrF32(V: Single);
    procedure WrPad(N: PtrUInt);
    procedure WrBytes(const Src: TBytes);
    procedure WrAnsi(const S: AnsiString);
    procedure WrAnsiZ(const S: AnsiString);  // NUL-terminated
  end;

procedure TByteBuilder.Init(InitialCap: PtrUInt);
begin
  if InitialCap < 64 then InitialCap := 64;
  SetLength(Buf, InitialCap);
  Len := 0;
end;

procedure TByteBuilder.EnsureCap(Want: PtrUInt);
var NewCap: PtrUInt;
begin
  if Want <= PtrUInt(Length(Buf)) then Exit;
  NewCap := PtrUInt(Length(Buf));
  if NewCap = 0 then NewCap := 64;
  while NewCap < Want do NewCap := NewCap * 2;
  SetLength(Buf, NewCap);
end;

procedure TByteBuilder.WrU8(V: Byte);
begin
  EnsureCap(Len + 1);
  Buf[Len] := V;
  Inc(Len);
end;

procedure TByteBuilder.WrU16(V: Word);
begin
  EnsureCap(Len + 2);
  Buf[Len]   := Byte(V and $FF);
  Buf[Len+1] := Byte((V shr 8) and $FF);
  Inc(Len, 2);
end;

procedure TByteBuilder.WrU32(V: LongWord);
begin
  EnsureCap(Len + 4);
  Buf[Len]   := Byte(V and $FF);
  Buf[Len+1] := Byte((V shr 8) and $FF);
  Buf[Len+2] := Byte((V shr 16) and $FF);
  Buf[Len+3] := Byte((V shr 24) and $FF);
  Inc(Len, 4);
end;

procedure TByteBuilder.WrU64(V: QWord);
begin
  WrU32(LongWord(V and $FFFFFFFF));
  WrU32(LongWord((V shr 32) and $FFFFFFFF));
end;

procedure TByteBuilder.WrF32(V: Single);
var u: LongWord; r: Single absolute u;
begin
  r := V;
  WrU32(u);
end;

procedure TByteBuilder.WrPad(N: PtrUInt);
begin
  EnsureCap(Len + N);
  if N > 0 then FillChar(Buf[Len], N, 0);
  Inc(Len, N);
end;

procedure TByteBuilder.WrBytes(const Src: TBytes);
begin
  if Length(Src) = 0 then Exit;
  EnsureCap(Len + PtrUInt(Length(Src)));
  Move(Src[0], Buf[Len], Length(Src));
  Inc(Len, Length(Src));
end;

procedure TByteBuilder.WrAnsi(const S: AnsiString);
begin
  if S = '' then Exit;
  EnsureCap(Len + PtrUInt(Length(S)));
  Move(S[1], Buf[Len], Length(S));
  Inc(Len, Length(S));
end;

procedure TByteBuilder.WrAnsiZ(const S: AnsiString);
begin
  WrAnsi(S);
  WrU8(0);
end;

// ---------------------------------------------------------------------
//   TTBLFile — lifecycle
// ---------------------------------------------------------------------

constructor TTBLFile.Create(SchemaDB: TSchemaDB);
begin
  inherited Create;
  FSchemaDB := SchemaDB;
  FSchemaWarnings := TStringList.Create;
end;

destructor TTBLFile.Destroy;
begin
  FreeAllSections;
  FSchemaWarnings.Free;
  inherited;
end;

procedure TTBLFile.FreeAllSections;
var i: Integer;
begin
  for i := 0 to High(FSections) do
    if FSections[i].Rows <> nil then
    begin
      FSections[i].Rows.Free;
      FSections[i].Rows := nil;
    end;
  SetLength(FSections, 0);
end;

// ---------------------------------------------------------------------
//   ReadFromFile
// ---------------------------------------------------------------------

function ReadU32(const B: TBytes; Off: PtrUInt): LongWord; inline;
begin
  Result :=  LongWord(B[Off])
         or (LongWord(B[Off+1]) shl 8)
         or (LongWord(B[Off+2]) shl 16)
         or (LongWord(B[Off+3]) shl 24);
end;

procedure LoadEntireFile(const Path: AnsiString; out B: TBytes);
var FS: TFileStream; L: Int64;
begin
  FS := TFileStream.Create(Path, fmOpenRead or fmShareDenyWrite);
  try
    L := FS.Size;
    SetLength(B, L);
    if L > 0 then FS.ReadBuffer(B[0], L);
  finally FS.Free; end;
end;

procedure TTBLFile.ReadFromFile(const Path: AnsiString;
                                const PreferGame: AnsiString;
                                const TblHeaderHint: AnsiString);
var
  Raw, Plain: TBytes;
  Magic: AnsiString;
  NumSections: LongWord;
  HdrPos, RowPos, j, RowIdx: Integer;
  HdrName: AnsiString;
  HdrNameBuf: array[0..63] of AnsiChar;
  SecCRC, SecStart, SecLen, SecCount: LongWord;
  Sect: TTBLSection;
  Variant: TSchemaVariant;
  TblFileForLookup: AnsiString;
begin
  FreeAllSections;
  FSchemaWarnings.Clear;
  FWasCLEWrapped := False;

  LoadEntireFile(Path, Raw);
  if IsCLEWrapped(Raw) then
  begin
    FWasCLEWrapped := True;
    ProcessCLE(Raw, Plain);
  end
  else
    Plain := Raw;

  if Length(Plain) < 8 then
    raise ETBL.Create('TBL too short');
  SetString(Magic, PAnsiChar(@Plain[0]), 4);
  if Magic <> '#TBL' then
    raise ETBL.CreateFmt('Bad TBL magic: %s', [Magic]);

  // Snapshot the unwrapped plaintext so writeback can do verbatim
  // passthrough when even a single section is in raw mode (since
  // raw sections may reference into the file-wide data2 area, which
  // we can't safely regenerate without the schema).
  SetLength(FOrigPlainBytes, Length(Plain));
  if Length(Plain) > 0 then
    Move(Plain[0], FOrigPlainBytes[0], Length(Plain));

  NumSections := ReadU32(Plain, 4);
  if NumSections > 1024 then
    raise ETBL.CreateFmt('Suspicious section count %d', [NumSections]);

  if TblHeaderHint <> '' then
    TblFileForLookup := TblHeaderHint
  else
    TblFileForLookup := ExtractFileName(Path);

  SetLength(FSections, NumSections);
  HdrPos := 8;
  for j := 0 to Integer(NumSections) - 1 do
  begin
    if HdrPos + 80 > Length(Plain) then
      raise ETBL.CreateFmt(
        'Section directory entry %d extends past EOF', [j]);
    Move(Plain[HdrPos], HdrNameBuf[0], 64);
    Inc(HdrPos, 64);
    HdrName := AnsiString(StrPas(HdrNameBuf));
    SecCRC   := ReadU32(Plain, HdrPos); Inc(HdrPos, 4);
    SecStart := ReadU32(Plain, HdrPos); Inc(HdrPos, 4);
    SecLen   := ReadU32(Plain, HdrPos); Inc(HdrPos, 4);
    SecCount := ReadU32(Plain, HdrPos); Inc(HdrPos, 4);

    // Hardening: refuse insane sizes early. SecLen*SecCount is the
    // contiguous row blob; if it doesn't fit in the file there's no
    // point continuing. We compute as Int64 to dodge overflow on
    // adversarial inputs.
    if (Int64(SecStart) + Int64(SecLen) * Int64(SecCount) > Int64(Length(Plain))) or
       (Int64(SecLen) * Int64(SecCount) > Int64(Length(Plain))) then
      raise ETBL.CreateFmt(
        'Section "%s": start=%d len=%d count=%d does not fit in file (%d bytes)',
        [HdrName, SecStart, SecLen, SecCount, Length(Plain)]);

    Sect := Default(TTBLSection);
    Sect.Name := HdrName;
    Sect.EntryLength := SecLen;

    if FSchemaDB.FindVariant(HdrName, SecLen, PreferGame, Variant) then
    begin
      Sect.Mode := smDecoded;
      Sect.GameTag := Variant.GameTag;
      Sect.PlatformKey := Variant.PlatformKey;
      Sect.Rows := TJSONArray.Create;
      try
        for RowIdx := 0 to Integer(SecCount) - 1 do
        begin
          RowPos := SecStart + RowIdx * SecLen;
          if RowPos + SecLen > Length(Plain) then
            raise ETBL.CreateFmt(
              'Section "%s" row %d extends past EOF', [HdrName, RowIdx]);
          Sect.Rows.Add(DecodeRow(Plain, RowPos, Variant.Fields));
        end;
      except
        on E: Exception do
        begin
          Sect.Rows.Free;
          Sect.Rows := nil;
          Sect.Mode := smRaw;
          Sect.GameTag := '';
          Sect.PlatformKey := '';
          SetLength(Sect.RawBytes, SecLen * SecCount);
          if SecCount > 0 then
            Move(Plain[SecStart], Sect.RawBytes[0], SecLen * SecCount);
          FSchemaWarnings.Add(Format('%s [%s len=%d]: %s',
            [ExtractFileName(Path), HdrName, SecLen, E.Message]));
        end;
      end;
    end
    else
    begin
      Sect.Mode := smRaw;
      SetLength(Sect.RawBytes, SecLen * SecCount);
      if SecCount > 0 then
        Move(Plain[SecStart], Sect.RawBytes[0], SecLen * SecCount);
      FSchemaWarnings.Add(Format('%s [%s len=%d]: no matching schema',
        [ExtractFileName(Path), HdrName, SecLen]));
    end;

    FSections[j] := Sect;
  end;

  // Decide whether we'll need verbatim passthrough on writeback.
  FAnyRawSection := False;
  for j := 0 to High(FSections) do
    if FSections[j].Mode = smRaw then
    begin
      FAnyRawSection := True;
      Break;
    end;
end;

// ---------------------------------------------------------------------
//   DecodeRow
// ---------------------------------------------------------------------

function TTBLFile.DecodeNested(const Buf: TBytes; RowOff: Integer;
                               NestedSize: Integer;
                               Fields: TFieldList): TJSONArray;
var
  i: Integer;
  ChildRowOff: Integer;
  ChildSize: Integer;
begin
  Result := TJSONArray.Create;
  ChildSize := FieldListSize(Fields);
  for i := 0 to NestedSize - 1 do
  begin
    ChildRowOff := RowOff + i * ChildSize;
    Result.Add(DecodeRow(Buf, ChildRowOff, Fields));
  end;
end;

function TTBLFile.DecodeRow(const Buf: TBytes; RowOff: Integer;
                            Fields: TFieldList): TJSONObject;
var
  i, k: Integer;
  Cur: Integer;
  FT: TTBLDataType;
  FieldName: AnsiString;
  S: UTF8String;
  StrOff: PtrUInt;
  ArrOff, ArrCnt: Int64;
  ArrJ: TJSONArray;
  ElemSize: Integer;
begin
  Result := TJSONObject.Create;
  Cur := RowOff;
  for i := 0 to High(Fields.Fields) do
  begin
    FieldName := Fields.Fields[i].Name;
    FT := Fields.Fields[i].DataType;
    case FT.Kind of
      tbkByte, tbkUByte, tbkShort, tbkUShort,
      tbkInt, tbkUInt, tbkLong, tbkULong, tbkFloat:
        begin
          Result.Add(FieldName, ReadPrim(Buf, Cur, FT.Kind));
          Inc(Cur, FieldTypeSize(FT));
        end;
      tbkTOffset:
        begin
          StrOff := PtrUInt(Int64(ReadPrimInt(Buf, Cur, tbkULong)));
          Inc(Cur, 8);
          if (StrOff = 0) or (StrOff >= PtrUInt(Length(Buf))) then
            S := ''
          else
            S := ReadStringZ(Buf, StrOff, FT.Encoding);
          Result.Add(FieldName, S);
        end;
      tbkU8Array, tbkU16Array, tbkU32Array:
        begin
          ArrOff := Int64(ReadPrimInt(Buf, Cur, tbkULong)); Inc(Cur, 8);
          ArrCnt := Int64(ReadPrimInt(Buf, Cur, tbkUInt));  Inc(Cur, 4);
          if FT.Kind = tbkU8Array  then ElemSize := 1
          else if FT.Kind = tbkU16Array then ElemSize := 2
          else                              ElemSize := 4;
          if (ArrCnt < 0) or (ArrCnt > 1048576) then
            raise EBadType.CreateFmt(
              'array count %d out of range at field "%s"',
              [ArrCnt, FieldName]);
          if (ArrCnt > 0) and
             ((ArrOff < 0) or (ArrOff + ArrCnt * ElemSize > Length(Buf))) then
            raise EBadType.CreateFmt(
              'array off=%d cnt=%d step=%d exceeds buffer (len=%d) at "%s"',
              [ArrOff, ArrCnt, ElemSize, Length(Buf), FieldName]);
          ArrJ := TJSONArray.Create;
          for k := 0 to ArrCnt - 1 do
          begin
            case FT.Kind of
              tbkU8Array:  ArrJ.Add(Int64(Buf[ArrOff + k]));
              tbkU16Array: ArrJ.Add(Int64(ReadPrimInt(Buf, ArrOff + k*2, tbkUShort)));
              tbkU32Array: ArrJ.Add(Int64(ReadPrimInt(Buf, ArrOff + k*4, tbkUInt)));
            end;
          end;
          Result.Add(FieldName, ArrJ);
        end;
      tbkNested:
        begin
          Result.Add(FieldName,
            DecodeNested(Buf, Cur,
                         FT.NestedSize,
                         TFieldList(FT.NestedFields)));
          Inc(Cur, FieldTypeSize(FT));
        end;
    else
      raise EBadType.CreateFmt('unhandled field kind %d', [Ord(FT.Kind)]);
    end;
  end;
end;

// ---------------------------------------------------------------------
//   WriteToFile  (implemented in next iteration)
// ---------------------------------------------------------------------

// ---------------------------------------------------------------------
//   WriteToFile
//
// Mirrors KuroTools' json2tbl.pack: phase 1 lays out section start
// offsets, phase 2 emits the header + row data, phase 3 (interleaved
// with row encoding) writes the data2 region. Each row's variable-
// length payloads (toffset strings, u8/u16/u32 arrays, nested struct
// elements that contain those) get appended to a Data2 buffer; the
// row cell stores the absolute offset (= Data2StartOffset +
// position-in-Data2-at-time-of-emission).
//
// CRC is computed over the section name (8-bit ASCII) using the same
// zlib-style CRC32 KuroTools uses (see crc32pac.pas — it's the same
// algorithm; the FPAC packer reuses it).
// ---------------------------------------------------------------------

type
  TPackContext = record
    Body:    ^TByteBuilder;       // section row data
    Data2:   ^TByteBuilder;       // variable-length payload area
    Data2StartOffset: Int64;      // absolute file offset where Data2 begins
    GameTag: AnsiString;
  end;

procedure PackData(var Ctx: TPackContext;
                   const FT: TTBLDataType;
                   J: TJSONData); forward;

procedure PackPrim(var Ctx: TPackContext;
                   const FT: TTBLDataType; J: TJSONData);
var IV: Int64; FV: Double;
begin
  if FT.Kind = tbkFloat then
  begin
    if (J <> nil) and (J.JSONType = jtNumber) then FV := J.AsFloat
    else if J <> nil then FV := StrToFloat(J.AsString)
    else FV := 0;
    Ctx.Body^.WrF32(Single(FV));
    Exit;
  end;
  if (J <> nil) and (J.JSONType = jtNumber) then IV := J.AsInt64
  else if J <> nil then IV := StrToInt64(J.AsString)
  else IV := 0;
  case FT.Kind of
    tbkByte, tbkUByte:   Ctx.Body^.WrU8 (Byte(IV));
    tbkShort, tbkUShort: Ctx.Body^.WrU16(Word(IV));
    tbkInt, tbkUInt:     Ctx.Body^.WrU32(LongWord(IV));
    tbkLong, tbkULong:   Ctx.Body^.WrU64(QWord(IV));
  else
    raise EBadType.Create('PackPrim: bad kind');
  end;
end;

procedure PackTOffset(var Ctx: TPackContext;
                      const FT: TTBLDataType; J: TJSONData);
var
  StrOff: Int64;
  S: RawByteString;
begin
  // J.AsString is UTF8String; assigning to RawByteString preserves
  // bytes verbatim (no codepage conversion). WrAnsi then writes those
  // bytes as-is to the data2 buffer, so a UTF-8 byte sequence read in
  // ReadFromFile travels round-trip without mutation.
  if (J <> nil) and (J.JSONType = jtString) then S := J.AsString
  else if J <> nil then S := J.AsString
  else S := '';
  StrOff := Int64(Ctx.Data2^.Len) + Ctx.Data2StartOffset;
  Ctx.Body^.WrU64(QWord(StrOff));
  // Write bytes
  if S <> '' then
  begin
    Ctx.Data2^.EnsureCap(Ctx.Data2^.Len + PtrUInt(Length(S)));
    Move(S[1], Ctx.Data2^.Buf[Ctx.Data2^.Len], Length(S));
    Inc(Ctx.Data2^.Len, Length(S));
  end;
  Ctx.Data2^.WrU8(0);
end;

procedure PackArray(var Ctx: TPackContext;
                    const FT: TTBLDataType; J: TJSONData);
var
  ArrJ: TJSONArray;
  i, ElemSize, Pad: Integer;
  ArrOff: Int64;
  V: Int64;
begin
  if J = nil then ArrJ := nil
  else if J is TJSONArray then ArrJ := TJSONArray(J)
  else raise EBadType.Create('expected array, got non-array');

  case FT.Kind of
    tbkU8Array:  ElemSize := 1;
    tbkU16Array: ElemSize := 2;
    tbkU32Array: ElemSize := 4;
  else
    raise EBadType.Create('PackArray: bad kind');
  end;

  // KuroTools' packer aligns the Data2 cursor to ElemSize before
  // recording the array offset and writing elements. (It does this
  // even for empty arrays.)
  Pad := Ctx.Data2^.Len mod PtrUInt(ElemSize);
  if Pad > 0 then
    Ctx.Data2^.WrPad(PtrUInt(ElemSize - Pad));
  ArrOff := Int64(Ctx.Data2^.Len) + Ctx.Data2StartOffset;
  Ctx.Body^.WrU64(QWord(ArrOff));
  if ArrJ = nil then
    Ctx.Body^.WrU32(0)
  else
  begin
    Ctx.Body^.WrU32(LongWord(ArrJ.Count));
    for i := 0 to ArrJ.Count - 1 do
    begin
      V := ArrJ.Items[i].AsInt64;
      case FT.Kind of
        tbkU8Array:  Ctx.Data2^.WrU8 (Byte(V));
        tbkU16Array: Ctx.Data2^.WrU16(Word(V));
        tbkU32Array: Ctx.Data2^.WrU32(LongWord(V));
      end;
    end;
  end;
end;

procedure PackNested(var Ctx: TPackContext;
                     const FT: TTBLDataType; J: TJSONData);
var
  ArrJ: TJSONArray;
  i, k: Integer;
  Inner: TFieldList;
  RowObj: TJSONObject;
  Field: TJSONData;
begin
  Inner := TFieldList(FT.NestedFields);
  if not (J is TJSONArray) then
    raise EBadType.Create('PackNested: expected JSON array of nested rows');
  ArrJ := TJSONArray(J);
  if ArrJ.Count <> FT.NestedSize then
    raise EBadType.CreateFmt(
      'PackNested: got %d rows, schema requires %d',
      [ArrJ.Count, FT.NestedSize]);
  for i := 0 to FT.NestedSize - 1 do
  begin
    if not (ArrJ.Items[i] is TJSONObject) then
      raise EBadType.Create('PackNested: nested row not an object');
    RowObj := TJSONObject(ArrJ.Items[i]);
    for k := 0 to High(Inner.Fields) do
    begin
      Field := RowObj.Find(Inner.Fields[k].Name);
      PackData(Ctx, Inner.Fields[k].DataType, Field);
    end;
  end;
end;

procedure PackData(var Ctx: TPackContext;
                   const FT: TTBLDataType;
                   J: TJSONData);
begin
  case FT.Kind of
    tbkByte, tbkUByte, tbkShort, tbkUShort,
    tbkInt, tbkUInt, tbkLong, tbkULong, tbkFloat:
      PackPrim(Ctx, FT, J);
    tbkTOffset:
      PackTOffset(Ctx, FT, J);
    tbkU8Array, tbkU16Array, tbkU32Array:
      PackArray(Ctx, FT, J);
    tbkNested:
      PackNested(Ctx, FT, J);
  else
    raise EBadType.CreateFmt('PackData: unknown kind %d', [Ord(FT.Kind)]);
  end;
end;

procedure TTBLFile.WriteToFile(const Path: AnsiString);
var
  Header, Body, Data2: TByteBuilder;
  Ctx: TPackContext;
  i, j, k: Integer;
  CurOff: LongWord;
  SectionStarts: array of LongWord;
  RowCount: Integer;
  NameBuf: array[0..63] of Byte;
  NameLen: Integer;
  Variant: TSchemaVariant;
  RowObj: TJSONObject;
  Field: TJSONData;
  CRC: LongWord;
  FS: TFileStream;
  TotalSize: Int64;
  RowsBefore: PtrUInt;
  Sect: TTBLSection;
begin
  // Verbatim passthrough mode: any section we couldn't decode means
  // we don't have a complete schema picture. Re-emit the original
  // bytes 1:1 — guarantees lossless round-trip and avoids the danger
  // of stale offset cells in raw sections pointing at moved data.
  if FAnyRawSection and (Length(FOrigPlainBytes) > 0) then
  begin
    FS := TFileStream.Create(Path, fmCreate);
    try
      FS.WriteBuffer(FOrigPlainBytes[0], Length(FOrigPlainBytes));
    finally FS.Free; end;
    Exit;
  end;

  // Phase 1: compute section start offsets.
  // Layout: 8 bytes #TBL+count, then 80 bytes per section header,
  //         then back-to-back row data.
  CurOff := 8 + LongWord(Length(FSections)) * 80;
  SetLength(SectionStarts, Length(FSections));
  for i := 0 to High(FSections) do
  begin
    SectionStarts[i] := CurOff;
    if FSections[i].Mode = smDecoded then
      RowCount := FSections[i].Rows.Count
    else if FSections[i].EntryLength > 0 then
      RowCount := Length(FSections[i].RawBytes) div FSections[i].EntryLength
    else
      RowCount := 0;
    Inc(CurOff, FSections[i].EntryLength * LongWord(RowCount));
  end;

  // Data2 starts right after the last section's row data.
  Header.Init(8 + Length(FSections) * 80);
  Body.Init(CurOff - SectionStarts[0] + 1024);
  Data2.Init(65536);

  Ctx.Body  := @Body;
  Ctx.Data2 := @Data2;
  Ctx.Data2StartOffset := CurOff;

  // Phase 2: emit header
  Header.WrU8(Ord('#'));
  Header.WrU8(Ord('T'));
  Header.WrU8(Ord('B'));
  Header.WrU8(Ord('L'));
  Header.WrU32(LongWord(Length(FSections)));
  for i := 0 to High(FSections) do
  begin
    Sect := FSections[i];
    FillChar(NameBuf, 64, 0);
    NameLen := Length(Sect.Name);
    if NameLen > 64 then NameLen := 64;
    if NameLen > 0 then
      Move(Sect.Name[1], NameBuf[0], NameLen);
    Header.EnsureCap(Header.Len + 64);
    Move(NameBuf[0], Header.Buf[Header.Len], 64);
    Inc(Header.Len, 64);
    CRC := CRC32_PAC_Str(Sect.Name);  // matches KuroTools compute_crc32
    Header.WrU32(CRC);
    Header.WrU32(SectionStarts[i]);
    Header.WrU32(LongWord(Sect.EntryLength));
    if Sect.Mode = smDecoded then
      Header.WrU32(LongWord(Sect.Rows.Count))
    else if Sect.EntryLength > 0 then
      Header.WrU32(LongWord(Length(Sect.RawBytes) div Sect.EntryLength))
    else
      Header.WrU32(0);
  end;

  // Phase 3: emit row data and accumulate Data2
  for i := 0 to High(FSections) do
  begin
    Sect := FSections[i];
    if Sect.Mode = smRaw then
    begin
      Body.WrBytes(Sect.RawBytes);
      Continue;
    end;
    // Decoded — need a schema variant to encode against
    if not FSchemaDB.FindVariant(Sect.Name, Sect.EntryLength,
                                 Sect.GameTag, Variant) then
      raise ETBL.CreateFmt(
        'WriteToFile: schema for "%s" len=%d disappeared between read and write',
        [Sect.Name, Sect.EntryLength]);
    Ctx.GameTag := Sect.GameTag;
    for j := 0 to Sect.Rows.Count - 1 do
    begin
      if not (Sect.Rows.Items[j] is TJSONObject) then
        raise ETBL.CreateFmt(
          'WriteToFile: section "%s" row %d is not an object',
          [Sect.Name, j]);
      RowObj := TJSONObject(Sect.Rows.Items[j]);
      RowsBefore := Body.Len;
      for k := 0 to High(Variant.Fields.Fields) do
      begin
        Field := RowObj.Find(Variant.Fields.Fields[k].Name);
        PackData(Ctx, Variant.Fields.Fields[k].DataType, Field);
      end;
      // Sanity check: emitted exactly EntryLength bytes for this row
      if Int64(Body.Len) - Int64(RowsBefore) <> Sect.EntryLength then
        raise ETBL.CreateFmt(
          'WriteToFile: section "%s" row %d emitted %d bytes (expected %d)',
          [Sect.Name, j, Int64(Body.Len) - Int64(RowsBefore),
           Sect.EntryLength]);
    end;
  end;

  // Phase 4: write to disk
  TotalSize := Int64(Header.Len) + Int64(Body.Len) + Int64(Data2.Len);
  FS := TFileStream.Create(Path, fmCreate);
  try
    if Header.Len > 0 then FS.WriteBuffer(Header.Buf[0], Header.Len);
    if Body.Len   > 0 then FS.WriteBuffer(Body.Buf[0],   Body.Len);
    if Data2.Len  > 0 then FS.WriteBuffer(Data2.Buf[0],  Data2.Len);
  finally FS.Free; end;
  // Suppress unused warning
  if TotalSize < 0 then ;
end;

function TTBLFile.ToJSON: TJSONObject;
var
  HdrArr, DataArr, RowsArr: TJSONArray;
  HdrObj, DataObj: TJSONObject;
  i: Integer;
begin
  Result := TJSONObject.Create;
  HdrArr := TJSONArray.Create;
  DataArr := TJSONArray.Create;
  Result.Add('headers', HdrArr);
  Result.Add('data', DataArr);

  for i := 0 to High(FSections) do
  begin
    HdrObj := TJSONObject.Create;
    HdrObj.Add('name', FSections[i].Name);
    if FSections[i].Mode = smDecoded then
      HdrObj.Add('schema', FSections[i].GameTag)
    else
      HdrObj.Add('schema', 'data_schema');
    HdrArr.Add(HdrObj);

    DataObj := TJSONObject.Create;
    DataObj.Add('name', FSections[i].Name);
    if FSections[i].Mode = smDecoded then
    begin
      // Clone the rows so caller owns its copy
      RowsArr := FSections[i].Rows.Clone as TJSONArray;
      DataObj.Add('data', RowsArr);
    end
    else
    begin
      // Raw mode: hex-encode raw bytes for inspection
      RowsArr := TJSONArray.Create;
      DataObj.Add('data', RowsArr);
      // (For now keep as empty in raw mode; future versions can split
      // into per-row hex blobs once we track entry_length cleanly.)
    end;
    DataArr.Add(DataObj);
  end;
end;

procedure TTBLFile.FromJSON(JObj: TJSONObject);
var
  DataArr: TJSONData;
  DataItems: TJSONArray;
  i: Integer;
  Item: TJSONData;
  ItemObj: TJSONObject;
  ItemName: AnsiString;
  ItemRows: TJSONData;
  NewRows: TJSONArray;
begin
  // We refresh row data only — section structure (count, names,
  // entry lengths, game tags) was set by the prior ReadFromFile and
  // must remain stable so WriteToFile can encode against the same
  // schemas. The input shape is the one produced by ToJSON:
  //
  //   { "headers": [{"name": ..., "schema": ...}, ...],
  //     "data":    [{"name": ..., "data": [...rows...]}, ...] }
  //
  // We walk `data` in order. The Nth `data` item must correspond to
  // the Nth section in FSections; both name and position must match
  // (so that decoded vs raw mode lines up with the original).

  if JObj = nil then
    raise ETBL.Create('FromJSON: object is nil');
  DataArr := JObj.Find('data');
  if not (DataArr is TJSONArray) then
    raise ETBL.Create('FromJSON: missing or non-array "data" field');
  DataItems := TJSONArray(DataArr);

  if DataItems.Count <> Length(FSections) then
    raise ETBL.CreateFmt(
      'FromJSON: data has %d sections, expected %d',
      [DataItems.Count, Length(FSections)]);

  for i := 0 to High(FSections) do
  begin
    Item := DataItems.Items[i];
    if not (Item is TJSONObject) then
      raise ETBL.CreateFmt(
        'FromJSON: data[%d] is not an object', [i]);
    ItemObj := TJSONObject(Item);
    ItemName := ItemObj.Get('name', '');
    if ItemName <> FSections[i].Name then
      raise ETBL.CreateFmt(
        'FromJSON: data[%d].name="%s" does not match section "%s"',
        [i, ItemName, FSections[i].Name]);

    // Raw sections can't be edited via JSON (we have no schema), so
    // we skip them — they keep their RawBytes.
    if FSections[i].Mode = smRaw then
      Continue;

    ItemRows := ItemObj.Find('data');
    if not (ItemRows is TJSONArray) then
      raise ETBL.CreateFmt(
        'FromJSON: data[%d].data is not an array', [i]);

    // Replace the section's rows with a deep copy of the input. The
    // existing FSections[i].Rows is owned by the section and must be
    // freed before the swap.
    NewRows := TJSONArray(TJSONArray(ItemRows).Clone);
    if FSections[i].Rows <> nil then FSections[i].Rows.Free;
    FSections[i].Rows := NewRows;
  end;
end;

end.
