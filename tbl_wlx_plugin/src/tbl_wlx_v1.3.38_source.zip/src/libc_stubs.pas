unit libc_stubs;
{$mode objfpc}{$H+}

// libc replacements required by the linked C object files (zstdobj.o).
// ZSTD's reference single-file decoder calls memcpy/memmove/memset/
// malloc/calloc/free; we route each to FPC's own RTL so the resulting
// DLL has no libc dependency on Windows.
//
// Kept in a separate unit (instead of inside zstddec.pas) so other
// units in the same project can also link C objects that need the
// same symbols without producing duplicate-symbol errors.

interface

implementation

function memcpy(Dst, Src: Pointer; N: PtrUInt): Pointer; cdecl; public name 'memcpy';
begin
  Move(Src^, Dst^, N);
  Result := Dst;
end;

function memmove(Dst, Src: Pointer; N: PtrUInt): Pointer; cdecl; public name 'memmove';
begin
  Move(Src^, Dst^, N);
  Result := Dst;
end;

function memset(Dst: Pointer; C: LongInt; N: PtrUInt): Pointer; cdecl; public name 'memset';
begin
  FillChar(Dst^, N, Byte(C));
  Result := Dst;
end;

function malloc_(N: PtrUInt): Pointer; cdecl; public name 'malloc';
begin
  GetMem(Result, N);
end;

function calloc(Num, Size: PtrUInt): Pointer; cdecl; public name 'calloc';
begin
  GetMem(Result, Num * Size);
  FillChar(Result^, Num * Size, 0);
end;

procedure free_(P: Pointer); cdecl; public name 'free';
begin
  if P <> nil then FreeMem(P);
end;

// __chkstk_ms is mingw's stack-probe helper, effectively a no-op for
// small allocations. The COFF symbol on Win64 has 3 leading
// underscores, ELF on Linux has 2.
procedure chkstk_ms; cdecl;
  {$IFDEF MSWINDOWS}
  public name '___chkstk_ms';
  {$ELSE}
  public name '__chkstk_ms';
  {$ENDIF}
begin
end;

end.
