unit tabwin;
{$mode objfpc}{$H+}

// Tab-strip host window: tabs at the top, swappable child window
// below. We use a SysTabControl32 for the tabs and switch the
// visibility of multiple grid + JSON child windows when the user
// changes tabs.
//
// Layout:
//
//   +---------------------------------------+
//   | [DLCTableData] [DLCTable] [JSON]      |  <- tab control (top)
//   +---------------------------------------+
//   |                                       |
//   |  active grid or JSON edit             |  <- client area
//   |                                       |
//   +---------------------------------------+
//
// The host registers a single window class. The tab control + the
// client children are siblings within it.
//
// One TTabHostState lives per host window. It owns:
//   - the tab control HWND
//   - an array of child windows (one per tab, in tab order)
//   - the current selection index
//
// TabContent kinds:
//   - tcGrid: a child created via gridwin.CreateGridWindow
//   - tcJSON: a child Edit control showing JSON text
//   - tcConfig: a child panel with INI-bound checkboxes/combobox
//     and Save / Reset to defaults buttons
//
// External code sets up tabs by calling AddGridTab / AddJSONTab and
// finally ShowFirstTab. The host then handles WM_NOTIFY (tab-change)
// and WM_SIZE on its own.

interface

uses
  Windows, Messages, SysUtils, Classes, CommCtrl,
  fpjson, tbltypes, gridmodel, gridwin;

type
  TTabContentKind = (tcGrid, tcJSON, tcConfig);

  TTabEntry = record
    Kind:      TTabContentKind;
    Caption:   AnsiString;
    Child:     HWND;            // window for the tab content
    // For tcGrid we also keep a reference to its TGridState so we
    // can route Save / Refresh through the right grid.
    Cols:      TGridColumnArray;
    Rows:      TJSONArray;
  end;
  TTabEntryArray = array of TTabEntry;

  PTabHostState = ^TTabHostState;
  TTabHostState = record
    TabCtrl:    HWND;
    // Status label at the top of the host showing edit-mode state
    // ("EDIT MODE" / "READ-ONLY"). Updated whenever F4 toggles the
    // mode via ApplyEditModeUI.
    ModeLabel:  HWND;
    Tabs:       TTabEntryArray;
    Active:     Integer;
    DirtyCB:    TGridDirtyCallback;
    // Forwarded notify for grid sub-classes embedded in a tab.
  end;

const
  TBL_TABHOST_CLASS_NAME : PChar = 'TBLLister.TabHostV1';

procedure EnsureTabHostClassRegistered;

// Create the tab-host window (returns the host HWND). Caller then
// adds tabs and finally shows the first tab. DirtyCB is called from
// grid cell commits to mark the file dirty; SaveCB is called from
// the JSON tab when the user presses Ctrl+S inside it.
function CreateTabHost(ParentWnd: HWND;
                       DirtyCB: TGridDirtyCallback;
                       SaveCB:  TGridDirtyCallback): HWND;

// Free per-host state (and any child resources we own — grids etc.
// are children of the tab-host so Windows destroys them on
// DestroyWindow).
procedure DestroyTabHostState(HostWnd: HWND);

// Add a grid tab. Cols and Rows are passed to gridwin.CreateGridWindow.
procedure AddGridTab(HostWnd: HWND; const Caption: AnsiString;
                     const Cols: TGridColumnArray; Rows: TJSONArray);

// Add a JSON tab whose content is a multi-line Edit control.
procedure AddJSONTab(HostWnd: HWND; const Caption: AnsiString;
                     const InitialText: AnsiString);

// Add the Config tab — a panel with controls bound to the INI
// settings ([TBL_WLX] section). Buttons inside let the user Save
// to disk or Reset to defaults without touching the INI by hand.
procedure AddConfigTab(HostWnd: HWND; const Caption: AnsiString);

// Make tab 0 active (call after all tabs are added).
procedure ShowFirstTab(HostWnd: HWND);

// Make tab Idx active. Clamped to [0, count-1]; out-of-range values
// fall back to tab 0.
procedure SetActiveTab(HostWnd: HWND; Idx: Integer);

// Remove every tab and destroy its child window. Used by F2 reload
// before re-populating with fresh content.
procedure ClearAllTabs(HostWnd: HWND);

// Get the JSON tab's Edit HWND if it exists. Used by the host's
// Save handler to read the current text.
function GetJSONTabEditWnd(HostWnd: HWND): HWND;

// Get the index of the currently-active tab.
function GetActiveTabIndex(HostWnd: HWND): Integer;

// Get tab kind by index.
function GetTabKind(HostWnd: HWND; Idx: Integer): TTabContentKind;

// Return the HWND of the child window in the given tab (or 0 if
// out of range). For tcGrid tabs that's the ListView grid; for
// tcJSON tabs that's the multi-line Edit. Used by ListSearchText
// to scan grid cells.
function GetTabChild(HostWnd: HWND; Idx: Integer): HWND;

// Number of tabs currently registered with the host.
function GetTabCount(HostWnd: HWND): Integer;

// Programmatically switch the active tab. Used by search to pull
// the user onto a grid tab where a hit was found.
procedure SelectTabAt(HostWnd: HWND; Idx: Integer);

// Defer a "restore window state from INI" call until after the
// current ListLoad returns, so we don't reentrantly call ShowWindow
// /SetWindowPos on the Lister parent while TC is still in the middle
// of its plugin-loading state machine. Without the deferral, TC
// crashes on the first F3 because WM_SHOWWINDOW reaches TC's plugin
// handler while it's already inside ListLoad.
procedure SchedulePostLoadWindowApply(HostWnd: HWND);

// Refresh the RO/RW status strip + JSON-tab read-only attribute
// from the current per-instance edit-mode flag. Called after
// instance creation so the label shows correct text on first open,
// and after F4 toggles the flag.
procedure ApplyEditModeUI(HostWnd: HWND);

// Set the callback used by Config tab's "Export current TBL as
// JSON" button. The callback is invoked with the tab-host HWND.
procedure SetExportJSONCallback(CB: TGridDirtyCallback);

// Suppress / unsuppress JSON-change tracking. Call Suppress before
// any programmatic SetViewerText / SendMessage(WM_SETTEXT) on a
// JSON tab's Edit control, and call Unsuppress afterwards. Without
// this the EN_CHANGE that fires from the SetText would mark the
// instance dirty as if the user had typed.
procedure SuppressJSONChange;
procedure UnsuppressJSONChange;

// Sync callback: invoked just before a tab switch, with the host
// HWND, the index of the tab being left, and the index of the
// tab being entered. tbl_wlx uses this to re-parse JSON edits or
// re-serialize grid edits so JSON ↔ grid stays consistent.
//
// Return True if the callback already rebuilt and re-selected the
// tabs itself (e.g. because syncing required a full ClearAllTabs +
// BuildTabsForInstance round-trip); tabwin will then skip its own
// ShowTabAt. Return False for the common case where the model is
// updated in place and tabwin should proceed normally.
type
  TTabSwitchCallback = function(HostWnd: HWND; FromIdx, ToIdx: Integer): Boolean;
procedure SetBeforeTabSwitchCallback(CB: TTabSwitchCallback);

// Called from ListCloseWindow — captures the current Lister window
// pos/size into INI memory. (No deferral needed here.)
procedure CaptureWindowStateOnClose(HostWnd: HWND);

implementation

uses StrUtils, pluginstate, inisettings;

const
  // Custom message: any of our subclassed children sends this to the
  // host when the user presses F4, so the toggle logic can live in a
  // single place.
  WM_TBL_TOGGLE_EDIT_MODE = WM_USER + 0;
  // Height in pixels of the RO/RW status strip at the top of the
  // tab-host. Tab control sits below it.
  MODE_BAR_HEIGHT = 22;

// Forward declaration: implemented further down.
procedure ShowTabAt(St: PTabHostState; Idx: Integer); forward;

// Update window title + JSON Edit's read-only flag to reflect the
// current edit-mode flag.
procedure ApplyEditModeUI(HostWnd: HWND);
var
  St: PTabHostState;
  EditMode: Boolean;
  i: Integer;
  Title: array[0..255] of AnsiChar;
  Buf: AnsiString;
  LabelText: AnsiString;
begin
  EditMode := GetInstanceEditMode(HostWnd);
  // Update window title (TC overwrites this for its own caption, but
  // many users have shown-window-on-taskbar plugins that pick it up).
  if GetWindowTextA(HostWnd, @Title[0], SizeOf(Title)) > 0 then
  begin
    Buf := Title;
    // Strip any prior " [read-only]" / " [edit mode]" suffix.
    Buf := StringReplace(Buf, ' [read-only]', '', [rfIgnoreCase]);
    Buf := StringReplace(Buf, ' [edit mode]', '', [rfIgnoreCase]);
  end
  else
    Buf := '';
  if EditMode then
    Buf := Buf + ' [edit mode]'
  else
    Buf := Buf + ' [read-only]';
  SetWindowTextA(HostWnd, PAnsiChar(Buf));

  St := PTabHostState(GetWindowLongPtr(HostWnd, GWLP_USERDATA));
  if St = nil then Exit;

  // Update the status strip at the top of the host. Color is
  // applied via WM_CTLCOLORSTATIC handler in TabHostWndProc.
  // Use ASCII separators (the STATIC control is ANSI; em-dash bytes
  // would render as cp1252 mojibake "â€"").
  if St^.ModeLabel <> 0 then
  begin
    if EditMode then
      LabelText := '   EDIT MODE   |   F4: toggle to read-only'
    else
      LabelText := '   READ-ONLY   |   F4: toggle to edit mode';
    SendMessageA(St^.ModeLabel, WM_SETTEXT, 0,
                 LPARAM(PAnsiChar(LabelText)));
    InvalidateRect(St^.ModeLabel, nil, True);
  end;

  // Toggle ES_READONLY on the JSON tab's Edit control if present.
  for i := 0 to High(St^.Tabs) do
    if (St^.Tabs[i].Kind = tcJSON) and (St^.Tabs[i].Child <> 0) then
      SendMessageW(St^.Tabs[i].Child, EM_SETREADONLY,
                   WPARAM(Ord(not EditMode)), 0);
end;

// Flip the per-instance edit-mode flag and refresh visible UI.
// We use distinct beeps (info vs. warning) so the user gets audio
// feedback without an intrusive popup; the new state is also
// reflected in the window title.
procedure DoToggleEditMode(HostWnd: HWND);
var
  NewMode: Boolean;
  St: PTabHostState;
begin
  NewMode := ToggleInstanceEditMode(HostWnd);
  ApplyEditModeUI(HostWnd);
  // Re-show the active tab to make sure focus lands on the child
  // and not on the tab strip / mode label / host. Without this,
  // the JSON Edit may be editable (EM_SETREADONLY 0) but keystrokes
  // never reach it because focus is somewhere else after the toggle.
  St := PTabHostState(GetWindowLongPtr(HostWnd, GWLP_USERDATA));
  if (St <> nil) and (St^.Active >= 0) and
     (St^.Active < Length(St^.Tabs)) then
  begin
    ShowTabAt(St, St^.Active);  // also calls SetFocus on Tabs[Active].Child
  end;
  if NewMode then
    MessageBeep(MB_ICONASTERISK)        // higher-pitched "ON" cue
  else
    MessageBeep(MB_ICONEXCLAMATION);    // lower-pitched "OFF" cue
end;

var
  TabHostClassRegistered: Boolean = False;
  // Subclass for the JSON Edit control inside the JSON tab so we
  // can pick up Ctrl+S the same way viewerwin.pas does for the
  // single-view layout.
  OrigJSONEditProc: LONG_PTR = 0;
  JSONEditSaveCB: TGridDirtyCallback = nil;
  // Callback invoked from Config tab's "Export current TBL as JSON"
  // button. Set by tbl_wlx via SetExportJSONCallback below.
  ExportJSONCallback: TGridDirtyCallback = nil;
  // Set by tbl_wlx via SetBeforeTabSwitchCallback. Invoked just
  // before TCN_SELCHANGE actually switches the visible child. The
  // callback can use FromIdx to pull dirty data from the outgoing
  // tab into the model, then push the model into the incoming tab.
  BeforeTabSwitchCallback: TTabSwitchCallback = nil;
  // Toolbar-style font for the tab strip
  TabFont: HFONT = 0;
  // Background brushes for the RO/RW status strip (lazily created
  // on first WM_CTLCOLORSTATIC). Pale red for read-only, pale
  // green for edit mode. Module-global so they're shared across
  // all open Lister windows.
  ROModeLabelBrush:   HBRUSH = 0;
  EditModeLabelBrush: HBRUSH = 0;
  // Reference-counted suppressor for EN_CHANGE-driven MarkDirty.
  // Set >0 around any programmatic SetWindowText on a JSON Edit
  // (initial load, grid → JSON re-sync) so the user's actions
  // remain the only thing that marks the instance dirty.
  IgnoreJSONChangeDepth: Integer = 0;

procedure SetExportJSONCallback(CB: TGridDirtyCallback);
begin
  ExportJSONCallback := CB;
end;

procedure SuppressJSONChange;
begin
  Inc(IgnoreJSONChangeDepth);
end;

procedure UnsuppressJSONChange;
begin
  if IgnoreJSONChangeDepth > 0 then
    Dec(IgnoreJSONChangeDepth);
end;

procedure SetBeforeTabSwitchCallback(CB: TTabSwitchCallback);
begin
  BeforeTabSwitchCallback := CB;
end;

function GetState(HostWnd: HWND): PTabHostState; inline;
begin
  Result := PTabHostState(GetWindowLongPtr(HostWnd, GWLP_USERDATA));
end;

procedure SetState(HostWnd: HWND; St: PTabHostState); inline;
begin
  SetWindowLongPtr(HostWnd, GWLP_USERDATA, LONG_PTR(St));
end;

// Compute the rect inside which the active tab's child should sit,
// in tab-host client coordinates (NOT tab control's own coords).
// We need the host coords because the tab content children are
// children of the host, not the tab control.
procedure GetClientChildRect(St: PTabHostState; out R: TRect);
var
  P: TPoint;
begin
  GetClientRect(St^.TabCtrl, R);
  // Shrink to the area suitable for tab content (excluding tabs strip).
  TabCtrl_AdjustRect(St^.TabCtrl, False, R);
  // R is in tab-control client coords; translate to host client coords
  // so the offset of the tab control within the host (mode bar height,
  // etc.) is accounted for.
  P.X := 0;
  P.Y := 0;
  ClientToScreen(St^.TabCtrl, P);
  ScreenToClient(GetParent(St^.TabCtrl), P);
  OffsetRect(R, P.X, P.Y);
end;

procedure ShowTabAt(St: PTabHostState; Idx: Integer);
var
  i: Integer;
  R: TRect;
begin
  if (Idx < 0) or (Idx >= Length(St^.Tabs)) then Exit;
  GetClientChildRect(St, R);
  for i := 0 to High(St^.Tabs) do
  begin
    if i = Idx then
    begin
      MoveWindow(St^.Tabs[i].Child, R.Left, R.Top,
                 R.Right - R.Left, R.Bottom - R.Top, True);
      ShowWindow(St^.Tabs[i].Child, SW_SHOW);
    end
    else
      ShowWindow(St^.Tabs[i].Child, SW_HIDE);
  end;
  St^.Active := Idx;
  SendMessage(St^.TabCtrl, TCM_SETCURSEL, WPARAM(Idx), 0);
  SetFocus(St^.Tabs[Idx].Child);
end;

// Is the given HWND the Edit control of one of our JSON tabs?
function IsJSONEditChild(St: PTabHostState; Child: HWND): Boolean;
var i: Integer;
begin
  Result := False;
  if (St = nil) or (Child = 0) then Exit;
  for i := 0 to High(St^.Tabs) do
    if (St^.Tabs[i].Kind = tcJSON) and (St^.Tabs[i].Child = Child) then
      Exit(True);
end;

// Manually translate a WM_KEYDOWN into one or more WM_CHAR messages,
// posting them to the target window. Used because Total Commander's
// message pump in Lister plugin context apparently doesn't run the
// standard TranslateMessage path that produces WM_CHAR — typing
// 'a','b','c' was silently dropped before this fix even though the
// Edit was editable (Delete and Backspace worked because they're
// processed in WM_KEYDOWN directly).
procedure GenerateCharFromKey(Edit: HWND; vk: WPARAM; lParam: LPARAM);
var
  KeyState: array[0..255] of Byte;
  WBuf: array[0..7] of WideChar;
  ScanCode: UINT;
  Count, i: Integer;
begin
  // Skip pure modifier keys — they don't produce a character.
  case vk of
    VK_SHIFT, VK_CONTROL, VK_MENU,
    VK_LSHIFT, VK_RSHIFT, VK_LCONTROL, VK_RCONTROL, VK_LMENU, VK_RMENU,
    VK_CAPITAL, VK_NUMLOCK, VK_SCROLL,
    VK_LEFT, VK_RIGHT, VK_UP, VK_DOWN,
    VK_HOME, VK_END, VK_PRIOR, VK_NEXT,
    VK_DELETE, VK_BACK, VK_INSERT, VK_TAB,
    VK_F1..VK_F24:
      Exit;
  end;
  // Don't synthesize WM_CHAR for Ctrl+letter combos — Edit handles
  // Ctrl+C/V/X/Z/A on the WM_KEYDOWN path itself, and we've already
  // intercepted Ctrl+S / Ctrl+F before getting here.
  if (GetKeyState(VK_CONTROL) and $8000) <> 0 then Exit;
  if not GetKeyboardState(@KeyState[0]) then Exit;
  ScanCode := (lParam shr 16) and $FF;
  FillChar(WBuf, SizeOf(WBuf), 0);
  Count := ToUnicode(vk, ScanCode, @KeyState[0],
                     @WBuf[0], Length(WBuf), 0);
  if Count <= 0 then Exit;
  // Send WM_CHAR for each character produced (most keys produce 1,
  // dead keys + accented combos can produce 2).
  for i := 0 to Count - 1 do
    SendMessageW(Edit, WM_CHAR, WPARAM(Word(WBuf[i])), lParam);
end;

// Subclassed JSON-Edit proc.
//
// Critical: we MUST handle WM_GETDLGCODE — Total Commander's main
// message loop calls IsDialogMessage on the Lister window, which
// queries the focused control's "what keys do you want?" code. A
// plain Edit normally returns DLGC_WANTCHARS|DLGC_WANTARROWS, but
// when reached via IsDialogMessage that's apparently not enough to
// keep typing routed to us — Tab, Return, and arrow keys get eaten
// as dialog navigation, and worse, character keys can be eaten too
// depending on the host. Returning DLGC_WANTALLKEYS unconditionally
// ensures every keystroke flows directly to the Edit's WM_KEYDOWN /
// WM_CHAR pipeline.
function JSONEditSubclassProc(Wnd: HWND; Msg: UINT;
                              wParam: WPARAM; lParam: LPARAM): LRESULT; stdcall;
var
  Host: HWND;
begin
  case Msg of
    WM_GETDLGCODE:
      begin
        // We want everything: chars, arrows, Tab, Return, Esc.
        // (We swallow Esc/Ctrl+S in WM_CHAR ourselves.)
        Result := DLGC_WANTALLKEYS or DLGC_WANTCHARS or
                  DLGC_WANTARROWS or DLGC_HASSETSEL or DLGC_WANTTAB;
        Exit;
      end;
    WM_LBUTTONDOWN, WM_LBUTTONDBLCLK:
      begin
        // Make sure the click gives us focus even when the host
        // sits behind a dialog message pump that might otherwise
        // route the click elsewhere.
        SetFocus(Wnd);
        // Fall through to default handler for caret positioning.
      end;
    WM_KEYDOWN:
      begin
        if wParam = VK_ESCAPE then
        begin
          // Esc closes the Lister window (TC convention).
          Host := GetParent(Wnd);
          PostMessage(GetParent(Host), WM_KEYDOWN, VK_ESCAPE, lParam);
          Result := 0;
          Exit;
        end;
        // F3 / F7: forward to TC's Lister parent so it opens the
        // Find dialog (or finds-next when state exists). The default
        // Edit-control handler consumes these keys, so without this
        // forward they don't reach TC.
        if (wParam = VK_F3) or (wParam = VK_F7) then
        begin
          Host := GetParent(Wnd);
          PostMessage(GetParent(Host), WM_KEYDOWN, wParam, lParam);
          Result := 0;
          Exit;
        end;
        // Ctrl+F: same — forward to TC.
        if (wParam = $46 {F}) and ((GetKeyState(VK_CONTROL) and $8000) <> 0) then
        begin
          Host := GetParent(Wnd);
          PostMessage(GetParent(Host), WM_KEYDOWN, wParam, lParam);
          Result := 0;
          Exit;
        end;
        if wParam = VK_F4 then
        begin
          // Forward toggle to the host
          Host := GetParent(Wnd);
          SendMessage(Host, WM_TBL_TOGGLE_EDIT_MODE, 0, 0);
          Result := 0;
          Exit;
        end;
        if (wParam = $53 {S}) and ((GetKeyState(VK_CONTROL) and $8000) <> 0) then
        begin
          // Block save shortcut when in read-only mode.
          if not GetInstanceEditMode(GetParent(Wnd)) then
          begin
            MessageBeep(0);
            Result := 0;
            Exit;
          end;
          if Assigned(JSONEditSaveCB) then
          begin
            // Walk up to the tab-host (Edit -> tabhost)
            Host := GetParent(Wnd);
            JSONEditSaveCB(Host);
          end;
          Result := 0;
          Exit;
        end;
        // KEY-TO-CHAR FALLBACK ----------------------------------
        // Total Commander's message pump in Lister plugin context
        // does not reliably produce WM_CHAR via TranslateMessage,
        // so the default Edit handler never sees printable keys.
        // We simulate it ourselves: ask the OS to translate the
        // virtual key + current keyboard state into characters,
        // then send WM_CHAR for each. (Special keys like Delete,
        // Backspace, arrows, etc. are handled by the default
        // WM_KEYDOWN path so they keep working.)
        if not GetInstanceEditMode(GetParent(Wnd)) then
        begin
          // RO mode — let default proc decide (it'll probably beep
          // for unhandled keys, which is fine).
        end
        else
        begin
          GenerateCharFromKey(Wnd, wParam, lParam);
        end;
      end;
    WM_CHAR:
      // Swallow the standard ESC beep that Edit emits otherwise.
      if (wParam = $1B) or (wParam = $13) then
      begin
        Result := 0;
        Exit;
      end;
  end;
  Result := CallWindowProcW(WNDPROC(OrigJSONEditProc), Wnd, Msg, wParam, lParam);
end;

// ---------------------------------------------------------------------
//   Tab host wndproc
// ---------------------------------------------------------------------

const
  // Timer ID used for the deferred window-state apply scheduled by
  // ListLoad. Picked from the user-message space ($0400+) but in a
  // range unlikely to collide with anything else we'd add later.
  TIMER_ID_APPLY_WINSTATE = $7F01;

procedure ApplyWindowStateNow(HostWnd: HWND); forward;

function TabHostWndProc(Wnd: HWND; Msg: UINT;
                        wParam: WPARAM; lParam: LPARAM): LRESULT; stdcall;
var
  St: PTabHostState;
  Hdr: PNMHdr;
  W, H: Integer;
  R: TRect;
  i: Integer;
begin
  St := GetState(Wnd);
  case Msg of
    WM_GETDLGCODE:
      begin
        // Same reason as in JSONEditSubclassProc: prevent TC's
        // IsDialogMessage from eating keystrokes meant for our
        // children before they get dispatched.
        Result := DLGC_WANTALLKEYS or DLGC_WANTCHARS or
                  DLGC_WANTARROWS or DLGC_WANTTAB;
        Exit;
      end;
    WM_ERASEBKGND:
      begin
        // Tell Windows we handled the background erase — don't fill
        // anything. Our children (tab control + active grid/edit)
        // fully cover the client area. Without this, a flash of
        // window-class brush colour appears whenever the Find dialog
        // is moved or dismissed, briefly erasing the grid.
        Result := 1;
        Exit;
      end;
    WM_PAINT:
      // Default paint is fine (children paint themselves), but when
      // a modal dialog (e.g. TC's Find) is dismissed, the active
      // tab's grid sometimes loses its cached cell text and renders
      // as a single row. Force-invalidating the active child here
      // ensures the LVS_OWNERDATA cache re-queries every visible
      // cell on the next paint cycle.
      if (St <> nil) and (St^.Active >= 0) and
         (St^.Active < Length(St^.Tabs)) and
         (St^.Tabs[St^.Active].Child <> 0) then
      begin
        InvalidateRect(St^.Tabs[St^.Active].Child, nil, True);
        // Fall through to DefWindowProc so it does the validation
      end;
    WM_TBL_TOGGLE_EDIT_MODE:
      begin
        DoToggleEditMode(Wnd);
        Result := 0;
        Exit;
      end;
    WM_TIMER:
      // Deferred window-state apply (scheduled by ListLoad). We
      // killed the timer first to make sure it only fires once.
      if wParam = TIMER_ID_APPLY_WINSTATE then
      begin
        KillTimer(Wnd, TIMER_ID_APPLY_WINSTATE);
        try
          ApplyWindowStateNow(Wnd);
        except end;
        Result := 0;
        Exit;
      end;
    WM_CTLCOLORSTATIC:
      // Color the mode label so RO / edit mode is visually
      // distinct: RO uses the default button-face grey (matches
      // the rest of the chrome — a "safe" default state); EDIT
      // MODE is highlighted in red because that's the state
      // where accidental keystrokes can corrupt the file.
      if (St <> nil) and (HWND(lParam) = St^.ModeLabel) then
      begin
        if GetInstanceEditMode(Wnd) then
        begin
          // EDIT MODE — red
          SetTextColor(HDC(wParam), RGB($88, $00, $00));   // dark red
          SetBkColor(HDC(wParam),   RGB($FA, $E0, $E0));   // pale red
        end
        else
        begin
          // READ-ONLY — neutral grey (button face, like rest of UI)
          SetTextColor(HDC(wParam), GetSysColor(COLOR_BTNTEXT));
          SetBkColor(HDC(wParam),   GetSysColor(COLOR_BTNFACE));
        end;
        // We need a real brush so the background actually fills.
        // Lazily create both. EditModeLabelBrush = red, ROModeLabelBrush
        // is COLOR_BTNFACE (we use the system brush directly so it
        // tracks theme changes — no explicit creation needed).
        if EditModeLabelBrush = 0 then
          EditModeLabelBrush := CreateSolidBrush(RGB($FA, $E0, $E0));
        if GetInstanceEditMode(Wnd) then
          Result := LRESULT(EditModeLabelBrush)
        else
          Result := LRESULT(GetSysColorBrush(COLOR_BTNFACE));
        Exit;
      end;
    WM_KEYDOWN:
      begin
        // Esc: forward to TC's Lister parent window so it closes
        // the Lister. TC subclasses our host window for hotkeys
        // like 'n'/'p' but Esc isn't reliably caught when one of
        // our child controls has focus, so we route it ourselves.
        if wParam = VK_ESCAPE then
        begin
          PostMessage(GetParent(Wnd), WM_KEYDOWN, VK_ESCAPE, lParam);
          Result := 0;
          Exit;
        end;
        // F3 / F7 / Ctrl+F: open TC's Find dialog.
        if (wParam = VK_F3) or (wParam = VK_F7) or
           ((wParam = $46 {F}) and ((GetKeyState(VK_CONTROL) and $8000) <> 0)) then
        begin
          PostMessage(GetParent(Wnd), WM_KEYDOWN, wParam, lParam);
          Result := 0;
          Exit;
        end;
        // F4 toggles edit/read-only mode when the host window has
        // focus directly. (Subclassed grids and edits forward via
        // WM_TBL_TOGGLE_EDIT_MODE so the toggle lives in one place.)
        if wParam = VK_F4 then
        begin
          DoToggleEditMode(Wnd);
          Result := 0;
          Exit;
        end;
      end;
    WM_SIZE:
      begin
        if St <> nil then
        begin
          W := LOWORD(lParam);
          H := HIWORD(lParam);
          // Mode label at top (full width, fixed height)
          if St^.ModeLabel <> 0 then
            MoveWindow(St^.ModeLabel, 0, 0, W, MODE_BAR_HEIGHT, True);
          // Tab control below the label, fills the rest
          MoveWindow(St^.TabCtrl, 0, MODE_BAR_HEIGHT,
                     W, H - MODE_BAR_HEIGHT, True);
          // Now move the active tab content
          GetClientChildRect(St, R);
          for i := 0 to High(St^.Tabs) do
            if i = St^.Active then
              MoveWindow(St^.Tabs[i].Child, R.Left, R.Top,
                         R.Right - R.Left, R.Bottom - R.Top, True);
        end;
        Result := 0;
        Exit;
      end;
    WM_NOTIFY:
      begin
        Hdr := PNMHdr(lParam);
        if Hdr <> nil then
        begin
          if (Hdr^.code = LongWord(TCN_SELCHANGE)) and (St <> nil) then
          begin
            // Invoke sync callback so the host (tbl_wlx) can flush
            // dirty edits from the leaving tab into the underlying
            // model, then refresh the entering tab from it. If the
            // callback returns True it has fully handled the switch
            // (rebuilt tabs + selected the right one) — we skip our
            // own ShowTabAt in that case.
            if Assigned(BeforeTabSwitchCallback) then
            begin
              if BeforeTabSwitchCallback(Wnd, St^.Active,
                   SendMessage(St^.TabCtrl, TCM_GETCURSEL, 0, 0)) then
              begin
                Result := 0;
                Exit;
              end;
            end;
            ShowTabAt(St, SendMessage(St^.TabCtrl, TCM_GETCURSEL, 0, 0));
            Result := 0;
            Exit;
          end;
          // Forward grid notifications (LVN_GETDISPINFO etc.)
          Result := GridHandleNotify(Hdr);
          Exit;
        end;
      end;
    WM_COMMAND:
      begin
        // EN_CHANGE on the JSON tab's Edit control: user just typed
        // or pasted/deleted something. Mark the instance dirty so F2
        // reload prompts to save, and so a subsequent Ctrl+S knows
        // there's something to write.
        // HIWORD(wParam) = notification code, LOWORD = control ID
        // (we set ID=0 on creation; matching by HWND instead).
        if (HIWORD(wParam) = EN_CHANGE) and (St <> nil) then
        begin
          if IsJSONEditChild(St, HWND(lParam)) then
          begin
            if (IgnoreJSONChangeDepth = 0) and Assigned(St^.DirtyCB) then
              St^.DirtyCB(Wnd);
            Result := 0;
            Exit;
          end;
        end;
      end;
    WM_SETFOCUS:
      if (St <> nil) and (St^.Active >= 0) and (St^.Active < Length(St^.Tabs)) then
      begin
        SetFocus(St^.Tabs[St^.Active].Child);
        Result := 0;
        Exit;
      end;
  end;
  Result := DefWindowProc(Wnd, Msg, wParam, lParam);
end;

procedure EnsureTabHostClassRegistered;
var WC: WNDCLASSA;
begin
  if TabHostClassRegistered then Exit;
  FillChar(WC, SizeOf(WC), 0);
  WC.style         := CS_HREDRAW or CS_VREDRAW;
  WC.lpfnWndProc   := @TabHostWndProc;
  WC.hInstance     := HInstance;
  WC.hCursor       := LoadCursor(0, IDC_ARROW);
  // No hbrBackground — our children (tab control + active tab's
  // grid/edit) fully cover the client area, so we don't need (or
  // want) DefWindowProc to fill anything. With a brush set, the
  // brush would flash white/grey for a frame whenever the Find
  // dialog appeared/disappeared, since Windows posts WM_ERASEBKGND
  // before children get to redraw.
  WC.hbrBackground := 0;
  WC.lpszClassName := TBL_TABHOST_CLASS_NAME;
  Windows.RegisterClassA(WC);
  TabHostClassRegistered := True;
end;

procedure EnsureTabFont;
var LF: TLogFont;
begin
  if TabFont <> 0 then Exit;
  FillChar(LF, SizeOf(LF), 0);
  LF.lfHeight := -11;
  LF.lfWeight := FW_NORMAL;
  LF.lfCharSet := DEFAULT_CHARSET;
  LF.lfPitchAndFamily := DEFAULT_PITCH or FF_SWISS;
  StrPCopy(LF.lfFaceName, 'Segoe UI');
  TabFont := CreateFontIndirect(LF);
end;

function CreateTabHost(ParentWnd: HWND;
                       DirtyCB: TGridDirtyCallback;
                       SaveCB:  TGridDirtyCallback): HWND;
var
  Host, TabCtrl, ModeLabel: HWND;
  RC: TRect;
  St: PTabHostState;
begin
  EnsureTabHostClassRegistered;
  EnsureCommonControlsLoaded;
  EnsureTabFont;

  GetClientRect(ParentWnd, RC);
  Host := CreateWindowEx(0, TBL_TABHOST_CLASS_NAME, nil,
                         WS_CHILD or WS_VISIBLE or WS_CLIPCHILDREN,
                         0, 0, RC.Right, RC.Bottom,
                         ParentWnd, 0, HInstance, nil);
  if Host = 0 then Exit(0);

  // Status strip at top showing edit-mode state. Updated from
  // ApplyEditModeUI on F4 toggle. Initial text set after we read
  // the per-instance flag below.
  ModeLabel := CreateWindowExA(0, 'STATIC', '',
                  WS_CHILD or WS_VISIBLE or SS_LEFT or SS_CENTERIMAGE,
                  0, 0, RC.Right, MODE_BAR_HEIGHT,
                  Host, 0, HInstance, nil);
  if (ModeLabel <> 0) and (TabFont <> 0) then
    SendMessage(ModeLabel, WM_SETFONT, WPARAM(TabFont), 1);

  TabCtrl := CreateWindowEx(0, WC_TABCONTROLA, nil,
                            WS_CHILD or WS_VISIBLE or WS_CLIPSIBLINGS or
                            TCS_TABS or TCS_SINGLELINE,
                            0, MODE_BAR_HEIGHT,
                            RC.Right, RC.Bottom - MODE_BAR_HEIGHT,
                            Host, 0, HInstance, nil);
  if TabCtrl = 0 then
  begin
    DestroyWindow(Host);
    Exit(0);
  end;
  if TabFont <> 0 then
    SendMessage(TabCtrl, WM_SETFONT, WPARAM(TabFont), 1);

  New(St);
  FillChar(St^, SizeOf(St^), 0);
  St^.TabCtrl   := TabCtrl;
  St^.ModeLabel := ModeLabel;
  St^.Active    := -1;
  St^.DirtyCB   := DirtyCB;
  SetState(Host, St);

  // Plumb the JSON-edit save callback once, lazily. (It's a global
  // since the subclass proc doesn't have per-instance context other
  // than the parent HWND.)
  JSONEditSaveCB := SaveCB;
  Result := Host;
end;

procedure DestroyTabHostState(HostWnd: HWND);
var St: PTabHostState;
begin
  St := GetState(HostWnd);
  if St = nil then Exit;
  SetState(HostWnd, nil);
  // Drop refs on managed-type fields explicitly before Dispose so
  // Finalize sees a clean record. (ClearAllTabs should have already
  // shrunk Tabs to zero, but be defensive.)
  SetLength(St^.Tabs, 0);
  Dispose(St);
end;

procedure InsertTabItem(St: PTabHostState; Idx: Integer;
                        const Caption: AnsiString);
var
  TIE: TCITEMA;
begin
  FillChar(TIE, SizeOf(TIE), 0);
  TIE.mask := TCIF_TEXT;
  TIE.pszText := PAnsiChar(Caption);
  SendMessageA(St^.TabCtrl, TCM_INSERTITEMA, WPARAM(Idx), LPARAM(@TIE));
end;

procedure AddGridTab(HostWnd: HWND; const Caption: AnsiString;
                     const Cols: TGridColumnArray; Rows: TJSONArray);
var
  St: PTabHostState;
  Grid: HWND;
  E: TTabEntry;
  Idx: Integer;
begin
  St := GetState(HostWnd);
  if St = nil then Exit;
  Grid := CreateGridWindow(HostWnd, Cols, Rows, St^.DirtyCB);
  if Grid = 0 then Exit;
  ShowWindow(Grid, SW_HIDE);  // hidden until activated
  E.Kind    := tcGrid;
  E.Caption := Caption;
  E.Child   := Grid;
  E.Cols    := Cols;
  E.Rows    := Rows;
  Idx := Length(St^.Tabs);
  SetLength(St^.Tabs, Idx + 1);
  St^.Tabs[Idx] := E;
  InsertTabItem(St, Idx, Caption);
end;

procedure AddJSONTab(HostWnd: HWND; const Caption: AnsiString;
                     const InitialText: AnsiString);
const
  ES_STYLES = ES_MULTILINE or ES_AUTOVSCROLL or ES_AUTOHSCROLL or
              ES_NOHIDESEL or ES_WANTRETURN;
  WS_STYLES = WS_CHILD or WS_VSCROLL or WS_HSCROLL or
              WS_BORDER or WS_TABSTOP;
var
  St: PTabHostState;
  Edit: HWND;
  E: TTabEntry;
  Idx: Integer;
  LF: TLogFontW;
  EditFont: HFONT;
  Buf: AnsiString;
  WBuf: WideString;
const
  EDIT_CLASSW: WideString = 'EDIT';
begin
  St := GetState(HostWnd);
  if St = nil then Exit;
  // Create the Edit as a Unicode window so WM_SETTEXT/WM_GETTEXT
  // and WM_CHAR all use UTF-16 internally. Without this, sending
  // UTF-8 bytes via the ANSI WM_SETTEXT path produces cp1252
  // mojibake on multi-byte characters like 'é' or 'ä'.
  Edit := CreateWindowExW(0, PWideChar(EDIT_CLASSW), nil,
                          ES_STYLES or WS_STYLES,
                          0, 0, 100, 100, HostWnd, 0, HInstance, nil);
  if Edit = 0 then Exit;
  ShowWindow(Edit, SW_HIDE);

  // Raise the Edit's text length limit. The default for a multi-line
  // Edit is around 30,000 chars (32k for ANSI, 16k for Unicode in
  // older Windows), which is well below the size of a typical TBL's
  // serialized JSON. Without this:
  //   * the loaded text gets silently truncated (e.g. the closing
  //     "sections" array gets cut off, breaking save validation)
  //   * once the text is at the limit, the Edit refuses any new
  //     character insertion — Delete and Backspace still work
  //     (they reduce length), and typing over a selection works
  //     (also reduces, then needs to add — the add still fails),
  //     which exactly matches the "typing doesn't write anything"
  //     symptom we were chasing.
  // 0x7FFFFFFE is the practical maximum (just under 2 GB).
  SendMessageW(Edit, EM_SETLIMITTEXT, $7FFFFFFE, 0);

  // Fixed-pitch font for JSON
  FillChar(LF, SizeOf(LF), 0);
  LF.lfHeight := -13;
  LF.lfWeight := FW_NORMAL;
  LF.lfCharSet := DEFAULT_CHARSET;
  LF.lfPitchAndFamily := FIXED_PITCH or FF_MODERN;
  WBuf := 'Consolas';
  Move(WBuf[1], LF.lfFaceName[0], (Length(WBuf) + 1) * SizeOf(WideChar));
  EditFont := CreateFontIndirectW(@LF);
  if EditFont = 0 then
  begin
    WBuf := 'Courier New';
    Move(WBuf[1], LF.lfFaceName[0], (Length(WBuf) + 1) * SizeOf(WideChar));
    EditFont := CreateFontIndirectW(@LF);
  end;
  if EditFont <> 0 then
    SendMessage(Edit, WM_SETFONT, WPARAM(EditFont), 1);

  // CRLF-normalized text. Source is UTF-8; decode to UTF-16 for
  // the Unicode Edit. Suppress EN_CHANGE-driven dirty marking
  // during this programmatic load — the file isn't actually modified
  // until the user types something.
  Buf := StringReplace(InitialText, #10, #13#10, [rfReplaceAll]);
  Buf := StringReplace(Buf, #13#13#10, #13#10, [rfReplaceAll]);
  WBuf := UTF8Decode(Buf);
  Inc(IgnoreJSONChangeDepth);
  try
    SendMessageW(Edit, WM_SETTEXT, 0, LPARAM(PWideChar(WBuf)));
  finally
    Dec(IgnoreJSONChangeDepth);
  end;
  SendMessage(Edit, EM_SETSEL, 0, 0);
  SendMessage(Edit, EM_SETMODIFY, 0, 0);

  // Subclass the Edit so we can intercept Ctrl+S, F3/F7/Esc, etc.
  // Try the W variant first (matches our CreateWindowExW). If that
  // somehow failed we'd fall back to A — but on 64-bit Windows both
  // variants normally work for Edit instances.
  if OrigJSONEditProc = 0 then
  begin
    OrigJSONEditProc := GetWindowLongPtrW(Edit, GWLP_WNDPROC);
    if OrigJSONEditProc = 0 then
      OrigJSONEditProc := GetWindowLongPtr(Edit, GWLP_WNDPROC);
  end;
  if SetWindowLongPtrW(Edit, GWLP_WNDPROC, LONG_PTR(@JSONEditSubclassProc)) = 0 then
    SetWindowLongPtr(Edit, GWLP_WNDPROC, LONG_PTR(@JSONEditSubclassProc));

  // Apply current per-instance edit-mode flag (default: read-only on
  // first F3 open, edit mode after the user has pressed F4).
  SendMessageW(Edit, EM_SETREADONLY,
               WPARAM(Ord(not GetInstanceEditMode(HostWnd))), 0);

  E.Kind    := tcJSON;
  E.Caption := Caption;
  E.Child   := Edit;
  E.Rows    := nil;
  Idx := Length(St^.Tabs);
  SetLength(St^.Tabs, Idx + 1);
  St^.Tabs[Idx] := E;
  InsertTabItem(St, Idx, Caption);
end;

// ---------------------------------------------------------------------
//   Config tab — GUI for INI settings
//
// Layout: a custom child window class hosts a column of label +
// control rows (combobox for PreferredGame, checkboxes for the
// boolean flags, then two buttons at the bottom).
//
// The panel WndProc handles WM_COMMAND from its buttons:
//   ID_BTN_SAVE   → harvest current control values, push to
//                   inisettings, flush LoadINI's path to disk.
//   ID_BTN_RESET  → set controls back to defaults (does NOT save
//                   automatically; user must click Save afterwards
//                   to persist).
// ---------------------------------------------------------------------

const
  TBL_CONFIG_CLASS_NAME : PChar = 'TBLLister.ConfigPanelV1';
  ID_CMB_GAME       = 1001;
  ID_CHK_EDITMODE   = 1002;
  ID_CHK_REMEMBER   = 1003;
  ID_CHK_MAXIMIZE   = 1004;
  ID_BTN_SAVE       = 1010;
  ID_BTN_RESET      = 1011;
  ID_BTN_OPENINI    = 1012;
  ID_BTN_EXPORTJSON = 1013;
  ID_LBL_STATUS     = 1020;
  ID_LBL_INIPATH    = 1021;
  ID_LBL_LASTWIN    = 1022;

  // Game tags in same order as the combobox items
  GAME_TAGS: array[0..5] of AnsiString = (
    '', 'Kuro1', 'Kuro2', 'Sora1', 'Ys_X', 'Kai');
  GAME_LABELS: array[0..5] of AnsiString = (
    '(auto-detect)', 'Kuro1 (Trails through Daybreak)',
    'Kuro2 (Trails through Daybreak II)', 'Sora1 (Trails in the Sky FC)',
    'Ys_X', 'Kai');

var
  ConfigPanelClassRegistered: Boolean = False;

function FindGameIndex(const Tag: AnsiString): Integer;
var i: Integer;
begin
  for i := 0 to High(GAME_TAGS) do
    if GAME_TAGS[i] = Tag then Exit(i);
  Result := 0;
end;

procedure SetStatusText(Panel: HWND; const Msg: AnsiString); forward;
procedure SetINIPathText(Panel: HWND; const Path: AnsiString); forward;
procedure SetLastWinText(Panel: HWND; const S: AnsiString); forward;
procedure PopulateInfoLabels(Panel: HWND); forward;

procedure SetStatusText(Panel: HWND; const Msg: AnsiString);
var Lbl: HWND;
begin
  Lbl := GetDlgItem(Panel, ID_LBL_STATUS);
  if Lbl <> 0 then
    SendMessageA(Lbl, WM_SETTEXT, 0, LPARAM(PAnsiChar(Msg)));
end;

procedure SetINIPathText(Panel: HWND; const Path: AnsiString);
var Lbl: HWND;
begin
  Lbl := GetDlgItem(Panel, ID_LBL_INIPATH);
  if Lbl <> 0 then
    SendMessageA(Lbl, WM_SETTEXT, 0, LPARAM(PAnsiChar(Path)));
end;

procedure SetLastWinText(Panel: HWND; const S: AnsiString);
var Lbl: HWND;
begin
  Lbl := GetDlgItem(Panel, ID_LBL_LASTWIN);
  if Lbl <> 0 then
    SendMessageA(Lbl, WM_SETTEXT, 0, LPARAM(PAnsiChar(S)));
end;

procedure OpenINIInExternalEditor(Panel: HWND);
var
  IniPath: AnsiString;
begin
  IniPath := pluginstate.GetIniPath;
  if IniPath = '' then
  begin
    SetStatusText(Panel,
      'No INI path available — TC hasn''t supplied one yet.');
    Exit;
  end;
  // Use ShellExecute "open" verb — Windows decides which app
  // handles .ini files (typically Notepad).
  ShellExecuteA(Panel, 'open', PAnsiChar(IniPath), nil, nil, SW_SHOWNORMAL);
end;

procedure LoadConfigControls(Panel: HWND);
var
  Cmb, Chk: HWND;
  Idx: Integer;
begin
  Cmb := GetDlgItem(Panel, ID_CMB_GAME);
  if Cmb <> 0 then
  begin
    Idx := FindGameIndex(inisettings.GetPreferredGame);
    SendMessage(Cmb, CB_SETCURSEL, WPARAM(Idx), 0);
  end;
  Chk := GetDlgItem(Panel, ID_CHK_EDITMODE);
  if Chk <> 0 then
    SendMessage(Chk, BM_SETCHECK,
                WPARAM(Ord(inisettings.GetDefaultEditMode)), 0);
  Chk := GetDlgItem(Panel, ID_CHK_REMEMBER);
  if Chk <> 0 then
    SendMessage(Chk, BM_SETCHECK,
                WPARAM(Ord(inisettings.GetRememberWindowSize)), 0);
  Chk := GetDlgItem(Panel, ID_CHK_MAXIMIZE);
  if Chk <> 0 then
    SendMessage(Chk, BM_SETCHECK,
                WPARAM(Ord(inisettings.GetMaximizeOnOpen)), 0);

  // Read-only display: INI path + last window state. These let the
  // user see where settings live without digging through TC's
  // Help → About to find the wincmd.ini directory, and confirm
  // that "Remember window size" is actually capturing values.
  PopulateInfoLabels(Panel);
end;

procedure PopulateInfoLabels(Panel: HWND);
var
  IniPath: AnsiString;
  X, Y, W, H: Integer;
  Maximized: Boolean;
  StateStr: AnsiString;
begin
  IniPath := pluginstate.GetIniPath;
  if IniPath = '' then
    SetINIPathText(Panel, 'INI file: (TC has not yet supplied a path)')
  else
    SetINIPathText(Panel, 'INI file: ' + IniPath);

  inisettings.GetLastWindowState(X, Y, W, H, Maximized);
  if (X = -1) and (Y = -1) and (W = -1) and (H = -1) then
    StateStr := 'Last window state: (not yet captured)'
  else
  begin
    StateStr := Format('Last window state: X=%d Y=%d W=%d H=%d',
                       [X, Y, W, H]);
    if Maximized then StateStr := StateStr + ' (maximized)';
  end;
  SetLastWinText(Panel, StateStr);
end;

procedure SaveConfigControls(Panel: HWND);
var
  Cmb, Chk: HWND;
  Idx: Integer;
  IniPath: AnsiString;
begin
  // Harvest control values into inisettings module-level vars
  Cmb := GetDlgItem(Panel, ID_CMB_GAME);
  if Cmb <> 0 then
  begin
    Idx := SendMessage(Cmb, CB_GETCURSEL, 0, 0);
    if (Idx >= 0) and (Idx <= High(GAME_TAGS)) then
      inisettings.SetPreferredGame(GAME_TAGS[Idx]);
  end;
  Chk := GetDlgItem(Panel, ID_CHK_EDITMODE);
  if Chk <> 0 then
    inisettings.SetDefaultEditMode(
      SendMessage(Chk, BM_GETCHECK, 0, 0) = BST_CHECKED);
  Chk := GetDlgItem(Panel, ID_CHK_REMEMBER);
  if Chk <> 0 then
    inisettings.SetRememberWindowSize(
      SendMessage(Chk, BM_GETCHECK, 0, 0) = BST_CHECKED);
  Chk := GetDlgItem(Panel, ID_CHK_MAXIMIZE);
  if Chk <> 0 then
    inisettings.SetMaximizeOnOpen(
      SendMessage(Chk, BM_GETCHECK, 0, 0) = BST_CHECKED);

  // Flush to disk
  IniPath := pluginstate.GetIniPath;
  if IniPath <> '' then
  begin
    inisettings.SaveINI(IniPath);
    SetStatusText(Panel,
      'Saved to ' + IniPath);
  end
  else
    SetStatusText(Panel,
      'Settings updated in memory (no INI path available — TC didn''t supply one yet).');
  // Refresh the read-only display so any newly captured values
  // (e.g. updated INI path on first save) are visible.
  PopulateInfoLabels(Panel);
end;

procedure ResetConfigControls(Panel: HWND);
var Cmb, Chk: HWND;
begin
  Cmb := GetDlgItem(Panel, ID_CMB_GAME);
  if Cmb <> 0 then SendMessage(Cmb, CB_SETCURSEL, 0, 0);   // (auto)
  Chk := GetDlgItem(Panel, ID_CHK_EDITMODE);
  if Chk <> 0 then SendMessage(Chk, BM_SETCHECK, 0, 0);    // unchecked
  Chk := GetDlgItem(Panel, ID_CHK_REMEMBER);
  if Chk <> 0 then SendMessage(Chk, BM_SETCHECK, 1, 0);    // checked
  Chk := GetDlgItem(Panel, ID_CHK_MAXIMIZE);
  if Chk <> 0 then SendMessage(Chk, BM_SETCHECK, 0, 0);    // unchecked
  SetStatusText(Panel,
    'Defaults loaded. Click Save to persist.');
end;

function ConfigPanelWndProc(Wnd: HWND; Msg: UINT;
                            wParam: WPARAM; lParam: LPARAM): LRESULT; stdcall;
var
  CmdId: Word;
begin
  case Msg of
    WM_COMMAND:
      begin
        CmdId := LOWORD(wParam);
        case CmdId of
          ID_BTN_SAVE:
            begin
              try
                SaveConfigControls(Wnd);
              except
                on E: Exception do
                  SetStatusText(Wnd, 'Error: ' + E.Message);
              end;
              Result := 0;
              Exit;
            end;
          ID_BTN_RESET:
            begin
              ResetConfigControls(Wnd);
              Result := 0;
              Exit;
            end;
          ID_BTN_OPENINI:
            begin
              OpenINIInExternalEditor(Wnd);
              Result := 0;
              Exit;
            end;
          ID_BTN_EXPORTJSON:
            begin
              if Assigned(ExportJSONCallback) then
                ExportJSONCallback(GetParent(Wnd));
              Result := 0;
              Exit;
            end;
        end;
      end;
    WM_ERASEBKGND:
      begin
        // Use the standard dialog background colour so the panel
        // looks consistent with TC's other property dialogs.
        Result := 1;
        Exit;
      end;
    WM_KEYDOWN:
      begin
        // Forward F3/F7/Ctrl+F (search) and Esc (close Lister) to
        // the TC parent. F4 toggles edit mode via the host.
        // (The host = our parent = the tab-host window.)
        if (wParam = VK_F3) or (wParam = VK_F7) or
           ((wParam = $46) and ((GetKeyState(VK_CONTROL) and $8000) <> 0)) then
        begin
          PostMessage(GetParent(GetParent(Wnd)), WM_KEYDOWN, wParam, lParam);
          Result := 0;
          Exit;
        end;
        if wParam = VK_ESCAPE then
        begin
          PostMessage(GetParent(GetParent(Wnd)), WM_KEYDOWN, VK_ESCAPE, lParam);
          Result := 0;
          Exit;
        end;
        if wParam = VK_F4 then
        begin
          SendMessage(GetParent(Wnd), WM_USER + 0, 0, 0);   // WM_TBL_TOGGLE_EDIT_MODE
          Result := 0;
          Exit;
        end;
      end;
  end;
  Result := DefWindowProc(Wnd, Msg, wParam, lParam);
end;

procedure EnsureConfigPanelClassRegistered;
var WC: WNDCLASSA;
begin
  if ConfigPanelClassRegistered then Exit;
  FillChar(WC, SizeOf(WC), 0);
  WC.style         := CS_HREDRAW or CS_VREDRAW;
  WC.lpfnWndProc   := @ConfigPanelWndProc;
  WC.hInstance     := HInstance;
  WC.hCursor       := LoadCursor(0, IDC_ARROW);
  WC.hbrBackground := HBRUSH(COLOR_BTNFACE + 1);
  WC.lpszClassName := TBL_CONFIG_CLASS_NAME;
  Windows.RegisterClassA(WC);
  ConfigPanelClassRegistered := True;
end;

procedure AddConfigTab(HostWnd: HWND; const Caption: AnsiString);
var
  St: PTabHostState;
  Panel: HWND;
  Lbl: HWND;
  Cmb, Chk, Btn, Status: HWND;
  E: TTabEntry;
  Idx: Integer;
  i: Integer;
  PanelFont: HFONT;
  LF: TLogFont;
  Y: Integer;
const
  ROW_HEIGHT = 28;
  LABEL_WIDTH = 200;
  CTRL_LEFT = 220;
  CTRL_WIDTH = 260;
  PAD_LEFT = 20;
  PAD_TOP  = 20;
begin
  St := GetState(HostWnd);
  if St = nil then Exit;
  EnsureConfigPanelClassRegistered;

  // Standard UI font (Segoe UI 9pt — looks native on modern Windows)
  FillChar(LF, SizeOf(LF), 0);
  LF.lfHeight := -12;
  LF.lfWeight := FW_NORMAL;
  LF.lfCharSet := DEFAULT_CHARSET;
  StrPCopy(LF.lfFaceName, 'Segoe UI');
  PanelFont := CreateFontIndirect(LF);
  if PanelFont = 0 then
  begin
    StrPCopy(LF.lfFaceName, 'Tahoma');
    PanelFont := CreateFontIndirect(LF);
  end;

  Panel := CreateWindowExA(0, TBL_CONFIG_CLASS_NAME, nil,
                           WS_CHILD,
                           0, 0, 100, 100, HostWnd, 0, HInstance, nil);
  if Panel = 0 then Exit;
  ShowWindow(Panel, SW_HIDE);

  // -------- Row 1: PreferredGame --------
  Y := PAD_TOP;
  Lbl := CreateWindowExA(0, 'STATIC', 'Preferred game (header tie-break):',
           WS_CHILD or WS_VISIBLE or SS_LEFT,
           PAD_LEFT, Y + 4, LABEL_WIDTH, 18,
           Panel, 0, HInstance, nil);
  if PanelFont <> 0 then SendMessage(Lbl, WM_SETFONT, WPARAM(PanelFont), 0);

  Cmb := CreateWindowExA(0, 'COMBOBOX', nil,
           WS_CHILD or WS_VISIBLE or WS_VSCROLL or
           CBS_DROPDOWNLIST or WS_TABSTOP,
           CTRL_LEFT, Y, CTRL_WIDTH, 200,
           Panel, HMENU(ID_CMB_GAME), HInstance, nil);
  if PanelFont <> 0 then SendMessage(Cmb, WM_SETFONT, WPARAM(PanelFont), 0);
  for i := 0 to High(GAME_LABELS) do
    SendMessageA(Cmb, CB_ADDSTRING, 0, LPARAM(PAnsiChar(GAME_LABELS[i])));

  // -------- Row 2: DefaultEditMode --------
  Inc(Y, ROW_HEIGHT);
  Chk := CreateWindowExA(0, 'BUTTON',
           'Default edit mode (open in edit mode, skip F4 toggle)',
           WS_CHILD or WS_VISIBLE or BS_AUTOCHECKBOX or WS_TABSTOP,
           PAD_LEFT, Y + 2, LABEL_WIDTH + CTRL_WIDTH, 22,
           Panel, HMENU(ID_CHK_EDITMODE), HInstance, nil);
  if PanelFont <> 0 then SendMessage(Chk, WM_SETFONT, WPARAM(PanelFont), 0);

  // -------- Row 3: RememberWindowSize --------
  Inc(Y, ROW_HEIGHT);
  Chk := CreateWindowExA(0, 'BUTTON',
           'Remember window position and size between sessions',
           WS_CHILD or WS_VISIBLE or BS_AUTOCHECKBOX or WS_TABSTOP,
           PAD_LEFT, Y + 2, LABEL_WIDTH + CTRL_WIDTH, 22,
           Panel, HMENU(ID_CHK_REMEMBER), HInstance, nil);
  if PanelFont <> 0 then SendMessage(Chk, WM_SETFONT, WPARAM(PanelFont), 0);

  // -------- Row 4: MaximizeOnOpen --------
  Inc(Y, ROW_HEIGHT);
  Chk := CreateWindowExA(0, 'BUTTON',
           'Always maximize Lister on open (overrides remembered size)',
           WS_CHILD or WS_VISIBLE or BS_AUTOCHECKBOX or WS_TABSTOP,
           PAD_LEFT, Y + 2, LABEL_WIDTH + CTRL_WIDTH, 22,
           Panel, HMENU(ID_CHK_MAXIMIZE), HInstance, nil);
  if PanelFont <> 0 then SendMessage(Chk, WM_SETFONT, WPARAM(PanelFont), 0);

  // -------- Row 5: Buttons --------
  Inc(Y, ROW_HEIGHT * 2);
  Btn := CreateWindowExA(0, 'BUTTON', 'Save',
           WS_CHILD or WS_VISIBLE or BS_DEFPUSHBUTTON or WS_TABSTOP,
           PAD_LEFT, Y, 100, 28,
           Panel, HMENU(ID_BTN_SAVE), HInstance, nil);
  if PanelFont <> 0 then SendMessage(Btn, WM_SETFONT, WPARAM(PanelFont), 0);

  Btn := CreateWindowExA(0, 'BUTTON', 'Reset to defaults',
           WS_CHILD or WS_VISIBLE or BS_PUSHBUTTON or WS_TABSTOP,
           PAD_LEFT + 110, Y, 140, 28,
           Panel, HMENU(ID_BTN_RESET), HInstance, nil);
  if PanelFont <> 0 then SendMessage(Btn, WM_SETFONT, WPARAM(PanelFont), 0);

  Btn := CreateWindowExA(0, 'BUTTON', 'Open INI in editor',
           WS_CHILD or WS_VISIBLE or BS_PUSHBUTTON or WS_TABSTOP,
           PAD_LEFT + 260, Y, 160, 28,
           Panel, HMENU(ID_BTN_OPENINI), HInstance, nil);
  if PanelFont <> 0 then SendMessage(Btn, WM_SETFONT, WPARAM(PanelFont), 0);

  // Row 5b: Export TBL → JSON (separate row so it stands out from
  // the INI-related buttons above).
  Inc(Y, 36);
  Btn := CreateWindowExA(0, 'BUTTON', 'Export current TBL as JSON...',
           WS_CHILD or WS_VISIBLE or BS_PUSHBUTTON or WS_TABSTOP,
           PAD_LEFT, Y, 250, 28,
           Panel, HMENU(ID_BTN_EXPORTJSON), HInstance, nil);
  if PanelFont <> 0 then SendMessage(Btn, WM_SETFONT, WPARAM(PanelFont), 0);

  // -------- Row 6: INI path (read-only) --------
  Inc(Y, 40);
  Lbl := CreateWindowExA(0, 'STATIC', '',
           WS_CHILD or WS_VISIBLE or SS_LEFT or $00008000 {SS_PATHELLIPSIS},
           PAD_LEFT, Y, LABEL_WIDTH + CTRL_WIDTH + 200, 18,
           Panel, HMENU(ID_LBL_INIPATH), HInstance, nil);
  if PanelFont <> 0 then SendMessage(Lbl, WM_SETFONT, WPARAM(PanelFont), 0);

  // -------- Row 7: Last window state (read-only) --------
  Inc(Y, 22);
  Lbl := CreateWindowExA(0, 'STATIC', '',
           WS_CHILD or WS_VISIBLE or SS_LEFT,
           PAD_LEFT, Y, LABEL_WIDTH + CTRL_WIDTH + 200, 18,
           Panel, HMENU(ID_LBL_LASTWIN), HInstance, nil);
  if PanelFont <> 0 then SendMessage(Lbl, WM_SETFONT, WPARAM(PanelFont), 0);

  // -------- Row 8: Status line --------
  Inc(Y, 30);
  Status := CreateWindowExA(0, 'STATIC', '',
              WS_CHILD or WS_VISIBLE or SS_LEFT,
              PAD_LEFT, Y, LABEL_WIDTH + CTRL_WIDTH, 18,
              Panel, HMENU(ID_LBL_STATUS), HInstance, nil);
  if PanelFont <> 0 then SendMessage(Status, WM_SETFONT, WPARAM(PanelFont), 0);

  // Populate from current settings
  LoadConfigControls(Panel);

  E.Kind    := tcConfig;
  E.Caption := Caption;
  E.Child   := Panel;
  E.Rows    := nil;
  Idx := Length(St^.Tabs);
  SetLength(St^.Tabs, Idx + 1);
  St^.Tabs[Idx] := E;
  InsertTabItem(St, Idx, Caption);
end;

procedure ShowFirstTab(HostWnd: HWND);
var St: PTabHostState;
begin
  St := GetState(HostWnd);
  if (St = nil) or (Length(St^.Tabs) = 0) then Exit;
  ShowTabAt(St, 0);
end;

procedure SetActiveTab(HostWnd: HWND; Idx: Integer);
var St: PTabHostState;
begin
  St := GetState(HostWnd);
  if (St = nil) or (Length(St^.Tabs) = 0) then Exit;
  if (Idx < 0) or (Idx >= Length(St^.Tabs)) then Idx := 0;
  SendMessage(St^.TabCtrl, TCM_SETCURSEL, WPARAM(Idx), 0);
  ShowTabAt(St, Idx);
end;

procedure ClearAllTabs(HostWnd: HWND);
var
  St: PTabHostState;
  i: Integer;
begin
  St := GetState(HostWnd);
  if St = nil then Exit;
  // Remove all tab items first so the tab control doesn't try to
  // notify-back-into us during destruction.
  SendMessage(St^.TabCtrl, TCM_DELETEALLITEMS, 0, 0);
  // Destroy each child window. For grids we also clean up state.
  // IMPORTANT: DestroyGridState before DestroyWindow, so the grid's
  // own subclass procs route through the nil-state fallback path
  // when they see WM_NCDESTROY etc.
  for i := 0 to High(St^.Tabs) do
  begin
    if St^.Tabs[i].Kind = tcGrid then
      DestroyGridState(St^.Tabs[i].Child);
    // Unsubclass JSON Edit if applicable, so WM_NCDESTROY doesn't
    // round-trip through our subclass proc. Use the W variant — we
    // subclassed with SetWindowLongPtrW, so we MUST restore with W
    // too. Mixing A/W has been observed to crash the host on close.
    if (St^.Tabs[i].Kind = tcJSON) and (St^.Tabs[i].Child <> 0)
       and (OrigJSONEditProc <> 0) then
      SetWindowLongPtrW(St^.Tabs[i].Child, GWLP_WNDPROC, OrigJSONEditProc);
    if St^.Tabs[i].Child <> 0 then
      DestroyWindow(St^.Tabs[i].Child);
    St^.Tabs[i].Child := 0;
    // Drop refs on managed-type fields in the entry now so they
    // can't be double-finalized when SetLength shrinks the array.
    St^.Tabs[i].Caption := '';
    St^.Tabs[i].Cols := nil;
    St^.Tabs[i].Rows := nil;
  end;
  SetLength(St^.Tabs, 0);
  St^.Active := -1;
end;

function GetJSONTabEditWnd(HostWnd: HWND): HWND;
var
  St: PTabHostState;
  i: Integer;
begin
  Result := 0;
  St := GetState(HostWnd);
  if St = nil then Exit;
  for i := 0 to High(St^.Tabs) do
    if St^.Tabs[i].Kind = tcJSON then
      Exit(St^.Tabs[i].Child);
end;

function GetActiveTabIndex(HostWnd: HWND): Integer;
var St: PTabHostState;
begin
  Result := -1;
  St := GetState(HostWnd);
  if St <> nil then Result := St^.Active;
end;

function GetTabKind(HostWnd: HWND; Idx: Integer): TTabContentKind;
var St: PTabHostState;
begin
  Result := tcGrid;
  St := GetState(HostWnd);
  if (St = nil) or (Idx < 0) or (Idx >= Length(St^.Tabs)) then Exit;
  Result := St^.Tabs[Idx].Kind;
end;

function GetTabChild(HostWnd: HWND; Idx: Integer): HWND;
var St: PTabHostState;
begin
  Result := 0;
  St := GetState(HostWnd);
  if (St = nil) or (Idx < 0) or (Idx >= Length(St^.Tabs)) then Exit;
  Result := St^.Tabs[Idx].Child;
end;

function GetTabCount(HostWnd: HWND): Integer;
var St: PTabHostState;
begin
  Result := 0;
  St := GetState(HostWnd);
  if St <> nil then Result := Length(St^.Tabs);
end;

procedure SelectTabAt(HostWnd: HWND; Idx: Integer);
var
  St: PTabHostState;
  Child: HWND;
begin
  St := GetState(HostWnd);
  if (St = nil) or (Idx < 0) or (Idx >= Length(St^.Tabs)) then Exit;
  SendMessage(St^.TabCtrl, TCM_SETCURSEL, WPARAM(Idx), 0);
  ShowTabAt(St, Idx);
  // Force a full repaint of the newly-shown tab's child. Without
  // this, LVS_OWNERDATA grids that were just made visible (e.g. via
  // search auto-switching tabs) may render in a stale state where
  // only the focused/selected row paints and the rest stays blank.
  Child := St^.Tabs[Idx].Child;
  if Child <> 0 then
  begin
    InvalidateRect(Child, nil, True);
    UpdateWindow(Child);
  end;
end;

// ---------------------------------------------------------------------
//   Window-state restore / capture
//
// Lives in tabwin so the WM_TIMER deferred-apply can call into it
// without going through tbl_wlx (which would create a circular dep).
// ---------------------------------------------------------------------

procedure ApplyWindowStateNow(HostWnd: HWND);
var
  Lister: HWND;
  X, Y, W, H: Integer;
  Maximized: Boolean;
begin
  // Walk up: HostWnd is our tab-host (child of Lister parent). The
  // top-level Lister frame is the root ancestor. (For Quick View
  // panel, this lands on TC's main window — we still apply, but
  // the user-visible effect there is "TC main window" which is
  // their own decision via MaximizeOnOpen.)
  Lister := GetParent(HostWnd);
  if Lister = 0 then Exit;
  Lister := GetAncestor(Lister, GA_ROOT);
  if Lister = 0 then Exit;

  if inisettings.GetMaximizeOnOpen then
  begin
    if not IsZoomed(Lister) then
      ShowWindow(Lister, SW_MAXIMIZE);
    Exit;
  end;

  if not inisettings.GetRememberWindowSize then Exit;

  inisettings.GetLastWindowState(X, Y, W, H, Maximized);
  if Maximized then
  begin
    if not IsZoomed(Lister) then
      ShowWindow(Lister, SW_MAXIMIZE);
    Exit;
  end;
  // Sanity-check the saved coords: if any are unset (-1) or the
  // size is degenerate, leave the window alone.
  if (X = -1) or (Y = -1) or (W <= 50) or (H <= 50) then Exit;
  // Make sure the saved rect lands at least partially on screen
  // (multi-monitor users moving setups around).
  if (X < -10000) or (X > 30000) or (Y < -10000) or (Y > 30000) then Exit;

  SetWindowPos(Lister, 0, X, Y, W, H,
               SWP_NOZORDER or SWP_NOACTIVATE);
end;

procedure SchedulePostLoadWindowApply(HostWnd: HWND);
begin
  if HostWnd = 0 then Exit;
  // 100ms is enough for TC to finish its plugin-loading state
  // machine. The timer fires once via WM_TIMER; the handler kills
  // it before doing the actual apply.
  SetTimer(HostWnd, TIMER_ID_APPLY_WINSTATE, 100, nil);
end;

procedure CaptureWindowStateOnClose(HostWnd: HWND);
var
  Lister: HWND;
  R: TRect;
  Pl: TWindowPlacement;
  IsMax: Boolean;
begin
  if HostWnd = 0 then Exit;
  Lister := GetParent(HostWnd);
  if Lister = 0 then Exit;
  Lister := GetAncestor(Lister, GA_ROOT);
  if Lister = 0 then Exit;

  // Use GetWindowPlacement so we record the *restore* rect even if
  // the user had it maximized, so unmaximizing later gives a
  // reasonable size.
  FillChar(Pl, SizeOf(Pl), 0);
  Pl.length := SizeOf(Pl);
  if not GetWindowPlacement(Lister, @Pl) then Exit;

  IsMax := (Pl.showCmd = SW_SHOWMAXIMIZED);
  R := Pl.rcNormalPosition;
  inisettings.SetLastWindowState(R.Left, R.Top,
                                 R.Right - R.Left,
                                 R.Bottom - R.Top, IsMax);
end;

end.
