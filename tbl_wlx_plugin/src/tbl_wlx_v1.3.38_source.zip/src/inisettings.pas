unit inisettings;
{$mode objfpc}{$H+}

// Persist user preferences across Lister sessions. TC hands us an INI
// path via ListSetDefaultParams (typically wincmd_ini-side
// `wincmd.ini` or a plugin-specific `tbl_wlx.ini` next to the DLL).
//
// We use Win32's GetPrivateProfileString/WritePrivateProfileString
// directly — this is what TC plugins are expected to use, and it
// gracefully handles the file not existing yet.
//
// Currently persisted:
//   [TBL_WLX]
//     PreferredGame      = Kuro1   ; '', Kuro1, Kuro2, Sora1, Ys_X
//     DefaultEditMode    = 0       ; 0 = read-only on F3 (default);
//                                  ; 1 = edit mode on F3 (skip F4)
//     RememberWindowSize = 1       ; 1 = restore Lister parent size
//                                  ; on next open (default 1)
//     MaximizeOnOpen     = 0       ; 1 = always maximize Lister on
//                                  ; open (overrides RememberWindowSize)
//     LastWinX, LastWinY, LastWinW, LastWinH, LastWinMax
//                                  ; updated automatically when
//                                  ; the window closes (do not edit
//                                  ; manually unless you want to
//                                  ; force a position).
//
// The unit reads on first call (lazily, idempotent). Writes go
// through immediately so Windows' WritePrivateProfileString flushes
// to disk.

interface

{$ifdef WINDOWS}
uses Windows, SysUtils;
{$else}
uses SysUtils;
{$endif}

const
  INI_SECTION = 'TBL_WLX';

// Read settings from the given path. Empty path = no-op (defaults
// stay in place).
procedure LoadINI(const Path: AnsiString);

// Write the current PreferredGame back to the INI. Empty path = no-op.
procedure SaveINI(const Path: AnsiString);

// Accessors. Game-tag enum is informational, validated case-sensitive
// against KuroTools' set.
function GetPreferredGame: AnsiString;
procedure SetPreferredGame(const G: AnsiString);

// Default edit-mode flag. False (read-only) is the default for new
// installs. Users who want F3 to open straight in edit mode can set
// `DefaultEditMode=1` in [TBL_WLX].
function GetDefaultEditMode: Boolean;
procedure SetDefaultEditMode(Value: Boolean);

// Persisted Lister-window state. Values are -1 / 0 if unset.
function  GetRememberWindowSize: Boolean;
procedure SetRememberWindowSize(Value: Boolean);
function  GetMaximizeOnOpen: Boolean;
procedure SetMaximizeOnOpen(Value: Boolean);
procedure GetLastWindowState(out X, Y, W, H: Integer; out Maximized: Boolean);
procedure SetLastWindowState(X, Y, W, H: Integer; Maximized: Boolean);

// Persisted sub-grid (nested-struct popup) geometry. Same conventions
// as the Lister-window state — -1 means "unset, use default offset
// from the parent grid". Honoured/written only when
// RememberWindowSize is on.
procedure GetLastSubGridState(out X, Y, W, H: Integer);
procedure SetLastSubGridState(X, Y, W, H: Integer);

// Sanity check: is G one of the accepted game tags? Empty string
// (auto-detect) is also accepted.
function IsValidGameTag(const G: AnsiString): Boolean;

implementation

var
  PreferredGame: AnsiString = '';
  DefaultEditMode: Boolean = False;
  RememberWindowSize: Boolean = True;    // default ON
  MaximizeOnOpen: Boolean = False;
  LastWinX: Integer = -1;                // -1 = unset
  LastWinY: Integer = -1;
  LastWinW: Integer = -1;
  LastWinH: Integer = -1;
  LastWinMax: Boolean = False;
  // Sub-grid popup geometry (no maximize — popups don't get
  // maximized in v1.x).
  LastSubX: Integer = -1;
  LastSubY: Integer = -1;
  LastSubW: Integer = -1;
  LastSubH: Integer = -1;

function IsValidGameTag(const G: AnsiString): Boolean;
begin
  Result :=
    (G = '') or
    (G = 'Kuro1') or
    (G = 'Kuro2') or
    (G = 'Sora1') or
    (G = 'Ys_X')  or
    (G = 'Kai');   // Kuro1 internal tag in some schemas
end;

function GetPreferredGame: AnsiString;
begin
  Result := PreferredGame;
end;

procedure SetPreferredGame(const G: AnsiString);
begin
  if IsValidGameTag(G) then PreferredGame := G;
end;

function GetDefaultEditMode: Boolean;
begin
  Result := DefaultEditMode;
end;

procedure SetDefaultEditMode(Value: Boolean);
begin
  DefaultEditMode := Value;
end;

function GetRememberWindowSize: Boolean;
begin
  Result := RememberWindowSize;
end;

procedure SetRememberWindowSize(Value: Boolean);
begin
  RememberWindowSize := Value;
end;

function GetMaximizeOnOpen: Boolean;
begin
  Result := MaximizeOnOpen;
end;

procedure SetMaximizeOnOpen(Value: Boolean);
begin
  MaximizeOnOpen := Value;
end;

procedure GetLastWindowState(out X, Y, W, H: Integer; out Maximized: Boolean);
begin
  X := LastWinX;
  Y := LastWinY;
  W := LastWinW;
  H := LastWinH;
  Maximized := LastWinMax;
end;

procedure SetLastWindowState(X, Y, W, H: Integer; Maximized: Boolean);
begin
  LastWinX := X;
  LastWinY := Y;
  LastWinW := W;
  LastWinH := H;
  LastWinMax := Maximized;
end;

procedure GetLastSubGridState(out X, Y, W, H: Integer);
begin
  X := LastSubX;
  Y := LastSubY;
  W := LastSubW;
  H := LastSubH;
end;

procedure SetLastSubGridState(X, Y, W, H: Integer);
begin
  LastSubX := X;
  LastSubY := Y;
  LastSubW := W;
  LastSubH := H;
end;

function ParseBoolStr(const S: AnsiString; Def: Boolean): Boolean;
var T: AnsiString;
begin
  T := LowerCase(Trim(S));
  if (T = '1') or (T = 'true') or (T = 'yes') or (T = 'on') then
    Result := True
  else if (T = '0') or (T = 'false') or (T = 'no') or (T = 'off') then
    Result := False
  else
    Result := Def;
end;

function ParseIntStr(const S: AnsiString; Def: Integer): Integer;
var Code: Integer;
begin
  Val(Trim(S), Result, Code);
  if Code <> 0 then Result := Def;
end;

// Read a string key into a fresh AnsiString, capping at 255 chars
// (more than enough for our tags and flag values).
function ReadINIString(const Section, Key, Path: AnsiString;
                       const Default: AnsiString): AnsiString;
{$ifdef WINDOWS}
var
  Buf: array[0..255] of AnsiChar;
  Len: DWORD;
begin
  if Path = '' then Exit(Default);
  FillChar(Buf, SizeOf(Buf), 0);
  Len := GetPrivateProfileStringA(
           PAnsiChar(Section), PAnsiChar(Key),
           PAnsiChar(Default), @Buf[0], SizeOf(Buf) - 1,
           PAnsiChar(Path));
  if Len = 0 then
    Result := Default
  else
    Result := AnsiString(StrPas(@Buf[0]));
end;
{$else}
begin
  // Non-Windows builds (Linux smoke tests): no INI support; always
  // return the default so the rest of the codebase behaves as if
  // no INI file existed.
  Result := Default;
end;
{$endif}

procedure WriteINIString(const Section, Key, Value, Path: AnsiString);
{$ifdef WINDOWS}
begin
  if Path = '' then Exit;
  WritePrivateProfileStringA(
    PAnsiChar(Section), PAnsiChar(Key),
    PAnsiChar(Value), PAnsiChar(Path));
end;
{$else}
begin
  // Non-Windows: no-op. Tests don't exercise this path.
end;
{$endif}

procedure LoadINI(const Path: AnsiString);
var
  G, S: AnsiString;
begin
  if Path = '' then Exit;
  G := ReadINIString(INI_SECTION, 'PreferredGame', Path, '');
  if IsValidGameTag(G) then
    PreferredGame := G;
  // Boolean flags
  DefaultEditMode := ParseBoolStr(
    ReadINIString(INI_SECTION, 'DefaultEditMode', Path, '0'), False);
  RememberWindowSize := ParseBoolStr(
    ReadINIString(INI_SECTION, 'RememberWindowSize', Path, '1'), True);
  MaximizeOnOpen := ParseBoolStr(
    ReadINIString(INI_SECTION, 'MaximizeOnOpen', Path, '0'), False);
  // Last window state
  LastWinX := ParseIntStr(
    ReadINIString(INI_SECTION, 'LastWinX', Path, '-1'), -1);
  LastWinY := ParseIntStr(
    ReadINIString(INI_SECTION, 'LastWinY', Path, '-1'), -1);
  LastWinW := ParseIntStr(
    ReadINIString(INI_SECTION, 'LastWinW', Path, '-1'), -1);
  LastWinH := ParseIntStr(
    ReadINIString(INI_SECTION, 'LastWinH', Path, '-1'), -1);
  LastWinMax := ParseBoolStr(
    ReadINIString(INI_SECTION, 'LastWinMax', Path, '0'), False);
  // Sub-grid popup geometry
  LastSubX := ParseIntStr(
    ReadINIString(INI_SECTION, 'LastSubX', Path, '-1'), -1);
  LastSubY := ParseIntStr(
    ReadINIString(INI_SECTION, 'LastSubY', Path, '-1'), -1);
  LastSubW := ParseIntStr(
    ReadINIString(INI_SECTION, 'LastSubW', Path, '-1'), -1);
  LastSubH := ParseIntStr(
    ReadINIString(INI_SECTION, 'LastSubH', Path, '-1'), -1);
  // Touch S to silence "var unused" if we narrow the function later
  S := '';
end;

procedure SaveINI(const Path: AnsiString);
  function I2S(V: Integer): AnsiString;
  begin Str(V, Result); end;
  function B2S(V: Boolean): AnsiString;
  begin if V then Result := '1' else Result := '0'; end;
begin
  if Path = '' then Exit;
  WriteINIString(INI_SECTION, 'PreferredGame',      PreferredGame, Path);
  WriteINIString(INI_SECTION, 'DefaultEditMode',    B2S(DefaultEditMode), Path);
  WriteINIString(INI_SECTION, 'RememberWindowSize', B2S(RememberWindowSize), Path);
  WriteINIString(INI_SECTION, 'MaximizeOnOpen',     B2S(MaximizeOnOpen), Path);
  WriteINIString(INI_SECTION, 'LastWinX',           I2S(LastWinX), Path);
  WriteINIString(INI_SECTION, 'LastWinY',           I2S(LastWinY), Path);
  WriteINIString(INI_SECTION, 'LastWinW',           I2S(LastWinW), Path);
  WriteINIString(INI_SECTION, 'LastWinH',           I2S(LastWinH), Path);
  WriteINIString(INI_SECTION, 'LastWinMax',         B2S(LastWinMax), Path);
  WriteINIString(INI_SECTION, 'LastSubX',            I2S(LastSubX), Path);
  WriteINIString(INI_SECTION, 'LastSubY',            I2S(LastSubY), Path);
  WriteINIString(INI_SECTION, 'LastSubW',            I2S(LastSubW), Path);
  WriteINIString(INI_SECTION, 'LastSubH',            I2S(LastSubH), Path);
end;

end.
