unit zstddec;
{$mode objfpc}{$H+}

// ZSTD decompression: thin wrapper around the official ZSTD reference
// single-file decoder (contrib/single_file_libs/zstddeclib.c). The C
// side is built once into zstdobj.o sitting next to this .pas; fpc
// pulls it in via the {$L} directive at the bottom.
//
// libc symbols (memcpy/memset/malloc/calloc/free/__chkstk_ms) come
// from the libc_stubs unit — make sure it's in `uses` for any DLL
// that links zstdobj.o.

interface

uses libc_stubs;

// ZSTD_decompress returns the produced byte count on success, or a
// large unsigned error code (use ZSTD_isError to distinguish).
function ZSTD_decompress(Dst: PByte; DstCapacity: PtrUInt;
                         Src: PByte; SrcSize: PtrUInt): PtrUInt; cdecl; external;

function ZSTD_isError(Code: PtrUInt): LongInt; cdecl; external;

// Returns the uncompressed size from the zstd frame header. The frame
// must include the FCS field (which is the case for everything our
// compressCLE counterpart emits).
function ZSTD_getFrameContentSize(Src: PByte; SrcSize: PtrUInt): QWord; cdecl; external;

// Returns the actual byte length of the zstd frame within Src. Lets
// us skip any trailing padding the CLE wrapper may have appended.
function ZSTD_findFrameCompressedSize(Src: PByte; SrcSize: PtrUInt): PtrUInt; cdecl; external;

implementation

{$ifdef WINDOWS}
{$L zstdobj_win64.o}
{$else}
{$L zstdobj.o}
{$endif}

end.
