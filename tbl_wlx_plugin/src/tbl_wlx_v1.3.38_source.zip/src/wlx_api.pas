unit wlx_api;
{$mode objfpc}{$H+}

// Total Commander Lister (.wlx) plugin API constants and types.
// Reference: Total Commander SDK listplug.h (https://www.ghisler.com/plugins.htm)
//
// We re-declare the constants here so we don't depend on any external
// header file at compile time. Numeric values are taken from the TC
// SDK and verified against existing open-source WLX plugins.

interface

uses Windows;

const
  // ---------------------------------------------------------------
  // ListLoad ShowFlags (passed by Lister when opening a file).
  // The plugin should respect these where it makes sense; for our
  // structured TBL viewer most flags don't apply (we render JSON
  // text not raw bytes), but lcp_quickview matters because TC uses
  // it to ask for a preview pane rather than a full Lister window.
  // ---------------------------------------------------------------
  lcp_wraptext      = 1;     // wrap text mode
  lcp_fittowindow   = 2;     // fit large image to window
  lcp_ansi          = 4;     // ANSI charset (vs OEM)
  lcp_ascii         = 8;     // force ASCII view
  lcp_variable      = 16;    // variable line width
  lcp_forceshow     = 32;    // force showing even if format isn't ours
  lcp_fitlargeronly = 64;    // fit only if larger than window
  lcp_center        = 128;   // center contents
  lcp_quickview     = 256;   // quick preview pane (not full Lister)

  // ---------------------------------------------------------------
  // ListSendCommand commands.
  // Lister calls this when the user picks an item from its menus
  // or when the parent window needs the plugin to react.
  // ---------------------------------------------------------------
  LCMD_FINDFIRST  = 0;       // start a fresh search (F7 typed text)
  LCMD_FINDNEXT   = 1;       // continue search (F3)
  LCMD_COPY       = 2;       // copy selection
  LCMD_NEWPARAMS  = 3;       // ShowFlags changed mid-view
  LCMD_QUICKVIEW  = 4;       // quickview-mode toggle
  LCMD_RELOAD     = 5;       // reload current file (F2 in Lister)
  LCMD_SELECTALL  = 6;       // Ctrl+A
  LCMD_SETPERCENT = 7;       // set vertical scroll position

  // ---------------------------------------------------------------
  // ListSearchText flags
  // ---------------------------------------------------------------
  lcs_findfirst   = 0;
  lcs_matchcase   = 1;
  lcs_wholewords  = 2;
  lcs_backwards   = 4;

  // ---------------------------------------------------------------
  // Notification codes (sent via ListNotificationReceived from
  // Lister to the plugin). Most plugins ignore these.
  // ---------------------------------------------------------------
  LISTPLUGIN_OK   = 0;
  LISTPLUGIN_ERROR= 1;

  // Default-params struct version (we accept any that's >= our
  // expected size, since TC has only ever extended this struct).
  LISTDEFAULTPARAMS_DEFAULT_SIZE = 16;

type
  // Passed to ListSetDefaultParams — gives us the path to the
  // plugin's INI file (where TC saves user-tweaked options) and
  // a TC version code.
  TListDefaultParamStruct = record
    Size:           Integer;     // sizeof of this struct
    PluginInterfaceVersionLow: Integer;
    PluginInterfaceVersionHi:  Integer;
    DefaultIniName: array[0..MAX_PATH-1] of AnsiChar;
  end;
  PListDefaultParamStruct = ^TListDefaultParamStruct;

implementation

end.
