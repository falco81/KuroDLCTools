unit pluginstate;
{$mode objfpc}{$H+}

// Per-window state for the TBL Lister plugin.
//
// Lister can open multiple files in parallel (multiple Lister windows
// or quickview panes), each handed to us via a separate ListLoad call.
// The HWND we return is the key to look state up later when ListSendCommand
// or ListCloseWindow is called against that window.
//
// One global TSchemaDB is shared by every window — it's loaded once
// from `schemas/` next to the DLL on first use and cached forever.
// One TInstance lives per open Lister window.
//
// Locking: we keep a critical section around the global state because
// TC may call our entry points from multiple threads (specifically the
// background indexer in some configurations).

interface

uses
  Windows, Classes, SysUtils,
  fpjson,
  tblschemas, tblfile;

type
  // Per-window state. Two views share the same parsed TBL data:
  //   JSON view  — single Edit control with formatted JSON text
  //   Grid view  — one ListView per section (TC menu / F11 cycles)
  //
  // Only one view is visible at a time. The other is hidden via
  // ShowWindow. Switch points re-render the visible side from the
  // currently authoritative TJSONArray rows; if the user has been
  // editing JSON, those edits are parsed into Tbl before switching
  // to grid (and vice versa).
  TViewMode = (vmJSON, vmGrid);

  TInstance = class
  public
    HostWnd:       HWND;       // our owned child window of the Lister parent
    EditWnd:       HWND;       // JSON Edit control (always allocated)
    GridWnd:       HWND;       // grid ListView for the active section (lazy)
    GridSectionIdx: Integer;   // which section the grid is currently showing
    FilePath:      AnsiString;
    Tbl:           TTBLFile;
    JsonText:      AnsiString;
    LastSearchPos: Integer;
    Mode:          TViewMode;
    Dirty:         Boolean;    // any unsaved changes (JSON or grid edit)
    EditMode:      Boolean;    // false = read-only (default), true = editable
    // Grid-search continuation cursor (per active grid tab). Reset
    // on tab switch / file open / new search query.
    GridSearchTab: Integer;
    GridSearchRow: Integer;
    GridSearchCol: Integer;
    GridSearchNeedle: AnsiString;
    constructor Create;
    destructor Destroy; override;
  end;

// Initialize the global state on first call. Idempotent.
procedure EnsureGlobalsInit;

// Find the schemas/ directory next to the DLL. Returns empty string
// if not found.
function FindSchemaDir: AnsiString;

// The shared schema database. nil until EnsureGlobalsInit runs.
function GetSchemaDB: TSchemaDB;

// Track open Lister windows.
procedure RegisterInstance(Wnd: HWND; Inst: TInstance);
function  FindInstance(Wnd: HWND): TInstance;
procedure UnregisterInstance(Wnd: HWND);

// Path to the plugin INI file (set by ListSetDefaultParams).
procedure SetIniPath(const Path: AnsiString);
function  GetIniPath: AnsiString;

// Game preference (Kuro1 / Kuro2 / Sora1 / Ys_X). Empty = auto.
function  GetPreferredGame: AnsiString;
procedure SetPreferredGame(const G: AnsiString);

// Edit-mode toggle. Default is read-only (false). User presses F4
// inside the plugin window to flip to editable.
function  GetInstanceEditMode(HostWnd: HWND): Boolean;
procedure SetInstanceEditMode(HostWnd: HWND; Mode: Boolean);
function  ToggleInstanceEditMode(HostWnd: HWND): Boolean;

implementation

uses inisettings;

var
  GlobalsLock:    TRTLCriticalSection;
  GlobalsLockInited: Boolean = False;
  GlobalsReady:   Boolean = False;
  Schemas:        TSchemaDB = nil;
  Instances:      TList = nil;     // of TInstance
  IniPath:        AnsiString = '';
  PreferredGame:  AnsiString = '';

procedure LockEnter; inline;
begin
  EnterCriticalSection(GlobalsLock);
end;
procedure LockLeave; inline;
begin
  LeaveCriticalSection(GlobalsLock);
end;

// ---------------------------------------------------------------------
//  TInstance
// ---------------------------------------------------------------------

constructor TInstance.Create;
begin
  inherited;
  HostWnd := 0;
  EditWnd := 0;
  Tbl := nil;
  LastSearchPos := 0;
  // Initial mode follows the user's INI preference. Default is
  // read-only (safe by default); flip to edit-on-open with
  // [TBL_WLX] DefaultEditMode=1. Users can still toggle per
  // window with F4.
  EditMode := inisettings.GetDefaultEditMode;
  GridSearchTab := -1;
  GridSearchRow := 0;
  GridSearchCol := 0;
  GridSearchNeedle := '';
end;

destructor TInstance.Destroy;
begin
  if Tbl <> nil then Tbl.Free;
  inherited;
end;

// ---------------------------------------------------------------------
//  Globals init
// ---------------------------------------------------------------------

function GetDLLDir: AnsiString;
var
  Buf: array[0..MAX_PATH] of WideChar;
  LenW: DWORD;
begin
  // GetModuleFileNameW(0,...) returns the path of the host EXE; we
  // want our DLL. Pass our HINSTANCE — FPC exposes it as the SysInit
  // global `HInstance`.
  LenW := GetModuleFileNameW(HInstance, @Buf[0], MAX_PATH);
  if LenW = 0 then Exit('');
  Result := AnsiString(WideCharToString(@Buf[0]));
  Result := ExtractFilePath(Result);
end;

function FindSchemaDir: AnsiString;
var
  Candidate: AnsiString;
begin
  Result := '';
  Candidate := GetDLLDir + 'schemas';
  if DirectoryExists(Candidate) then Exit(Candidate);
  Candidate := GetDLLDir + 'schemas' + PathDelim + 'headers';
  if DirectoryExists(Candidate) then Exit(GetDLLDir + 'schemas');
end;

procedure EnsureGlobalsInit;
var
  SchemaDir: AnsiString;
  Errs: TStringList;
begin
  if not GlobalsLockInited then
  begin
    InitializeCriticalSection(GlobalsLock);
    GlobalsLockInited := True;
  end;
  LockEnter;
  try
    if GlobalsReady then Exit;
    Instances := TList.Create;
    Schemas := TSchemaDB.Create;
    SchemaDir := FindSchemaDir;
    if SchemaDir <> '' then
    begin
      Errs := TStringList.Create;
      try
        Schemas.LoadFromDir(SchemaDir, Errs);
      finally
        Errs.Free;
      end;
    end;
    GlobalsReady := True;
  finally
    LockLeave;
  end;
end;

function GetSchemaDB: TSchemaDB;
begin
  EnsureGlobalsInit;
  Result := Schemas;
end;

procedure RegisterInstance(Wnd: HWND; Inst: TInstance);
begin
  EnsureGlobalsInit;
  LockEnter;
  try
    Instances.Add(Inst);
  finally
    LockLeave;
  end;
end;

function FindInstance(Wnd: HWND): TInstance;
var i: Integer;
begin
  Result := nil;
  EnsureGlobalsInit;
  LockEnter;
  try
    for i := 0 to Instances.Count - 1 do
      if TInstance(Instances[i]).HostWnd = Wnd then
        Exit(TInstance(Instances[i]));
  finally
    LockLeave;
  end;
end;

procedure UnregisterInstance(Wnd: HWND);
var i: Integer; Inst: TInstance;
begin
  EnsureGlobalsInit;
  LockEnter;
  try
    for i := Instances.Count - 1 downto 0 do
    begin
      Inst := TInstance(Instances[i]);
      if Inst.HostWnd = Wnd then
      begin
        Instances.Delete(i);
        Inst.Free;
      end;
    end;
  finally
    LockLeave;
  end;
end;

procedure SetIniPath(const Path: AnsiString);
begin
  EnsureGlobalsInit;
  LockEnter;
  try
    IniPath := Path;
  finally
    LockLeave;
  end;
  // Load whatever is already saved in the INI so the very next
  // ListLoad benefits from the persisted preference.
  LoadINI(Path);
  // After load, snapshot the persisted PreferredGame back into our
  // module-level cache so callers don't go through inisettings on
  // every read (LockEnter is the hot path during section parse).
  LockEnter;
  try
    PreferredGame := inisettings.GetPreferredGame;
  finally
    LockLeave;
  end;
end;

function GetIniPath: AnsiString;
begin
  EnsureGlobalsInit;
  LockEnter;
  try
    Result := IniPath;
  finally
    LockLeave;
  end;
end;

function GetPreferredGame: AnsiString;
begin
  EnsureGlobalsInit;
  LockEnter;
  try
    Result := PreferredGame;
  finally
    LockLeave;
  end;
end;

procedure SetPreferredGame(const G: AnsiString);
var Path: AnsiString;
begin
  EnsureGlobalsInit;
  if not inisettings.IsValidGameTag(G) then Exit;
  LockEnter;
  try
    PreferredGame := G;
    Path := IniPath;
  finally
    LockLeave;
  end;
  // Push to inisettings + flush to disk if we have a path. This is
  // safe to do outside the lock — no shared state of ours touched.
  inisettings.SetPreferredGame(G);
  if Path <> '' then inisettings.SaveINI(Path);
end;

// ---------------------------------------------------------------------
//  Edit-mode toggle
// ---------------------------------------------------------------------

function GetInstanceEditMode(HostWnd: HWND): Boolean;
var Inst: TInstance;
begin
  Result := False;
  Inst := FindInstance(HostWnd);
  if Inst <> nil then Result := Inst.EditMode;
end;

procedure SetInstanceEditMode(HostWnd: HWND; Mode: Boolean);
var Inst: TInstance;
begin
  Inst := FindInstance(HostWnd);
  if Inst <> nil then Inst.EditMode := Mode;
end;

function ToggleInstanceEditMode(HostWnd: HWND): Boolean;
var Inst: TInstance;
begin
  Result := False;
  Inst := FindInstance(HostWnd);
  if Inst = nil then Exit;
  Inst.EditMode := not Inst.EditMode;
  Result := Inst.EditMode;
end;

initialization
finalization
  if Instances <> nil then
  begin
    while Instances.Count > 0 do
    begin
      TInstance(Instances[0]).Free;
      Instances.Delete(0);
    end;
    Instances.Free;
  end;
  if Schemas <> nil then Schemas.Free;
  if GlobalsLockInited then DeleteCriticalSection(GlobalsLock);
end.
