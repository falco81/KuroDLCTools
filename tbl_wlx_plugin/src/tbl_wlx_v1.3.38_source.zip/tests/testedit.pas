program testedit;
{$mode objfpc}{$H+}

// End-to-end edit simulation:
//   1. Load t_dlc.tbl
//   2. Render to JSON view text
//   3. Replace one of the DLC item names ("Rean Schwarzer's Instructor
//      Apparel" -> "Edited DLC Item Name")
//   4. Run the save pipeline
//   5. Re-read the saved file
//   6. Confirm the new name is present in the decoded data

uses
  Classes, SysUtils, fpjson, jsonparser, jsonscanner,
  tbltypes, tblschemas, tblfile;

function IfThen(Cond: Boolean; const ATrue, AFalse: AnsiString): AnsiString;
begin
  if Cond then Result := ATrue else Result := AFalse;
end;

function BuildJSONView(const Tbl: TTBLFile): AnsiString;
var
  Js: TJSONObject;
  Body, Header: AnsiString;
  i: Integer;
begin
  Js := Tbl.ToJSON;
  try Body := Js.FormatJSON(); finally Js.Free; end;
  Header := '// header line 1' + #10;
  for i := 0 to High(Tbl.Sections) do
    Header := Header + '//   sec ' + IntToStr(i) + #10;
  Result := Header + #10 + Body;
end;

function StripHeaderComment(const Text: AnsiString): AnsiString;
var
  i, n, LineStart: Integer;
begin
  n := Length(Text); i := 1;
  while i <= n do
  begin
    LineStart := i;
    while (i <= n) and (Text[i] <> #10) do Inc(i);
    if  ((i - LineStart >= 2) and (Text[LineStart] = '/') and
         (Text[LineStart+1] = '/'))
       or (Trim(Copy(Text, LineStart, i - LineStart)) = '') then
    begin
      if (i <= n) and (Text[i] = #10) then Inc(i);
      Continue;
    end;
    Result := Copy(Text, LineStart, n - LineStart + 1); Exit;
  end;
  Result := '';
end;

const
  ORIG_NAME = 'Rean Schwarzer''s Instructor Apparel';
  NEW_NAME  = 'EDITED-PLUGIN-TEST-NAME';

var
  DB: TSchemaDB; Errs: TStringList;
  T1, T2: TTBLFile;
  ViewText, Body, EditedView: AnsiString;
  P: TJSONParser; D: TJSONData;
  Path, Tmp: AnsiString;
  i: Integer;
  Row: TJSONObject;
  GotName: AnsiString;
  Found: Boolean;
begin
  Path := GetEnvironmentVariable('TBL_CORPUS') + '/t_dlc.tbl';
  Tmp  := Path + '.edited';
  DB := TSchemaDB.Create; Errs := TStringList.Create;
  DB.LoadFromDir(GetEnvironmentVariable('TBL_SCHEMAS'), Errs);

  // Load + render
  T1 := TTBLFile.Create(DB);
  T1.ReadFromFile(Path);
  ViewText := BuildJSONView(T1);
  T1.Free;

  // Simulate user edit: replace the first occurrence of ORIG_NAME
  EditedView := StringReplace(ViewText, ORIG_NAME, NEW_NAME, []);
  if EditedView = ViewText then
  begin
    WriteLn('FAIL: original name not found in JSON view');
    Halt(1);
  end;

  // Save pipeline
  Body := StripHeaderComment(EditedView);
  P := TJSONParser.Create(Body, []);
  try
    D := P.Parse;
  finally P.Free; end;
  T2 := TTBLFile.Create(DB);
  try
    T2.ReadFromFile(Path);
    T2.FromJSON(TJSONObject(D));
    T2.WriteToFile(Tmp);
  finally
    T2.Free;
    D.Free;
  end;

  // Re-read and verify
  T2 := TTBLFile.Create(DB);
  try
    T2.ReadFromFile(Tmp);
    Found := False;
    for i := 0 to T2.Sections[0].Rows.Count - 1 do
    begin
      Row := T2.Sections[0].Rows.Objects[i];
      GotName := Row.Get('text1', '');
      if GotName = NEW_NAME then
      begin
        Found := True;
        Break;
      end;
    end;
    if Found then
      WriteLn('PASS: edited DLC item name is present in re-read file (row ', i, ')')
    else
      WriteLn('FAIL: edited name not found after save+reload');
  finally T2.Free; end;
  if FileExists(Tmp) then DeleteFile(Tmp);
  Errs.Free; DB.Free;
end.
