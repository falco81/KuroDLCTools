program testarrayedit;
{$mode objfpc}{$H+}

// Verify SetCellText handles ckArray columns: parses the user's
// text input as a JSON-array-or-comma-separated and writes it
// back to the row.

uses Classes, SysUtils, fpjson, gridmodel, tbltypes;

procedure CheckOrFail(Cond: Boolean; const Where: AnsiString);
begin
  if not Cond then
  begin
    WriteLn('FAIL: ', Where);
    Halt(1);
  end;
end;

var
  Row: TJSONObject;
  Col: TGridColumn;
  Arr: TJSONArray;
  Out_: AnsiString;
begin
  Row := TJSONObject.Create;
  Row.Add('xs', TJSONArray.Create);
  TJSONArray(Row.Find('xs')).Add(Int64(1));
  TJSONArray(Row.Find('xs')).Add(Int64(2));
  TJSONArray(Row.Find('xs')).Add(Int64(3));

  // Synthesize a ckArray column for the 'xs' field.
  FillChar(Col, SizeOf(Col), 0);
  Col.DisplayName := 'xs';
  Col.JsonPath    := 'xs';
  Col.Kind        := ckArray;
  Col.BaseKind    := tbkU16Array;

  // Round-trip: GetCellText, mutate, SetCellText
  Out_ := GetCellText(Row, Col);
  WriteLn('Initial: ', Out_);
  CheckOrFail(Pos('1', Out_) > 0, 'GetCellText shows initial');

  // Edit via JSON-array notation
  CheckOrFail(SetCellText(Row, Col, '[10, 20, 30]'),
              'SetCellText accepts [10, 20, 30]');
  Arr := TJSONArray(Row.Find('xs'));
  CheckOrFail(Arr.Count = 3,        'array has 3 items');
  CheckOrFail(Arr.Integers[0] = 10, 'item 0 = 10');
  CheckOrFail(Arr.Integers[1] = 20, 'item 1 = 20');
  CheckOrFail(Arr.Integers[2] = 30, 'item 2 = 30');

  // Edit via bare comma-separated
  CheckOrFail(SetCellText(Row, Col, '4, 5, 6'),
              'SetCellText accepts bare commas');
  Arr := TJSONArray(Row.Find('xs'));
  CheckOrFail(Arr.Count = 3,        'array now has 3 items');
  CheckOrFail(Arr.Integers[0] = 4,  'item 0 = 4');

  // Empty array
  CheckOrFail(SetCellText(Row, Col, '[]'),
              'SetCellText accepts empty []');
  Arr := TJSONArray(Row.Find('xs'));
  CheckOrFail(Arr.Count = 0, 'empty array');

  // Bad input — refuse and don't mutate
  CheckOrFail(SetCellText(Row, Col, '[7, 8, 9]'),
              'set a known-good value');
  CheckOrFail(not SetCellText(Row, Col, '[1, abc, 3]'),
              'reject non-numeric');
  Arr := TJSONArray(Row.Find('xs'));
  CheckOrFail(Arr.Count = 3, 'still 3 items after rejected edit');
  CheckOrFail(Arr.Integers[0] = 7, 'unchanged');

  Row.Free;
  WriteLn('PASS: array edit round-trip OK');
end.
