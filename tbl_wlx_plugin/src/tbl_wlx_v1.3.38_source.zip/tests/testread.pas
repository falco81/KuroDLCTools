program testread;
{$mode objfpc}{$H+}

uses Classes, SysUtils, tbltypes, tblschemas, tblfile;

var
  DB: TSchemaDB;
  T: TTBLFile;
  SR: TSearchRec;
  Path, Dir: AnsiString;
  Errs: TStringList;
  TotalFiles, ReadOK, ReadErr: Integer;
  TotalSections, FullDecoded, PartialDecoded, NoneDecoded: Integer;
  i, FullSections, RawSections: Integer;
  ErrSamples: TStringList;
  Status: AnsiString;
begin
  if ParamCount < 2 then
  begin
    WriteLn('usage: testread <schemas dir> <tbl dir> [--quiet]');
    Halt(1);
  end;

  DB := TSchemaDB.Create;
  Errs := TStringList.Create;
  ErrSamples := TStringList.Create;
  try
    DB.LoadFromDir(ParamStr(1), Errs);
    WriteLn(Format('Schemas: %d headers, %d variants',
                   [DB.HeaderCount, DB.VariantCount]));
    WriteLn;

    TotalFiles := 0; ReadOK := 0; ReadErr := 0;
    TotalSections := 0; FullDecoded := 0;
    PartialDecoded := 0; NoneDecoded := 0;

    Dir := IncludeTrailingPathDelimiter(ParamStr(2));
    if FindFirst(Dir + '*.tbl', faAnyFile, SR) = 0 then
    begin
      repeat
        Path := Dir + SR.Name;
        Inc(TotalFiles);
        T := TTBLFile.Create(DB);
        try
          try
            T.ReadFromFile(Path);
            Inc(ReadOK);
            FullSections := 0;
            RawSections := 0;
            for i := 0 to High(T.Sections) do
            begin
              Inc(TotalSections);
              if T.Sections[i].Mode = smDecoded then Inc(FullSections)
              else                                   Inc(RawSections);
            end;
            if (FullSections > 0) and (RawSections = 0) then
              Inc(FullDecoded)
            else if FullSections > 0 then
              Inc(PartialDecoded)
            else
              Inc(NoneDecoded);
            Status := '';
            if (FullSections = 0) and (Length(T.Sections) > 0) then
              Status := 'NONE';
          except
            on E: Exception do
            begin
              Inc(ReadErr);
              if ErrSamples.Count < 10 then
                ErrSamples.Add(Format('%s: %s', [SR.Name, E.Message]));
            end;
          end;
        finally
          T.Free;
        end;
      until FindNext(SR) <> 0;
      FindClose(SR);
    end;

    WriteLn(Format('Files:    total=%d, read OK=%d, read errors=%d',
                   [TotalFiles, ReadOK, ReadErr]));
    WriteLn(Format('Coverage: full=%d, partial=%d, none=%d',
                   [FullDecoded, PartialDecoded, NoneDecoded]));
    WriteLn(Format('Sections: total=%d', [TotalSections]));
    if ReadErr > 0 then
    begin
      WriteLn('Read error samples:');
      for i := 0 to ErrSamples.Count - 1 do
        WriteLn('  ', ErrSamples[i]);
    end;
  finally
    Errs.Free;
    ErrSamples.Free;
    DB.Free;
  end;
end.
