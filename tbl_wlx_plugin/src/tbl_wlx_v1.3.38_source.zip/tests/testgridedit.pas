program testgridedit;
{$mode objfpc}{$H+}

// Linux-only smoke test. Verifies the column model + cell I/O paths
// that the Win32 grid widget calls into:
//
//   1. Build top-level columns for ItemTableData
//   2. Edit a scalar cell (id) via SetCellText
//   3. Find a nested-summary column ("effects")
//   4. Pull the nested array, build sub-grid columns
//   5. Edit a leaf cell inside the nested rows
//   6. Save + reload + verify both edits stuck

uses
  Classes, SysUtils, fpjson, jsonparser, jsonscanner,
  tbltypes, tblschemas, tblfile, gridmodel;

procedure FindNestedCol(const Cols: TGridColumnArray; out Idx: Integer);
var i: Integer;
begin
  Idx := -1;
  for i := 0 to High(Cols) do
    if Cols[i].Kind = ckNestedSummary then
    begin
      Idx := i;
      Exit;
    end;
end;

var
  DB: TSchemaDB; Errs: TStringList;
  T: TTBLFile;
  V: TSchemaVariant;
  Cols, SubCols: TGridColumnArray;
  Row0, NestedRow0: TJSONObject;
  NestedArr: TJSONArray;
  NestedColIdx, i: Integer;
  Path, TmpPath: AnsiString;
  OrigID, NewID: Int64;
  OrigEffectVal, NewEffectVal: Int64;
begin
  Path := GetEnvironmentVariable('TBL_CORPUS') + '/t_item.tbl';
  TmpPath := Path + '.gridedit_test';

  DB := TSchemaDB.Create; Errs := TStringList.Create;
  DB.LoadFromDir(GetEnvironmentVariable('TBL_SCHEMAS'), Errs);

  T := TTBLFile.Create(DB);
  T.ReadFromFile(Path);
  WriteLn(Format('Loaded %s: %d sections', [ExtractFileName(Path), Length(T.Sections)]));

  // Section 0 = ItemTableData
  if not DB.FindVariant(T.Sections[0].Name,
                         T.Sections[0].EntryLength,
                         T.Sections[0].GameTag, V) then
  begin
    WriteLn('FAIL: cannot resolve ItemTableData schema');
    Halt(1);
  end;
  Cols := BuildColumns(V.Fields);
  WriteLn(Format('ItemTableData: %d columns', [Length(Cols)]));

  Row0 := T.Sections[0].Rows.Objects[0];
  // 1. Read original scalar 'id'
  OrigID := Row0.Get('id', Int64(-1));
  WriteLn('Original id = ', OrigID);

  // 2. Edit it via SetCellText
  for i := 0 to High(Cols) do
    if Cols[i].DisplayName = 'id' then
    begin
      if not SetCellText(Row0, Cols[i], '99999') then
      begin
        WriteLn('FAIL: SetCellText scalar');
        Halt(1);
      end;
      Break;
    end;
  WriteLn('After scalar edit, id = ', Row0.Get('id', Int64(-2)));

  // 3. Find the nested-summary column
  FindNestedCol(Cols, NestedColIdx);
  if NestedColIdx < 0 then
  begin
    WriteLn('FAIL: no nested-summary column found in ItemTableData');
    Halt(1);
  end;
  WriteLn(Format('Nested col: %s (idx %d)',
                 [Cols[NestedColIdx].DisplayName, NestedColIdx]));

  // 4. Pull nested array, build sub-grid columns
  NestedArr := GetNestedArray(Row0, Cols[NestedColIdx]);
  if NestedArr = nil then
  begin
    WriteLn('FAIL: nested array nil');
    Halt(1);
  end;
  WriteLn(Format('Nested has %d rows', [NestedArr.Count]));
  SubCols := BuildNestedColumns(
    TFieldList(Cols[NestedColIdx].NestedFT.NestedFields));
  WriteLn(Format('Sub-grid columns: %d', [Length(SubCols)]));
  for i := 0 to High(SubCols) do Write(SubCols[i].DisplayName, ' ');
  WriteLn;

  // 5. Edit a value in the first nested row
  NestedRow0 := TJSONObject(NestedArr.Items[0]);
  OrigEffectVal := NestedRow0.Get('value1', Int64(-1));
  WriteLn('Original effects[0].value1 = ', OrigEffectVal);
  for i := 0 to High(SubCols) do
    if SubCols[i].DisplayName = 'value1' then
    begin
      if not SetCellText(NestedRow0, SubCols[i], '7777') then
      begin
        WriteLn('FAIL: SetCellText sub-grid');
        Halt(1);
      end;
      Break;
    end;
  WriteLn('After nested edit, effects[0].value1 = ',
          NestedRow0.Get('value1', Int64(-2)));

  // 6. Save, reload, verify both edits
  T.WriteToFile(TmpPath);
  T.Free;

  T := TTBLFile.Create(DB);
  T.ReadFromFile(TmpPath);
  Row0 := T.Sections[0].Rows.Objects[0];
  NewID := Row0.Get('id', Int64(-1));
  NestedArr := GetNestedArray(Row0, Cols[NestedColIdx]);
  NewEffectVal := TJSONObject(NestedArr.Items[0]).Get('value1', Int64(-1));
  WriteLn;
  WriteLn(Format('After reload: id=%d, effects[0].value1=%d',
                 [NewID, NewEffectVal]));
  if (NewID = 99999) and (NewEffectVal = 7777) then
    WriteLn('PASS: scalar + nested-leaf edits both persisted')
  else
    WriteLn('FAIL: edits did not persist');

  T.Free;
  if FileExists(TmpPath) then DeleteFile(TmpPath);
  Errs.Free; DB.Free;
end.
