program testcle;
{$mode objfpc}{$H+}

uses Classes, SysUtils, md5, cle;

procedure LoadFile(const Path: AnsiString; out B: TBytes);
var FS: TFileStream; L: Int64;
begin
  FS := TFileStream.Create(Path, fmOpenRead);
  try
    L := FS.Size;
    SetLength(B, L);
    if L > 0 then FS.ReadBuffer(B[0], L);
  finally FS.Free; end;
end;

function MD5OfBytes(const B: TBytes): AnsiString;
var Digest: TMDDigest;
begin
  if Length(B) = 0 then
    Digest := MDBuffer(nil^, 0, MD_VERSION_5)
  else
    Digest := MDBuffer(B[0], Length(B), MD_VERSION_5);
  Result := MD5Print(Digest);
end;

procedure RunTest(const Path, ExpectedMD5, Label_: AnsiString);
var
  Input, Output: TBytes;
  GotMD5: AnsiString;
begin
  LoadFile(Path, Input);
  WriteLn(Format('  Input %s: %d bytes magic=%s%s%s%s',
                 [Path, Length(Input),
                  Char(Input[0]), Char(Input[1]),
                  Char(Input[2]), Char(Input[3])]));
  ProcessCLE(Input, Output);
  GotMD5 := MD5OfBytes(Output);
  if LowerCase(GotMD5) = LowerCase(ExpectedMD5) then
    WriteLn('  PASS  ', Label_, ' (', Length(Output), ' bytes)')
  else
    WriteLn('  FAIL  ', Label_, '  got=', GotMD5, ' exp=', ExpectedMD5,
            ' (', Length(Output), ' bytes)');
end;

begin
  WriteLn('CLE round-trip tests against Python-generated fixtures');
  WriteLn;

  // 01 plain.tbl: passes through unchanged because magic is "#TBL"
  RunTest('./cle_fixtures/01_plain.tbl',
          'dc0df178088b015f15675e9203a443bb',
          'plain (passthrough)');

  // 02 D9BA: zstd-only, output should be plain TBL
  RunTest('./cle_fixtures/02_compressed.D9BA',
          'dc0df178088b015f15675e9203a443bb',
          'D9BA -> plain');

  // 03 F9BA over D9BA: encrypt(compress(plain)). Output: plain.
  RunTest('./cle_fixtures/03_encrypted.F9BA',
          'dc0df178088b015f15675e9203a443bb',
          'F9BA(D9BA) -> plain');

  // 04 F9BA over plain (no compression): encrypt(plain) and decrypt
  // produces the input PLUS 4 bytes of padding (encryptCLE adds 8-byte
  // alignment padding AFTER encryption, so the decrypted output
  // contains the trailing pad XOR'd back to garbage, not stripped).
  // Python's processCLE behaves the same way — this is the expected
  // CLE behavior. Real Falcom files always use compression first
  // (case 03), so this lossy padding is harmless in practice.
  RunTest('./cle_fixtures/04_encrypted_only.F9BA',
          'd42fb4edd7162b4a110ef8789a0e1a45',
          'F9BA(plain) -> plain+pad (matches Python)');
end.
