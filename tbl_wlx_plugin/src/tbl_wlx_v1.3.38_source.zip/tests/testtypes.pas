program testtypes;
{$mode objfpc}{$H+}

uses Classes, SysUtils, fpjson, jsonparser, jsonscanner, tbltypes;

var
  TotalSchemas, OK, Failed: Integer;
  FailureSamples: TStringList;

function ReadFile_(const Path: AnsiString): AnsiString;
var FS: TFileStream; L: Int64;
begin
  Result := '';
  FS := TFileStream.Create(Path, fmOpenRead);
  try
    L := FS.Size;
    SetLength(Result, L);
    if L > 0 then FS.ReadBuffer(Result[1], L);
  finally FS.Free; end;
end;

// Walk a JSON text and rename later-occurring duplicates of object
// keys to "<key>__dupN", which the strict FPC parser then accepts.
// We then ignore the extra "__dupN" entries during schema lookup. This
// matches Python's json.load (last-wins) semantics — KuroTools'
// ConditionInfoTableData.json etc. ship duplicated platform keys.
//
// Implementation: tokenize JSON stack-based to know which level each
// "key" is at, track per-level seen names, append a suffix to repeats.
function DedupJSONKeys(const Src: AnsiString): AnsiString;
type
  TLevel = record
    Names: TStringList;
  end;
  TLevelArr = array of TLevel;
var
  Out_: AnsiString;
  i, n, depth: Integer;
  ch: AnsiChar;
  InString: Boolean;
  Levels: TLevelArr;
  CurStr, NewKey: AnsiString;
  ExpectingKey: Boolean;
  StartIdx: Integer;
  SeenIdx: Integer;
  DupCounter: Integer;
begin
  Out_ := '';
  n := Length(Src);
  i := 1;
  depth := 0;
  InString := False;
  SetLength(Levels, 16);
  for SeenIdx := 0 to High(Levels) do
    Levels[SeenIdx].Names := nil;
  ExpectingKey := False;

  while i <= n do
  begin
    ch := Src[i];
    if InString then
    begin
      // Look for the end of this string
      if ch = '\' then
      begin
        // Escape sequence — copy this char and the next verbatim
        Out_ := Out_ + ch;
        Inc(i);
        if i <= n then
        begin
          Out_ := Out_ + Src[i];
          Inc(i);
        end;
        Continue;
      end;
      if ch = '"' then
      begin
        // End of string. If we were expecting a key, dedup it now.
        InString := False;
        if ExpectingKey then
        begin
          CurStr := Copy(Out_, StartIdx + 1, Length(Out_) - StartIdx);
          if Levels[depth].Names = nil then
            Levels[depth].Names := TStringList.Create;
          DupCounter := 0;
          NewKey := CurStr;
          while Levels[depth].Names.IndexOf(NewKey) >= 0 do
          begin
            Inc(DupCounter);
            NewKey := CurStr + '__dup' + IntToStr(DupCounter);
          end;
          Levels[depth].Names.Add(NewKey);
          if NewKey <> CurStr then
          begin
            // Replace the just-appended raw key with the deduped one
            SetLength(Out_, StartIdx);
            Out_ := Out_ + NewKey;
          end;
          ExpectingKey := False;
        end;
        Out_ := Out_ + ch;
        Inc(i);
        Continue;
      end;
      Out_ := Out_ + ch;
      Inc(i);
      Continue;
    end;
    case ch of
      '"':
        begin
          // Decide if this string is a key. A string is a key when we
          // just opened an object or finished a comma INSIDE an object.
          // We approximate: string is a key iff the next non-whitespace
          // char (after the matching close-quote) is ':'. That requires
          // lookahead — instead, we set ExpectingKey based on context:
          // we set it to True after '{' or ',' INSIDE an object level.
          InString := True;
          if ExpectingKey then
          begin
            StartIdx := Length(Out_) + 1; // we're about to write the opening quote
            // ExpectingKey stays True until the closing quote is seen
          end;
          Out_ := Out_ + ch;
          Inc(i);
        end;
      '{':
        begin
          Inc(depth);
          if depth >= Length(Levels) then
            SetLength(Levels, Length(Levels) * 2);
          if Levels[depth].Names <> nil then
            Levels[depth].Names.Clear
          else
            Levels[depth].Names := TStringList.Create;
          ExpectingKey := True;
          Out_ := Out_ + ch;
          Inc(i);
        end;
      '}':
        begin
          if depth >= 0 then
          begin
            if (depth < Length(Levels)) and (Levels[depth].Names <> nil) then
              Levels[depth].Names.Clear;
            Dec(depth);
          end;
          ExpectingKey := False;
          Out_ := Out_ + ch;
          Inc(i);
        end;
      '[':
        begin
          // Arrays contain values, not keys
          Inc(depth);
          if depth >= Length(Levels) then
            SetLength(Levels, Length(Levels) * 2);
          if Levels[depth].Names <> nil then
            Levels[depth].Names.Clear
          else
            Levels[depth].Names := TStringList.Create;
          ExpectingKey := False;
          Out_ := Out_ + ch;
          Inc(i);
        end;
      ']':
        begin
          if (depth < Length(Levels)) and (Levels[depth].Names <> nil) then
            Levels[depth].Names.Clear;
          Dec(depth);
          ExpectingKey := False;
          Out_ := Out_ + ch;
          Inc(i);
        end;
      ',':
        begin
          // After comma at object level, expect a key. We can't easily
          // tell if we're in object or array — use Levels[depth].Names
          // tracking: only objects get key-tracking. Heuristic: if
          // previously emitted a key at this depth, we're in an
          // object → expect key.
          if (depth >= 0) and (depth < Length(Levels)) and
             (Levels[depth].Names <> nil) and
             (Levels[depth].Names.Count > 0) then
            ExpectingKey := True
          else
            ExpectingKey := False;
          Out_ := Out_ + ch;
          Inc(i);
        end;
      ':':
        begin
          ExpectingKey := False;
          Out_ := Out_ + ch;
          Inc(i);
        end;
    else
      Out_ := Out_ + ch;
      Inc(i);
    end;
  end;
  // Cleanup
  for SeenIdx := 0 to High(Levels) do
    if Levels[SeenIdx].Names <> nil then
      Levels[SeenIdx].Names.Free;
  Result := Out_;
end;

procedure ProcessSchemaFile(const Path: AnsiString);
var
  Raw: AnsiString;
  Root: TJSONData;
  TopObj, GameObj, Schema: TJSONObject;
  GameKey: AnsiString;
  Inner: TFieldList;
  i: Integer;
  Sz: Integer;
begin
  Raw := ReadFile_(Path);
  Raw := DedupJSONKeys(Raw);
  Root := nil;
  try
    Root := GetJSON(Raw);
  except
    on E: Exception do
    begin
      Inc(Failed);
      if FailureSamples.Count < 10 then
        FailureSamples.Add(Format('%s: bad JSON: %s', [ExtractFileName(Path), E.Message]));
      Exit;
    end;
  end;
  try
    if not (Root is TJSONObject) then
    begin
      Inc(Failed);
      Exit;
    end;
    TopObj := TJSONObject(Root);
    // Each top-level key is a "platform" name like FALCOM_PS4 / CLE_PC.
    // Each contains {game, schema}.
    for i := 0 to TopObj.Count - 1 do
    begin
      GameKey := TopObj.Names[i];
      if not (TopObj.Items[i] is TJSONObject) then Continue;
      GameObj := TJSONObject(TopObj.Items[i]);
      Schema := GameObj.Get('schema', TJSONObject(nil));
      if Schema = nil then Continue;
      Inc(TotalSchemas);
      try
        Inner := ParseFieldList(Schema);
        try
          Sz := FieldListSize(Inner);
          // Print a sanity sample for the first few
          if OK < 3 then
            WriteLn(Format('  %s [%s]: size=%d, %d fields',
                           [ExtractFileName(Path), GameKey,
                            Sz, Length(Inner.Fields)]));
          Inc(OK);
        finally
          Inner.Free;
        end;
      except
        on E: Exception do
        begin
          Inc(Failed);
          if FailureSamples.Count < 10 then
            FailureSamples.Add(Format('%s [%s]: %s',
                              [ExtractFileName(Path), GameKey, E.Message]));
        end;
      end;
    end;
  finally
    Root.Free;
  end;
end;

var
  SR: TSearchRec;
  Dir: AnsiString;
  i: Integer;
begin
  if ParamCount < 1 then
  begin
    WriteLn('usage: testtypes <schemas/headers/ directory>');
    Halt(1);
  end;
  Dir := ParamStr(1);
  TotalSchemas := 0;
  OK := 0;
  Failed := 0;
  FailureSamples := TStringList.Create;
  try
    if FindFirst(IncludeTrailingPathDelimiter(Dir) + '*.json',
                 faAnyFile and not faDirectory, SR) = 0 then
    begin
      repeat
        ProcessSchemaFile(IncludeTrailingPathDelimiter(Dir) + SR.Name);
      until FindNext(SR) <> 0;
      FindClose(SR);
    end;
    WriteLn;
    WriteLn(Format('Total schema variants: %d', [TotalSchemas]));
    WriteLn(Format('Parsed OK:             %d', [OK]));
    WriteLn(Format('Failed:                %d', [Failed]));
    if Failed > 0 then
    begin
      WriteLn('Failure samples:');
      for i := 0 to FailureSamples.Count - 1 do
        WriteLn('  ', FailureSamples[i]);
    end;
  finally
    FailureSamples.Free;
  end;
end.
