program testschemas;
{$mode objfpc}{$H+}

uses Classes, SysUtils, tbltypes, tblschemas;

var
  DB: TSchemaDB;
  Errs: TStringList;
  V: TSchemaVariant;
  HdrList: TStringList;
  i: Integer;
begin
  if ParamCount < 1 then
  begin
    WriteLn('usage: testschemas <schemas/ directory>');
    Halt(1);
  end;

  DB := TSchemaDB.Create;
  Errs := TStringList.Create;
  try
    DB.LoadFromDir(ParamStr(1), Errs);

    WriteLn(Format('Loaded headers:  %d', [DB.HeaderCount]));
    WriteLn(Format('Total variants:  %d', [DB.VariantCount]));
    WriteLn(Format('Errors:          %d', [Errs.Count]));
    if Errs.Count > 0 then
    begin
      for i := 0 to 4 do
        if i < Errs.Count then WriteLn('  - ', Errs[i]);
      if Errs.Count > 5 then WriteLn('  ... ', Errs.Count - 5, ' more');
    end;

    WriteLn;
    WriteLn('=== Lookup tests ===');

    // 1) Known DLC table: DLCTableData of length 64 (Kuro2)
    if DB.FindVariant('DLCTableData', 64, 'Kuro2', V) then
      WriteLn(Format('  PASS  DLCTableData len=64 -> %s/%s (size=%d, %d fields)',
                     [V.PlatformKey, V.GameTag, V.Size, Length(V.Fields.Fields)]))
    else
      WriteLn('  FAIL  DLCTableData len=64 not found');

    // 2) ItemTableData length 248 — Kuro1 PS4 schema
    if DB.FindVariant('ItemTableData', 248, '', V) then
      WriteLn(Format('  PASS  ItemTableData len=248 -> %s/%s (size=%d, %d fields)',
                     [V.PlatformKey, V.GameTag, V.Size, Length(V.Fields.Fields)]))
    else
      WriteLn('  FAIL  ItemTableData len=248 not found');

    // 3) Wrong size -> should fail
    if DB.FindVariant('DLCTableData', 999, '', V) then
      WriteLn('  FAIL  DLCTableData len=999 unexpectedly matched')
    else
      WriteLn('  PASS  DLCTableData len=999 correctly absent');

    // 4) TBL file -> header list lookup
    HdrList := DB.FindTblHeaders('t_dlc.tbl');
    if (HdrList <> nil) and (HdrList.Count = 2) and
       (HdrList[0] = 'DLCTableData') then
      WriteLn(Format('  PASS  t_dlc.tbl -> %d headers (%s, %s)',
                     [HdrList.Count, HdrList[0], HdrList[1]]))
    else
      WriteLn('  FAIL  t_dlc.tbl header list lookup');

    // 5) Filename normalization for digit-templated schemas
    HdrList := DB.FindTblHeaders('t_npc_c1027.tbl');
    if (HdrList <> nil) and (HdrList.Count >= 1) and
       (HdrList[0] = 'NPCParam') then
      WriteLn(Format('  PASS  t_npc_c1027.tbl -> %d headers (first: %s)',
                     [HdrList.Count, HdrList[0]]))
    else
      WriteLn('  FAIL  t_npc_c1027.tbl header list lookup (digit normalization)');

    // 6) Multi-game variant resolution: DLCTableData has Kuro1 64B and Kuro2 64B?
    // Probably both same size. PreferGame Kuro2 should pick Kuro2 if both match.
    HdrList := DB.FindTblHeaders('t_item.tbl');
    if HdrList <> nil then
      WriteLn(Format('  INFO  t_item.tbl -> %d headers', [HdrList.Count]));

  finally
    Errs.Free;
    DB.Free;
  end;
end.
