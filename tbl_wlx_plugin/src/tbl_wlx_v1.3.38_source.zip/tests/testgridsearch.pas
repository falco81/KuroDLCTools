program testgridsearch;
{$mode objfpc}{$H+}

// GridSearchText is a Win32-only function (uses HWND, ListView msgs),
// so we only verify what we can on Linux: that the input/output rules
// are sound for the search-cursor advance logic. The actual cell-text
// scan is exercised through the e2e tests on Windows.

uses Classes, SysUtils;

procedure CheckOrFail(Cond: Boolean; const Where: AnsiString);
begin
  if not Cond then
  begin
    WriteLn('FAIL: ', Where);
    Halt(1);
  end;
end;

// Mirror of the Pos/LowerCase logic used in GridSearchText, for
// regression coverage of the substring matching rules.
function FindIn(const Haystack, Needle: AnsiString; Case_: Boolean): Boolean;
var Hay, Pin: AnsiString;
begin
  if Case_ then
  begin
    Hay := Haystack;
    Pin := Needle;
  end
  else
  begin
    Hay := LowerCase(Haystack);
    Pin := LowerCase(Needle);
  end;
  Result := Pos(Pin, Hay) > 0;
end;

begin
  CheckOrFail(FindIn('Hello World', 'World', True),  'case-sensitive hit');
  CheckOrFail(not FindIn('Hello World', 'world', True), 'case-sensitive miss');
  CheckOrFail(FindIn('Hello World', 'world', False), 'case-insensitive hit');
  CheckOrFail(FindIn('Hello World', 'WORLD', False), 'case-insensitive uppercase');
  CheckOrFail(FindIn('aaaa', 'a',     True),  'single char');
  // Note: Pos('', 'Hello') returns 1 in FPC. The grid-search proper
  // refuses empty needles before calling Pos.

  WriteLn('PASS: grid-search substring rules OK');
end.
