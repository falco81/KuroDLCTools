program testgridsort;
{$mode objfpc}{$H+}

// Linux-only smoke test for the column-header sort algorithm.
// Mirrors SortRowsByColumn in gridwin.pas (Windows-only unit) so we
// can exercise the algorithm against the gridmodel API on Linux.

uses
  Classes, SysUtils, fpjson, jsonparser, jsonscanner,
  tbltypes, tblschemas, tblfile, gridmodel;

procedure SortRowsByColumn(Rows: TJSONArray;
                           const Cols: TGridColumnArray;
                           ColIdx: Integer; Ascending: Boolean);
var
  N, I, J, Code, Cmp: Integer;
  Tmp: TJSONData;
  Items: array of TJSONData;
  Keys:  array of AnsiString;
  KeyI, KeyJ: AnsiString;
  IsNumI, IsNumJ: Boolean;
  NumI, NumJ: Double;

  function CompareCells(const A, B: AnsiString;
                        AnumOk, BnumOk: Boolean;
                        Anum, Bnum: Double): Integer;
  begin
    if (A = '') and (B = '') then Result := 0
    else if A = '' then Result := 1
    else if B = '' then Result := -1
    else if AnumOk and BnumOk then
    begin
      if Anum < Bnum then Result := -1
      else if Anum > Bnum then Result := 1
      else Result := 0;
    end
    else
      Result := CompareText(A, B);
  end;

begin
  N := Rows.Count;
  if N < 2 then Exit;
  SetLength(Items, N);
  SetLength(Keys, N);
  for I := 0 to N - 1 do
  begin
    Items[I] := Rows.Items[I];
    Keys[I]  := GetCellText(Rows.Objects[I], Cols[ColIdx]);
  end;
  for I := 1 to N - 1 do
  begin
    KeyI := Keys[I];
    Val(KeyI, NumI, Code); IsNumI := (Code = 0) and (KeyI <> '');
    Tmp := Items[I];
    J := I;
    while J > 0 do
    begin
      KeyJ := Keys[J - 1];
      Val(KeyJ, NumJ, Code); IsNumJ := (Code = 0) and (KeyJ <> '');
      Cmp := CompareCells(KeyJ, KeyI, IsNumJ, IsNumI, NumJ, NumI);
      if not Ascending then Cmp := -Cmp;
      if Cmp <= 0 then break;
      Items[J] := Items[J - 1];
      Keys[J]  := Keys[J - 1];
      Dec(J);
    end;
    Items[J] := Tmp;
    Keys[J]  := KeyI;
  end;
  for I := N - 1 downto 0 do
    Rows.Extract(I);
  for I := 0 to N - 1 do
    Rows.Add(Items[I]);
end;

procedure Check(Cond: Boolean; const Msg: String);
begin
  if not Cond then
  begin
    WriteLn('FAIL: ', Msg);
    Halt(1);
  end;
end;

procedure FindNestedCol(const Cols: TGridColumnArray; out Idx: Integer);
var i: Integer;
begin
  Idx := -1;
  for i := 0 to High(Cols) do
    if Cols[i].Kind = ckNestedSummary then
    begin
      Idx := i;
      Exit;
    end;
end;

var
  DB: TSchemaDB; Errs: TStringList;
  T: TTBLFile;
  V: TSchemaVariant;
  Cols: TGridColumnArray;
  Rows: TJSONArray;
  i, IdCol, NestedCol, Code: Integer;
  Path: AnsiString;
  PrevID, ThisID: Int64;
  CellText: AnsiString;
  Schemas: AnsiString;

begin
  WriteLn('testgridsort: column-header sort algorithm test');
  Path := ParamStr(1);
  if Path = '' then Path := GetEnvironmentVariable('TBL_CORPUS') + '/t_item.tbl';
  if not FileExists(Path) then
  begin
    WriteLn('  (no fixture at ', Path, '; skipping)');
    Exit;
  end;
  Schemas := GetEnvironmentVariable('TBL_SCHEMAS');
  if Schemas = '' then Schemas := 'schemas';

  DB := TSchemaDB.Create;
  Errs := TStringList.Create;
  T := nil;
  try
    DB.LoadFromDir(Schemas, Errs);
    T := TTBLFile.Create(DB);
    T.ReadFromFile(Path);
    Check(Length(T.Sections) > 0, 'has sections');
    Check(DB.FindVariant(T.Sections[0].Name, T.Sections[0].EntryLength,
                         T.Sections[0].GameTag, V),
          'resolve schema for ' + T.Sections[0].Name);
    Cols := BuildColumns(V.Fields);
    Check(Length(Cols) > 0, 'has columns');

    // Find a numeric "id" column for sorting test.
    IdCol := -1;
    for i := 0 to High(Cols) do
      if (LowerCase(Cols[i].DisplayName) = 'id') and (Cols[i].Kind = ckScalar) then
      begin
        IdCol := i;
        break;
      end;
    if IdCol < 0 then
      for i := 0 to High(Cols) do
        if Cols[i].Kind = ckScalar then begin IdCol := i; break; end;
    Check(IdCol >= 0, 'found a sortable column');
    Rows := T.Sections[0].Rows;
    Check(Rows.Count >= 2, 'enough rows to sort');

    // -- Test 1: ascending sort by id --
    WriteLn('  rows: ', Rows.Count, ', sorting by column "', Cols[IdCol].DisplayName, '"');
    SortRowsByColumn(Rows, Cols, IdCol, True);
    PrevID := Low(Int64);
    for i := 0 to Rows.Count - 1 do
    begin
      CellText := GetCellText(Rows.Objects[i], Cols[IdCol]);
      if CellText = '' then continue;
      Val(CellText, ThisID, Code);
      if Code = 0 then
      begin
        if PrevID <> Low(Int64) then
          if ThisID < PrevID then
          begin
            WriteLn(Format('FAIL: asc order at row %d: %d < prev %d', [i, ThisID, PrevID]));
            Halt(1);
          end;
        PrevID := ThisID;
      end;
    end;
    WriteLn('    asc OK');

    // -- Test 2: descending sort by same column --
    SortRowsByColumn(Rows, Cols, IdCol, False);
    PrevID := High(Int64);
    for i := 0 to Rows.Count - 1 do
    begin
      CellText := GetCellText(Rows.Objects[i], Cols[IdCol]);
      if CellText = '' then continue;
      Val(CellText, ThisID, Code);
      if Code = 0 then
      begin
        if PrevID <> High(Int64) then
          if ThisID > PrevID then
          begin
            WriteLn(Format('FAIL: desc order at row %d: %d > prev %d', [i, ThisID, PrevID]));
            Halt(1);
          end;
        PrevID := ThisID;
      end;
    end;
    WriteLn('    desc OK');

    // -- Test 3: nested cells (ckNestedSummary) --
    FindNestedCol(Cols, NestedCol);
    if NestedCol >= 0 then
    begin
      WriteLn('  also sorting by nested column "', Cols[NestedCol].DisplayName, '"');
      SortRowsByColumn(Rows, Cols, NestedCol, True);
      // Just verify it doesn't crash; summary text varies.
      for i := 0 to Rows.Count - 1 do
        CellText := GetCellText(Rows.Objects[i], Cols[NestedCol]);
      WriteLn('    nested OK');
    end;

    WriteLn('PASS');
  finally
    T.Free;
    Errs.Free;
    DB.Free;
  end;
end.
