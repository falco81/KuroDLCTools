program testgrid;
{$mode objfpc}{$H+}

uses Classes, SysUtils, fpjson,
     tbltypes, tblschemas, tblfile, gridmodel;

procedure DumpForFile(const Path: AnsiString; DB: TSchemaDB);
var
  T: TTBLFile;
  Cols: TGridColumnArray;
  i, k: Integer;
  Variant: TSchemaVariant;
  Row0: TJSONObject;
  CellTxt: AnsiString;
begin
  T := TTBLFile.Create(DB);
  try
    T.ReadFromFile(Path);
    WriteLn('=== ', ExtractFileName(Path), ' ===');
    for i := 0 to High(T.Sections) do
    begin
      if T.Sections[i].Mode <> smDecoded then Continue;
      if not DB.FindVariant(T.Sections[i].Name,
                             T.Sections[i].EntryLength,
                             T.Sections[i].GameTag, Variant) then Continue;
      Cols := BuildColumns(Variant.Fields);
      WriteLn(Format('  [%d] %s: %d columns, %d rows',
                     [i, T.Sections[i].Name, Length(Cols),
                      T.Sections[i].Rows.Count]));
      // Print column headers (first 10)
      for k := 0 to High(Cols) do
      begin
        if k >= 10 then begin Write(' ...(', Length(Cols) - 10, ' more)'); Break; end;
        if k > 0 then Write(', ');
        Write(Cols[k].DisplayName);
      end;
      WriteLn;
      // Print first row's cells
      if T.Sections[i].Rows.Count > 0 then
      begin
        Row0 := T.Sections[i].Rows.Objects[0];
        Write('     row[0]: ');
        for k := 0 to High(Cols) do
        begin
          if k >= 5 then begin Write(' ...'); Break; end;
          if k > 0 then Write(' | ');
          CellTxt := GetCellText(Row0, Cols[k]);
          if Length(CellTxt) > 25 then SetLength(CellTxt, 25);
          Write(Cols[k].DisplayName, '=', CellTxt);
        end;
        WriteLn;
      end;
    end;
    WriteLn;
  finally T.Free; end;
end;

var
  DB: TSchemaDB; Errs: TStringList;
begin
  DB := TSchemaDB.Create; Errs := TStringList.Create;
  try
    DB.LoadFromDir(GetEnvironmentVariable('TBL_SCHEMAS'), Errs);
    DumpForFile(GetEnvironmentVariable('TBL_CORPUS') + '/t_dlc.tbl', DB);
    DumpForFile(GetEnvironmentVariable('TBL_CORPUS') + '/t_costume.tbl', DB);
    DumpForFile(GetEnvironmentVariable('TBL_CORPUS') + '/t_item.tbl', DB);
  finally Errs.Free; DB.Free; end;
end.
