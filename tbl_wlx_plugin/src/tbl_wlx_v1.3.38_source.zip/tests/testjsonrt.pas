program testjsonrt;
{$mode objfpc}{$H+}

uses Classes, SysUtils, md5, fpjson, jsonparser, jsonscanner,
     tbltypes, tblschemas, tblfile;

function MD5OfFile(const Path: AnsiString): AnsiString;
begin
  Result := MD5Print(MD5File(Path));
end;

procedure SaveJSON(J: TJSONObject; const Path: AnsiString);
var
  S: AnsiString;
  FS: TFileStream;
begin
  S := J.FormatJSON();
  FS := TFileStream.Create(Path, fmCreate);
  try
    if Length(S) > 0 then FS.WriteBuffer(S[1], Length(S));
  finally FS.Free; end;
end;

function LoadJSON(const Path: AnsiString): TJSONObject;
var
  S: AnsiString;
  FS: TFileStream;
  L: Int64;
  D: TJSONData;
  P: TJSONParser;
begin
  FS := TFileStream.Create(Path, fmOpenRead);
  try
    L := FS.Size;
    SetLength(S, L);
    if L > 0 then FS.ReadBuffer(S[1], L);
  finally FS.Free; end;
  // Parse WITHOUT joUTF8 — fpjson's UTF8 mode converts UTF-8 input
  // to the platform default codepage on read, which mangles bytes
  // ≥ 0x80 when DefaultSystemCodePage isn't CP_UTF8 (e.g. Linux on
  // a sparse profile). Without joUTF8 the scanner copies bytes
  // verbatim — that's what we want for round-trip byte fidelity.
  P := TJSONParser.Create(S, []);
  try
    D := P.Parse;
  finally P.Free; end;
  if not (D is TJSONObject) then
  begin
    D.Free;
    raise Exception.Create('JSON root is not an object');
  end;
  Result := TJSONObject(D);
end;

var
  DB: TSchemaDB;
  Errs: TStringList;
  SR: TSearchRec;
  Path, Dir: AnsiString;
  T1, T2: TTBLFile;
  Js: TJSONObject;
  Total, BitId, JsonRtOK, Bad: Integer;
  Md5Direct, Md5JsonRt: AnsiString;
  TmpDirect, TmpJson, TmpJsonRt: AnsiString;
  i: Integer;
  BadSamples: TStringList;
begin
  if ParamCount < 2 then
  begin
    WriteLn('usage: testjsonrt <schemas dir> <tbl dir>');
    Halt(1);
  end;
  DB := TSchemaDB.Create;
  Errs := TStringList.Create;
  BadSamples := TStringList.Create;
  try
    DB.LoadFromDir(ParamStr(1), Errs);
    WriteLn(Format('Schemas: %d / %d', [DB.HeaderCount, DB.VariantCount]));
    Total := 0; BitId := 0; JsonRtOK := 0; Bad := 0;

    Dir := IncludeTrailingPathDelimiter(ParamStr(2));
    if FindFirst(Dir + '*.tbl', faAnyFile, SR) = 0 then
    begin
      repeat
        Path := Dir + SR.Name;
        Inc(Total);
        TmpDirect := Path + '.dirRt';
        TmpJson   := Path + '.json';
        TmpJsonRt := Path + '.jsonRt';
        try
          // Direct TBL -> TBL round-trip (baseline)
          T1 := TTBLFile.Create(DB);
          try
            T1.ReadFromFile(Path);
            T1.WriteToFile(TmpDirect);
          finally T1.Free; end;
          Md5Direct := MD5OfFile(TmpDirect);

          // TBL -> JSON -> JSON-parse -> FromJSON -> WriteTBL
          T1 := TTBLFile.Create(DB);
          T2 := TTBLFile.Create(DB);
          try
            T1.ReadFromFile(Path);
            Js := T1.ToJSON;
            try
              SaveJSON(Js, TmpJson);
            finally Js.Free; end;

            // Now load JSON back and apply to a fresh TBL with same
            // structure (T2 reads original to inherit schema state)
            T2.ReadFromFile(Path);
            Js := LoadJSON(TmpJson);
            try
              T2.FromJSON(Js);
              T2.WriteToFile(TmpJsonRt);
            finally Js.Free; end;
          finally T1.Free; T2.Free; end;
          Md5JsonRt := MD5OfFile(TmpJsonRt);

          // The JSON round-trip output should bit-match the direct
          // round-trip output (we're applying identical transforms,
          // just one routes through JSON).
          if Md5Direct = MD5OfFile(Path) then
            Inc(BitId);
          if Md5JsonRt = Md5Direct then
            Inc(JsonRtOK)
          else
          begin
            Inc(Bad);
            if BadSamples.Count < 10 then
              BadSamples.Add(Format('%s: direct=%s, jsonRt=%s',
                [SR.Name, Md5Direct, Md5JsonRt]));
          end;
        except
          on E: Exception do
          begin
            Inc(Bad);
            if BadSamples.Count < 10 then
              BadSamples.Add(Format('%s: %s', [SR.Name, E.Message]));
          end;
        end;
        if FileExists(TmpDirect) then DeleteFile(TmpDirect);
        if FileExists(TmpJson)   then DeleteFile(TmpJson);
        if FileExists(TmpJsonRt) then DeleteFile(TmpJsonRt);
      until FindNext(SR) <> 0;
      FindClose(SR);
    end;

    WriteLn;
    WriteLn(Format('Total:                       %d', [Total]));
    WriteLn(Format('Direct round-trip = orig:    %d', [BitId]));
    WriteLn(Format('JSON round-trip = direct:    %d', [JsonRtOK]));
    WriteLn(Format('Bad / divergent:             %d', [Bad]));
    if Bad > 0 then
    begin
      for i := 0 to BadSamples.Count - 1 do
        WriteLn('  - ', BadSamples[i]);
    end;
  finally
    Errs.Free; BadSamples.Free; DB.Free;
  end;
end.
