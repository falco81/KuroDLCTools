program testsave;
{$mode objfpc}{$H+}

// Replicates the plugin's load → display-as-text → user-edit →
// parse-back → save pipeline without any Win32 UI. Validates that
// the StripHeaderComment + JSON-parse + FromJSON + WriteToFile chain
// produces a file identical (byte-for-byte) to what direct round-trip
// would have produced.

uses
  Classes, SysUtils, md5, fpjson, jsonparser, jsonscanner,
  tbltypes, tblschemas, tblfile;

function IfThen(Cond: Boolean; const ATrue, AFalse: AnsiString): AnsiString;
begin
  if Cond then Result := ATrue else Result := AFalse;
end;

function BuildJSONView(const Tbl: TTBLFile): AnsiString;
var
  Js: TJSONObject;
  Body, Header: AnsiString;
  i: Integer;
begin
  Js := Tbl.ToJSON;
  try Body := Js.FormatJSON(); finally Js.Free; end;
  Header := '// Falcom #TBL viewer  --  ' + IntToStr(Length(Tbl.Sections)) + ' section(s)' + #10;
  for i := 0 to High(Tbl.Sections) do
    Header := Header + Format('//   [%d] %s len=%d mode=%s' + #10,
      [i, Tbl.Sections[i].Name, Tbl.Sections[i].EntryLength,
       IfThen(Tbl.Sections[i].Mode = smDecoded, 'decoded', 'raw')]);
  Result := Header + #10 + Body;
end;

function StripHeaderComment(const Text: AnsiString): AnsiString;
var
  i, n, LineStart: Integer;
begin
  n := Length(Text); i := 1;
  while i <= n do
  begin
    LineStart := i;
    while (i <= n) and (Text[i] <> #10) do Inc(i);
    if  ((i - LineStart >= 2) and (Text[LineStart] = '/') and
         (Text[LineStart+1] = '/'))
       or (Trim(Copy(Text, LineStart, i - LineStart)) = '') then
    begin
      if (i <= n) and (Text[i] = #10) then Inc(i);
      Continue;
    end;
    Result := Copy(Text, LineStart, n - LineStart + 1); Exit;
  end;
  Result := '';
end;

function MD5OfFile(const Path: AnsiString): AnsiString;
begin Result := MD5Print(MD5File(Path)); end;

procedure TestOne(const Path: AnsiString; DB: TSchemaDB);
var
  T1, T2: TTBLFile;
  ViewText, Body: AnsiString;
  P: TJSONParser;
  D: TJSONData;
  TmpDirect, TmpSaved: AnsiString;
begin
  TmpDirect := Path + '.direct';
  TmpSaved  := Path + '.saved';

  // Direct round-trip: read → write
  T1 := TTBLFile.Create(DB);
  try
    T1.ReadFromFile(Path);
    T1.WriteToFile(TmpDirect);
  finally T1.Free; end;

  // Save round-trip: read → BuildJSONView → StripHeaderComment →
  // parse → FromJSON → write
  T2 := TTBLFile.Create(DB);
  try
    T2.ReadFromFile(Path);
    ViewText := BuildJSONView(T2);
    Body := StripHeaderComment(ViewText);
    P := TJSONParser.Create(Body, []);
    try
      D := P.Parse;
    finally P.Free; end;
    try
      T2.FromJSON(TJSONObject(D));
      T2.WriteToFile(TmpSaved);
    finally D.Free; end;
  finally T2.Free; end;

  if MD5OfFile(TmpDirect) = MD5OfFile(TmpSaved) then
    WriteLn('  OK  ', ExtractFileName(Path))
  else
    WriteLn('  FAIL ', ExtractFileName(Path),
            ' (direct=', MD5OfFile(TmpDirect),
            ' saved=', MD5OfFile(TmpSaved), ')');

  if FileExists(TmpDirect) then DeleteFile(TmpDirect);
  if FileExists(TmpSaved)  then DeleteFile(TmpSaved);
end;

var
  DB: TSchemaDB;
  Errs: TStringList;
  SR: TSearchRec;
  Dir: AnsiString;
  Total, Done: Integer;
begin
  if ParamCount < 2 then
  begin
    WriteLn('usage: testsave <schemas dir> <tbl dir>');
    Halt(1);
  end;
  DB := TSchemaDB.Create;
  Errs := TStringList.Create;
  try
    DB.LoadFromDir(ParamStr(1), Errs);
    WriteLn(Format('Schemas: %d / %d', [DB.HeaderCount, DB.VariantCount]));
    Total := 0; Done := 0;
    Dir := IncludeTrailingPathDelimiter(ParamStr(2));
    if FindFirst(Dir + '*.tbl', faAnyFile, SR) = 0 then
    begin
      repeat
        Inc(Total);
        try
          TestOne(Dir + SR.Name, DB);
          Inc(Done);
        except
          on E: Exception do
            WriteLn('  ERR  ', SR.Name, ': ', E.Message);
        end;
      until FindNext(SR) <> 0;
      FindClose(SR);
    end;
    WriteLn;
    WriteLn(Format('Total: %d, processed: %d', [Total, Done]));
  finally
    Errs.Free; DB.Free;
  end;
end.
