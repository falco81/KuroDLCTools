# Changelog

## v1.3.15 (2026-04)

### Added
- **Array fields are now editable in the grid.** Previously the
  grid showed `[1, 2, 3]` for u8/u16/u32-array fields but
  double-click only beeped — you had to drop into the JSON tab to
  edit them. The inline overlay now accepts:
  - `[1, 2, 3]` — JSON-array notation (with or without brackets,
    with or without spaces)
  - `1, 2, 3`   — bare comma-separated
  - `[]` / empty — clears the array
  Each item must parse as the column's primitive type (integer or
  float); a non-numeric token rejects the whole edit and leaves
  the row unchanged.
- **Status strip showing edit-mode state at the top of the host.**
  A 22-pixel-tall label sits above the tab control:
  - **EDIT MODE** — pale-green background, dark-green text
  - **READ-ONLY** — pale-red background, dark-red text
  Updates instantly on F4 toggle.

### Fixed
- **Editing column 0 (the leftmost column) no longer hides the
  rest of the row's cells.** `LVM_GETSUBITEMRECT` with `LVIR_BOUNDS`
  returns the *entire row's* rect when called for subitem 0 (a
  Win32 ListView quirk), so the floating Edit overlay covered all
  cells in the row instead of just the first one. Fixed by using
  `LVIR_LABEL` for column 0 and `LVIR_BOUNDS` for the rest.

## v1.3.14 (2026-04)

### Added
- **Sub-grid (nested-struct popup) position and size are now also
  remembered between sessions.** Same convention as the main
  Lister window: gated by `RememberWindowSize`, persisted in
  `tbl_wlx.ini` under the `[TBL_WLX]` section as `LastSubX`,
  `LastSubY`, `LastSubW`, `LastSubH`. Captured when the popup
  closes (Esc, ✕, after editing); restored when next double-click
  on a `[N rows]` cell opens a popup. If the saved values are
  missing or out of sane bounds (off-screen, degenerate), the
  plugin falls back to the v1.3.x default — popup placed 50px
  offset from the parent grid, sized 700×400.

### Notes
- `RememberWindowSize=0` (or unsetting it via the Config tab)
  also stops capturing/restoring sub-grid geometry; the popup
  always opens at the default offset/size.
- `MaximizeOnOpen` is *only* about the main Lister window — sub-
  grids are never auto-maximized.

## v1.3.13 (2026-04)

### Fixed
- **Esc inside sub-grid popup actually works now.** v1.3.12's Esc
  handling was correct in `GridSubclassProc` (it would post
  `WM_CLOSE` to the popup), but the keystroke never reached our
  subclass — `IsDialogMessage()` in the sub-grid's modal message
  loop was swallowing `VK_ESCAPE` and converting it to
  `WM_COMMAND IDCANCEL` on the popup window, which we don't
  handle. Effectively, Esc was dispatched to a black hole.

  Fix: the message loop in `OpenSubGrid` now bypasses
  `IsDialogMessage` for `WM_KEYDOWN VK_ESCAPE` and calls
  `TranslateMessage`/`DispatchMessage` directly, so Esc reaches
  the focused control's WndProc:
  - During inline cell edit: `OverlayEditProc` cancels the edit
  - On the grid (no active edit): `GridSubclassProc` posts
    `WM_CLOSE` to the popup, closing it
  - Other dialog navigation keys (Tab, Enter, arrow keys) still
    go through `IsDialogMessage` as before.

## v1.3.12 (2026-04)

### Fixed
- **Sub-grid (nested struct popup) now opens in read-only mode too.**
  Previously, double-clicking a `[N rows]` cell in RO mode beeped
  and refused — now it opens the popup so you can *view* the
  nested rows. Cell editing inside the popup remains gated by the
  parent instance's edit-mode flag (the sub-grid walks back to the
  original tab-host through `SubGridFindHost` to read it live).
- **Esc inside a sub-grid popup closes the popup, not the whole
  Lister.** Previously Esc forwarded to TC's parent regardless of
  context. Now `GridSubclassProc` checks `IsSubGrid` + `PopupWnd`
  on the grid state and posts `WM_CLOSE` to the popup if it's a
  sub-grid; top-level grids still forward to TC as before.
- **Sub-grid popup title no longer shows mojibake.** The `Format`
  string for the title contained an em-dash (`—`, UTF-8 bytes
  `E2 80 94`) and the column DisplayName may itself be UTF-8.
  Creating the popup via `CreateWindowExA` interpreted those bytes
  as cp1252 — title showed `effects â€" row 4 (6 nested rows)`.
  Fix: `UTF8Decode` the title and use `CreateWindowExW`.

### Added
- **Config tab gained more controls and read-only fields:**
  - **Open INI in editor** button — launches Notepad (or whatever
    is registered for `.ini`) on the active INI file.
  - **INI file path** — read-only label showing where settings
    actually live (handy when TC's `wincmd.ini` is in a non-default
    location).
  - **Last window state** — read-only label showing the last
    captured `LastWinX/Y/W/H` and the `LastWinMax` flag, so you can
    confirm window-position memory is actually capturing values.

### Sub-grid behavior summary
| Action               | RO mode               | Edit mode             |
|----------------------|-----------------------|-----------------------|
| Open sub-grid (dbl)  | ✅ opens for viewing  | ✅ opens              |
| Edit cell in sub-grid| beeps, refuses        | ✅ inline edit        |
| Esc in sub-grid      | closes popup          | closes popup          |
| Esc in top-level grid| closes Lister (TC)    | closes Lister (TC)    |

## v1.3.11 (2026-04)

### Fixed
- **UTF-8 mojibake in grid cells.** TBL files store strings as UTF-8
  (Falcom convention), but the grid was registered as an ANSI
  control, so non-ASCII characters rendered as cp1250/cp1252
  garbage — `Dantès` showed as `DantÃ¨s`, `René` as `RenÃ©`,
  `◆3D Avatar` as `â—†3D Avatar`, etc.
  
  Fix: the grid now runs in Unicode mode
  (`CCM_SETUNICODEFORMAT, 1`), column headers use
  `LVM_INSERTCOLUMNW` with UTF-16 caption text, and the
  `LVN_GETDISPINFOW` handler decodes UTF-8 cell text to UTF-16
  before writing to the control's WCHAR buffer. Cell editing also
  switched to Unicode (Edit overlay created with
  `CreateWindowExW`, text round-tripped via `UTF8Decode` /
  `UTF8Encode` on edit/commit).

### Added
- **Config tab.** A new tab labeled **Config** is appended after
  the JSON tab, with a GUI for the `[TBL_WLX]` INI section so you
  don't have to edit `tbl_wlx.ini` by hand:
  - **Preferred game** — combobox: `(auto-detect)`, Kuro1, Kuro2,
    Sora1, Ys_X, Kai
  - **Default edit mode** — checkbox (skip the F4 toggle on open)
  - **Remember window position and size between sessions** —
    checkbox
  - **Always maximize Lister on open** — checkbox
  - **Save** button — writes current values to disk and shows the
    INI path in the status line
  - **Reset to defaults** button — populates the controls with the
    factory defaults (you must click Save afterwards to persist)

## v1.3.10 (2026-04)

### Fixed
- **Find dialog no longer erases the grid background.** When TC's
  Find dialog opened (F3 / F7 / Ctrl+F), the entire grid + tabs
  were briefly painted white/grey behind the dialog, and sometimes
  stayed that way after the dialog was dismissed. Two compounding
  bugs:
  - The tab-host window class was registered with
    `hbrBackground = COLOR_BTNFACE+1`, so every `WM_ERASEBKGND`
    filled the whole client area with grey *before* the children
    got a chance to paint. The dialog opening triggered an erase,
    showing grey for one frame, hiding the grid.
  - Even after the dialog was dismissed, the LVS_OWNERDATA grid's
    cached cell-text replies were sometimes invalidated; only the
    focused/selected row repainted, leaving the rest blank.

  Fix: window class now uses `hbrBackground = 0` (no fill — children
  fully cover the client area), `WM_ERASEBKGND` handler returns 1
  (handled, don't fill), and `WM_PAINT` on the host invalidates the
  active tab's child so the next paint cycle re-queries every
  visible cell from `LVN_GETDISPINFO`.

## v1.3.9 (2026-04)

### Fixed
- **Crash on first F3 of a session**. The window-state restore from
  v1.3.7 called `SetWindowPos` / `ShowWindow(SW_MAXIMIZE)` on TC's
  Lister parent *during* `ListLoad`, which reentrantly fired
  `WM_SHOWWINDOW` into TC while it was still in the middle of its
  plugin-loading state machine. On some configurations this corrupted
  TC's internal state and crashed the whole TC process.
  
  Fix: window-state restore is now scheduled via `SetTimer(100ms)`
  on the plugin's tab-host, so it runs *after* `ListLoad` returns
  and TC has finished its plugin-loading dance. The `WM_TIMER`
  handler in `TabHostWndProc` calls `KillTimer` first to ensure
  the apply runs only once, then invokes `ApplyWindowStateNow`
  inside a `try/except` for extra safety.

- **`MaximizeOnOpen` / `LastWinMax` now use `IsZoomed` guard** before
  calling `ShowWindow(SW_MAXIMIZE)`. If the window is already
  maximized (e.g. TC's own "Save Position" already restored it),
  we skip the call entirely so we don't trigger redundant resize
  notifications.

### Behavior notes (search dialog)

If the user reports that "F7 / Ctrl+F sometimes opens TC's standard
Find dialog" (with checkboxes for whole words, backwards search,
match case, and hex search) — that is the **expected** behavior. WLX
plugins forward F-keys to TC's Lister, which then opens its built-in
Find dialog. Our plugin doesn't ship a custom search UI; instead we
implement `ListSearchText` and let TC drive.

## v1.3.8 (2026-04)

### Fixed
- **F3 / F7 / Ctrl+F now actually open the search dialog.**
  Previously the keystrokes were swallowed by whichever child
  control had focus (grid, JSON Edit) and never reached Total
  Commander, so the only way to start a search was via
  *Edit → Find* in the menu. The grid, JSON-Edit, and tab-host
  subclass procs now forward F3 / F7 / Ctrl+F to the TC Lister
  parent the same way Esc and F4 are forwarded.
- **Grid search no longer leaves the view in a "single visible row,
  rest blank" state.** Two compounding bugs:
  - The search switched tabs *after* `SetItemState` /
    `EnsureVisible` fired on the (still-hidden) target grid.
    `LVS_OWNERDATA` ListViews don't repaint cells that weren't
    queried while the control was visible, so on tab activation
    only the focused/selected row painted.
  - Even with the right ordering, the post-`SelectTabAt` paint
    relied on Windows' lazy invalidation, which sometimes left
    cached rows blank.
  Fix: `SelectTabAt` now does an explicit
  `InvalidateRect(child, nil, TRUE) + UpdateWindow(child)` after
  showing the new tab, and the grid-search hit handler does the
  same on the grid before calling `SetFocus`. The search call site
  in `DoSearch` also switches tabs *before* running the search,
  not after.

## v1.3.7 (2026-04)

### Added
- **Grid cell search.** F3/F7 now scans cells in the active grid tab
  (and continues into other tabs if no hit there). When a match is
  found, the plugin selects the row, scrolls it into view, and
  switches the active tab if the hit was on a different tab.
  Previously, F3 only worked inside the JSON tab — search on a grid
  tab silently fell through.
- **Window position / size memory.** The plugin now persists the
  Lister window's last position and size to `tbl_wlx.ini` on close,
  and restores them next time the plugin opens a TBL file. Maximized
  state is preserved separately so unmaximizing later gives a sane
  size.
- **`MaximizeOnOpen=1`** INI flag. Add to `[TBL_WLX]` to always open
  the Lister maximized, regardless of the saved size.

### INI keys (under `[TBL_WLX]`)
| Key                 | Default | Description                          |
|---------------------|--------:|--------------------------------------|
| `RememberWindowSize`|       1 | Restore last position+size on open   |
| `MaximizeOnOpen`    |       0 | Always maximize on open              |
| `LastWinX/Y/W/H`    |      -1 | Auto-updated on close (don't edit)   |
| `LastWinMax`        |       0 | Auto-updated on close (don't edit)   |

### Note about TC's built-in "Save Position"
Total Commander's Lister has its own *Options → Save position* menu
entry that does roughly the same thing. If you've already used that,
you can leave the new INI defaults alone or set
`RememberWindowSize=0` to disable the plugin-side persistence and
let TC handle it. The two systems don't fight, but TC's saved
position will win on the very first open before our INI restore
kicks in.

### Search semantics
- Plain text substring; case-insensitive by default (TC's *Match
  case* checkbox toggles).
- Wraps around: starts from the active tab+row, runs forward through
  remaining tabs, then wraps to tab 0 and continues until back at the
  start.
- Non-text fields (numbers, arrays, nested-summary `[N rows]`) are
  matched as their displayed text — so searching `42` finds rows
  whose any cell prints `42`.

## v1.3.6 (2026-04)

### Fixed
- **Esc key now closes the plugin window**. Previously, Esc was
  swallowed by whichever child control had focus (the grid, JSON
  Edit, or sub-grid Edit) and never reached Total Commander, so the
  Lister window stayed open. Now all three of our subclassed window
  procs forward Esc to the TC parent window via
  `PostMessage(parent, WM_KEYDOWN, VK_ESCAPE)`, which TC interprets
  as "close Lister".
- Esc on the JSON tab no longer triggers the standard Edit-control
  beep (`WM_CHAR` with `0x1B` is now swallowed alongside the keydown
  forward).

### Behavior notes
- Esc on a sub-grid popup still closes the popup (not the whole
  Lister) — that's existing behavior, intentional.
- During inline cell editing, Esc still cancels the edit (handled
  by `OverlayEditProc` before the new top-level forward).

## v1.3.5 (2026-04)

### Added
- **`DefaultEditMode` INI setting**. Add `DefaultEditMode=1` under
  `[TBL_WLX]` in your `tbl_wlx.ini` to make every newly opened TBL
  start in edit mode (skipping the F4 step). Default remains `0`
  (read-only). Useful if you primarily use the plugin to edit, not
  to view.

### Changed
- **F4 toggle is no longer a popup.** It now plays distinct beeps
  (info pitch for ON, warning pitch for OFF) instead of opening a
  modal dialog after each press. This is much less intrusive when
  you toggle modes frequently. The JSON tab's read-only state still
  changes visibly so you can confirm the mode switched.

## v1.3.4 (2026-04)

### Added
- **Read-only by default + F4 to toggle edit mode**. The plugin now
  opens every file in **read-only mode** when invoked from F3 (the
  Total Commander Lister). Press **F4 inside the plugin window** to
  toggle to edit mode (and F4 again to flip back).
- In read-only mode:
  - Double-click on a cell beeps and refuses (no inline editor opens)
  - The JSON tab's text area is disabled (read-only) — you can still
    select and copy, but not type
  - Ctrl+S in the JSON tab is a no-op (beep)
  - Closing the window does **not** show a save prompt
- In edit mode, all editing works as before (cell editing, sub-grid
  popups, JSON editing, Ctrl+S, save-on-close prompt).

### Note about TC F4 vs the plugin's F4
Total Commander's own F4 key opens the *external editor* configured
in `wincmd.ini` (`[Configuration] Editor=`); it does **not** invoke
WLX plugins. To get edit mode for a TBL file:
- Press F3 (TC) → plugin opens in read-only mode
- Press F4 (inside the plugin) → flip to edit mode
- OR: set `DefaultEditMode=1` in `tbl_wlx.ini` to skip the F4 step
  (added in v1.3.5)

## v1.3.3 (2026-04)

### Fixed
- **Plugin no longer claims unrelated files** (`.md`, `.ini`, `.inf`,
  etc.). The previous detect string used `FIND("#TBL")` which scans
  the first 8 KB of the file, so any random text file mentioning
  `#TBL` anywhere in its content was wrongly matched. The new detect
  string uses **only** exact matches:
  - file extension is `.tbl`, OR
  - the file's first 4 bytes are exactly `#TBL` (plain TBL), OR
  - the file's first 2 bytes are `F9 BA` (CLE encrypted), OR
  - the file's first 2 bytes are `D9 BA` (CLE encrypted+compressed)

### Important: existing installations need a one-time fix

If you installed v1.3.0 / v1.3.1 / v1.3.2 (or installed manually
through Configuration → Plugins → Lister WLX → Add), Total Commander
saved the **old** detect string into `wincmd.ini` and won't update
it just because you install a newer DLL. To reset:

**Option A (recommended): reinstall via the auto-installer.** Open
`tbl_wlx_v1.3.4_plugin.zip` from inside Total Commander, click Yes on
the install dialog. TC overwrites both the DLL and the `wincmd.ini`
detect string entry.

**Option B: manual edit.** Open `wincmd.ini` (Configuration →
Options → Configuration → "Open in editor"), find your `[ListerPlugins]`
section, locate the `<n>_detect=...` line that mentions
`tbl_wlx.wlx64`, and replace its value with:

```
EXT="TBL" | ([0]=35 & [1]=84 & [2]=66 & [3]=76) | ([0]=249 & [1]=186) | ([0]=217 & [1]=186)
```

Save, restart TC.

**Option C: remove + re-add.** In TC: Configuration → Options →
Plugins → Lister (WLX) → Configure → select the existing TBL plugin →
Remove. Then either re-run the installer ZIP, or click Add and pick
`tbl_wlx.wlx64` again.

## v1.3.2 (2026-04)

### Fixed
- **Crash on close**: Total Commander would crash when closing the
  Lister window in some cases. Root cause: the overlay Edit's
  subclassed window proc dereferenced freed grid state (`St^`)
  during `WM_NCDESTROY` after `ClearAllTabs` had already disposed
  the state record. The subclass procs are now hardened to handle
  a nil state, and `DestroyGridState` explicitly unsubclasses the
  Edit before disposing state. `ClearAllTabs` similarly unsubclasses
  the JSON-tab Edit before destroying it.
- Managed-type fields (`Cols`, `Rows`, `Caption`) are now explicitly
  nilled before `Dispose` to avoid double-finalize on shared
  dynamic-array data when the same `Cols` array is held by both a
  `TGridState` and its parent `TTabEntry`.
- `ListCloseWindow` now guards `DestroyWindow` with `IsWindow` and
  wraps each teardown step in its own `try/except`.

## v1.3.1 (2026-04)

### Fixed
- **Plugin DLL renamed from `tbl_wlx.dll` to `tbl_wlx.wlx64`**.
  Total Commander only treats files with `.wlx`/`.wlx64` extensions
  as Lister plugins; the previous `.dll` name caused TC's plugin
  installer to skip auto-detection.
- `pluginst.inf` updated to point at `tbl_wlx.wlx64`.
- Manual install: pick the `.wlx64` file (not a `.dll`) when adding
  the plugin via Configuration → Options → Plugins.

## v1.3 (2026-04)

### Added
- F2 reload now functional (re-reads file from disk, asks before
  discarding unsaved changes)
- INI settings persistence (`[TBL_WLX] PreferredGame=...`)
- TC plugin auto-installer manifest (`pluginst.inf`)
- Crash-safety: every `stdcall` entry point wrapped in `try/except`
- Memory leak audit (HeapTrc): 0 leaks on happy path and error path
- Fuzz hardening: bounds check on `SecStart + SecLen*SecCount`
  prevents OOM on malformed section directories
- `build.sh` / `run-tests.sh` reproducibility scripts
- `TROUBLESHOOTING.md`

### Changed
- (Internal) Removed dead `tbllib.pas` from the eArmada8-based
  prototype. All file I/O lives in `tblfile.pas` now.

## v1.2 (2026-04)

### Added
- Tabbed view: one tab per TBL section + a JSON tab at the end
- Per-section grid view (Win32 ListView, virtual mode)
- Inline cell edit overlay (double-click → Edit → Enter/Escape)
- Sub-grid dialog for nested-struct fields (modal popup)
- Tab strip at top of viewer (`SysTabControl32`)

### Changed
- `gridmodel`: nested struct fields now render as a single
  `[N rows]` summary cell instead of inline-expanding into N×K
  columns. Cleaner UX for sections like `ItemTableData.effects`.
- DLL grew from ~520 KB to ~725 KB due to grid + tab UI

## v1.1 (2026-04)

### Added
- Editable JSON view (`ES_READONLY` removed)
- Ctrl+S in the JSON edit triggers Save
- `EM_SETMODIFY` / `EM_GETMODIFY` dirty tracking
- Close-prompt for unsaved changes
- `StripHeaderComment` strips informational `//` lines on save

## v1.0 (2026-04)

### Added
- Initial WLX Lister plugin for Total Commander
- Read-only JSON view of decoded `#TBL` files
- 11 standard WLX entry points
- Schema DB driven by KuroTools' 282-header / 346-variant set
- Auto-detect CLE wrap (Blowfish-CTR + ZSTD)
- Verbatim raw passthrough for sections without a schema
- Round-trip parity: 408/411 bit-identical, 411/411 functionally
  identical against KuroTools Python `json2tbl`
