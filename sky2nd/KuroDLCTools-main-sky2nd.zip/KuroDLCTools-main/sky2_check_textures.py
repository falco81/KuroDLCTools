#!/usr/bin/env python3
"""
sky2_check_textures.py - check (and repair) the textures used by .mdl models
for Trails in the Sky 2nd Chapter.

Trails in the Sky 2nd Chapter stores its DDS textures compressed in the LZ4
frame format (magic 04 22 4D 18).  A plain .dds file is only read by the game
when a mod loader bypasses that (the "LZ4 bypassed: vtable swapped for raw DDS"
line in the log); packed into a .pac, or without such a loader, the game will
not read it.  Textures carried over from Kuro / Daybreak are worse still: those
are Blowfish-encrypted or zstd-compressed (F9BA / C9BA / D9BA) and Sky 2nd
cannot read them at all.

This script walks every .mdl in a directory, collects the textures each model
asks for, finds those files on disk and reports the ones that are in the wrong
format or missing.  With --fix it converts them to the format 2nd Chapter
expects, keeping a backup of every file it touches.

Usage:
  python sky2_check_textures.py                 # check the current folder
  python sky2_check_textures.py <dir>           # check another folder
  python sky2_check_textures.py --fix           # convert what can be converted
  python sky2_check_textures.py --decompress    # the other way, for editing

Options:
  --fix                Convert textures to the Sky 2nd Chapter format.
  --decompress         Decompress LZ4 textures back to plain .dds (for editing
                       in an image editor). Mutually exclusive with --fix.
  --image-dir DIR      Where the .dds files live. Default: auto-detected
                       (asset/dx11/image above the model tree), plus each
                       model's own folder and a recursive search of the scan
                       folder.
  --shader-ref PATH    A folder of untouched 2nd Chapter .mdl files (or a
                       single .mdl). Materials whose shader configuration does
                       not appear anywhere in that reference are reported -
                       those are the ones the game logs as
                       "file not found: asset/dx11/shader/<name>#<hash>.fxo".
  --no-recursive       Only look at .mdl files in the folder itself.
  --no-backup          Do not keep a backup of converted textures.
  --list-ok            Also list textures that are already fine.
  -q, --quiet          Only print the problems and the summary.

Exit code is 1 when unresolved problems remain, so the script can be used in a
build step.

Requires the lz4 module: python -m pip install lz4
The blowfish and zstandard modules are only needed to convert Kuro-format
(F9BA / C9BA / D9BA) textures.

Part of the KuroDLCTools toolkit. The LZ4 texture format of Sky 2nd Chapter was
documented by eArmada8 (kuro_mdl_tool); the MDL material parser follows the
same project's format work.
"""

import argparse
import glob
import io
import os
import struct
import sys

# ---------------------------------------------------------------------------
# Optional modules. Only lz4 is needed for the common case.
# ---------------------------------------------------------------------------
try:
    import lz4.frame
    HAS_LZ4 = True
except ImportError:
    HAS_LZ4 = False

try:
    import xxhash
    HAS_XXHASH = True
except ImportError:
    HAS_XXHASH = False

try:
    import operator
    import blowfish
    HAS_BLOWFISH = True
except ImportError:
    HAS_BLOWFISH = False

try:
    import zstandard
    HAS_ZSTD = True
except ImportError:
    HAS_ZSTD = False


# ---------------------------------------------------------------------------
# Console output. Texture and material names can contain characters the Windows
# console cannot encode, so every print goes through here.
# ---------------------------------------------------------------------------

def out(text=''):
    try:
        print(text)
    except UnicodeEncodeError:
        enc = sys.stdout.encoding or 'ascii'
        print(text.encode(enc, 'replace').decode(enc, 'replace'))


# ---------------------------------------------------------------------------
# File format detection
# ---------------------------------------------------------------------------

LZ4_MAGIC = b'\x04\x22\x4D\x18'
DDS_MAGIC = b'DDS '
CLE_MAGICS = (b'F9BA', b'C9BA', b'D9BA')

# What a texture file turned out to be.
OK      = 'ok'           # LZ4 frame holding a DDS - what the game wants
RAW     = 'raw'          # plain .dds - needs compressing
CLE     = 'cle'          # Kuro encrypted / zstd compressed - wrong game
BAD_LZ4 = 'bad_lz4'      # LZ4 frame that does not hold a valid DDS
UNKNOWN = 'unknown'      # something else entirely
MISSING = 'missing'      # no such file

STATE_TEXT = {
    OK:      'ok (lz4)',
    RAW:     'plain DDS, not compressed for Sky 2nd',
    CLE:     'Kuro format (encrypted / zstd), unreadable in Sky 2nd',
    BAD_LZ4: 'lz4 container, but the contents are not a DDS',
    UNKNOWN: 'unrecognised file format',
    MISSING: 'file not found',
}

FIXABLE = (RAW, CLE)


def classify(path):
    """Return (state, detail) for one texture file."""
    try:
        with open(path, 'rb') as f:
            head = f.read(4)
    except (OSError, IOError) as e:
        return UNKNOWN, str(e)

    if head == DDS_MAGIC:
        return RAW, ''
    if head in CLE_MAGICS:
        return CLE, head.decode('ascii', 'replace')
    if head == LZ4_MAGIC:
        if not HAS_LZ4:
            # Without the module the contents cannot be verified. The magic is
            # right, so take the file at face value.
            return OK, 'contents not verified (lz4 module missing)'
        try:
            with open(path, 'rb') as f:
                data = lz4.frame.decompress(f.read())
        except Exception as e:
            return BAD_LZ4, 'does not decompress: {}'.format(e)
        if data[:4] != DDS_MAGIC:
            return BAD_LZ4, 'decompresses to something that is not a DDS'
        return OK, ''
    return UNKNOWN, 'starts with {!r}'.format(head)


# DXGI formats worth naming; anything else is shown as its number.
DXGI_NAMES = {
    28: 'R8G8B8A8', 29: 'R8G8B8A8_SRGB', 71: 'BC1', 72: 'BC1_SRGB',
    74: 'BC2', 77: 'BC3', 78: 'BC3_SRGB', 80: 'BC4', 83: 'BC5',
    87: 'B8G8R8A8', 95: 'BC6H', 98: 'BC7', 99: 'BC7_SRGB',
}


def dds_info(data):
    """(width, height, mipmaps, format) of a DDS held in memory, or None."""
    if len(data) < 128 or data[:4] != DDS_MAGIC:
        return None
    try:
        size, _flags, height, width, _pitch, _depth, mips = \
            struct.unpack_from('<7I', data, 4)
        # A real DDS header is 124 bytes and the rest has to be plausible;
        # without this a file that merely starts with "DDS " reports nonsense.
        if size != 124 or not (0 < width <= 65536) or not (0 < height <= 65536) \
                or mips > 32:
            return None
        four_cc = struct.unpack_from('<4s', data, 4 + 80)[0]
        name = four_cc.decode('ascii', 'replace').strip('\x00')
        if name == 'DX10' and len(data) >= 148:
            dxgi, = struct.unpack_from('<I', data, 4 + 124)
            name = DXGI_NAMES.get(dxgi, 'DXGI{}'.format(dxgi))
        elif not name:
            name = 'uncompressed'
        return width, height, max(mips, 1), name
    except struct.error:
        return None


def read_dds_info(path, state):
    """Inspect a texture file whatever wrapper it is in."""
    try:
        with open(path, 'rb') as f:
            data = f.read()
    except (OSError, IOError):
        return None
    if state == OK and HAS_LZ4:
        try:
            data = lz4.frame.decompress(data)
        except Exception:
            return None
    elif state == CLE:
        try:
            data = decrypt_cle(data)
        except Exception:
            return None
    return dds_info(data)


def decrypt_cle(file_content):
    """Unwrap a Kuro / Daybreak asset (F9BA, C9BA, D9BA).

    Thank you to the authors of KuroTools for this function.
    https://github.com/nnguyen259/KuroTools
    """
    key = b"\x16\x4B\x7D\x0F\x4F\xA7\x4C\xAC\xD3\x7A\x06\xD9\xF8\x6D\x20\x94"
    IV = b"\x9D\x8F\x9D\xA1\x49\x60\xCC\x4C"

    result = file_content
    magic = file_content[0:4]
    while magic in CLE_MAGICS:
        if magic in (b'F9BA', b'C9BA'):
            if not HAS_BLOWFISH:
                raise RuntimeError("the blowfish module is needed to decrypt "
                                   "{} files".format(magic.decode()))
            cipher = blowfish.Cipher(key, byte_order="big")
            iv = struct.unpack(">Q", IV)
            dec_counter = blowfish.ctr_counter(iv[0], f=operator.add)
            result = b"".join(cipher.decrypt_ctr(file_content[8:], dec_counter))
        else:
            if not HAS_ZSTD:
                raise RuntimeError("the zstandard module is needed to "
                                   "decompress D9BA files")
            result = zstandard.ZstdDecompressor().decompress(file_content[8:])
        file_content = result
        magic = file_content[0:4]
    return result


# ---------------------------------------------------------------------------
# MDL parsing. Only the material section is needed, so this is a trimmed copy
# of the parser in kuro_mdl_rename.py / kuro_mdl_tool - that keeps the script
# usable on its own, dropped into a folder of models.
# ---------------------------------------------------------------------------

MDL_MAGIC = 0x204c444d          # 'MDL '


def read_pascal_string(f):
    size = int.from_bytes(f.read(1), byteorder='little')
    return f.read(size)


def read_mdl(path):
    """Return the model bytes, unwrapped if the file is a Kuro CLE asset."""
    with open(path, 'rb') as f:
        data = f.read()
    if data[:4] in CLE_MAGICS:
        data = decrypt_cle(data)
    return data


def isolate_material_data(mdl_data):
    """Return the raw bytes of the material section, or None."""
    with io.BytesIO(mdl_data) as f:
        header = struct.unpack("<III", f.read(12))
        if header[0] != MDL_MAGIC:
            return None
        sections = []
        while True:
            info = {}
            try:
                info['type'], info['size'] = struct.unpack("<II", f.read(8))
            except struct.error:
                break
            info['start'] = f.tell()
            sections.append(info)
            f.seek(info['size'], 1)
        # Kuro-engine models have a single material section, type 0.
        for section in sections:
            if section['type'] == 0:
                f.seek(section['start'], 0)
                return f.read(section['size'])
    return None


def obtain_material_data(mdl_data):
    """Parse the material section into a list of material dicts."""
    kuro_ver, = struct.unpack("<I", mdl_data[4:8])
    material_data = isolate_material_data(mdl_data)
    if material_data is None:
        return []

    materials = []
    with io.BytesIO(material_data) as f:
        blocks, = struct.unpack("<I", f.read(4))
        for _ in range(blocks):
            material = {}
            material['material_name'] = read_pascal_string(f).decode('ASCII', 'replace')
            material['shader_name'] = read_pascal_string(f).decode('ASCII', 'replace')
            read_pascal_string(f)                    # str3, not needed here

            texture_count, = struct.unpack("<I", f.read(4))
            material['textures'] = []
            for _t in range(texture_count):
                name = read_pascal_string(f).decode('ASCII', 'replace')
                f.read(4)                            # texture_slot
                if kuro_ver > 1:
                    f.read(4)                        # unk_00
                f.read(8)                            # wrapS, wrapT
                if kuro_ver > 1:
                    f.read(4)                        # unk_03
                material['textures'].append(name)

            # Shader parameters. The payload size depends on the type.
            shader_count, = struct.unpack("<I", f.read(4))
            payload = {0: 4, 1: 4, 2: 8, 3: 12, 4: 4, 5: 8, 6: 12,
                       7: 16, 8: 64, 0xFFFFFFFF: 0}
            for _s in range(shader_count):
                read_pascal_string(f)                # parameter name
                type_int, = struct.unpack("<I", f.read(4))
                f.read(payload.get(type_int, 0))

            # The switch block identifies the compiled shader configuration.
            switch_count, = struct.unpack("<I", f.read(4))
            switch_start = f.tell()
            for _w in range(switch_count):
                read_pascal_string(f)                # switch name
                f.read(4)                            # value
            switch_end = f.tell()
            f.seek(switch_start, 0)
            switch_bytes = f.read(switch_end - switch_start)
            material['switches_hash'] = (xxhash.xxh64_hexdigest(switch_bytes)
                                         if HAS_XXHASH else '')

            uv_count, = struct.unpack("<I", f.read(4))
            f.read(uv_count)
            unknown1_count, = struct.unpack("<I", f.read(4))
            f.read(unknown1_count)
            f.read(20)                               # unknown2

            materials.append(material)
    return materials


def shader_id(material):
    """'chr_cloth#<switch hash>' - the compiled configuration a material needs."""
    return "{0}#{1}".format(material['shader_name'], material['switches_hash'])


# ---------------------------------------------------------------------------
# Locating texture files
# ---------------------------------------------------------------------------

def find_game_image_dirs(start_dir):
    """Walk up from start_dir collecting asset/dx11/image folders."""
    found = []
    current = os.path.abspath(start_dir)
    while True:
        candidate = os.path.join(current, 'asset', 'dx11', 'image')
        if os.path.isdir(candidate):
            found.append(candidate)
        parent = os.path.dirname(current)
        if parent == current:
            break
        current = parent
    return found


def build_texture_index(roots, recursive=True):
    """Map lowercase texture basename (no extension) -> full path.

    Earlier roots win, so an explicit --image-dir beats a stray copy picked up
    by the recursive search.
    """
    index = {}
    for root in roots:
        if not os.path.isdir(root):
            continue
        pattern = os.path.join(root, '**', '*.dds') if recursive \
            else os.path.join(root, '*.dds')
        for path in glob.glob(pattern, recursive=recursive):
            key = os.path.splitext(os.path.basename(path))[0].lower()
            index.setdefault(key, path)
    return index


# ---------------------------------------------------------------------------
# Conversion
# ---------------------------------------------------------------------------

def backup_path(path, suffix):
    """First free '<path><suffix>' name; an existing backup is never replaced."""
    candidate = path + suffix
    if not os.path.exists(candidate):
        return candidate
    n = 1
    while os.path.exists("{0}{1}".format(candidate, n)):
        n += 1
    return "{0}{1}".format(candidate, n)


def convert_to_sky2(path, state, keep_backup=True):
    """Convert one texture into the Sky 2nd Chapter format.

    Returns (True, note) on success, (False, reason) otherwise.
    """
    if not HAS_LZ4:
        return False, "the lz4 module is missing (python -m pip install lz4)"

    with open(path, 'rb') as f:
        data = f.read()

    if state == CLE:
        try:
            data = decrypt_cle(data)
        except Exception as e:
            return False, str(e)
        if data[:4] != DDS_MAGIC:
            return False, "unwrapped to something that is not a DDS"
        suffix = '.compressed_original'
    else:
        suffix = '.uncompressed_original'

    compressed = lz4.frame.compress(data)

    if keep_backup:
        target = backup_path(path, suffix)
        os.replace(path, target)
        note = "backup: " + os.path.basename(target)
    else:
        note = "no backup"

    with open(path, 'wb') as f:
        f.write(compressed)
    return True, note


def decompress_to_dds(path, state, keep_backup=True):
    """Turn an LZ4 (or Kuro) texture back into a plain .dds for editing."""
    with open(path, 'rb') as f:
        data = f.read()

    if state == OK:
        if not HAS_LZ4:
            return False, "the lz4 module is missing (python -m pip install lz4)"
        try:
            data = lz4.frame.decompress(data)
        except Exception as e:
            return False, str(e)
    elif state == CLE:
        try:
            data = decrypt_cle(data)
        except Exception as e:
            return False, str(e)
    else:
        return False, "nothing to decompress"

    if data[:4] != DDS_MAGIC:
        return False, "the result is not a DDS"

    if keep_backup:
        target = backup_path(path, '.compressed_original')
        os.replace(path, target)
        note = "backup: " + os.path.basename(target)
    else:
        note = "no backup"

    with open(path, 'wb') as f:
        f.write(data)
    return True, note


# ---------------------------------------------------------------------------
# Shader reference set
# ---------------------------------------------------------------------------

def collect_shader_ids(paths, recursive=True):
    """Every 'name#hash' configuration used by the reference models."""
    ids = set()
    files = []
    for path in paths:
        if os.path.isfile(path):
            files.append(path)
        elif os.path.isdir(path):
            pattern = os.path.join(path, '**', '*.mdl') if recursive \
                else os.path.join(path, '*.mdl')
            files.extend(glob.glob(pattern, recursive=recursive))
    for mdl in files:
        try:
            for material in obtain_material_data(read_mdl(mdl)):
                ids.add(shader_id(material))
        except Exception:
            continue
    return ids, len(files)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Check (and repair) the textures used by .mdl models for "
                    "Trails in the Sky 2nd Chapter.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="Sky 2nd Chapter reads DDS textures compressed with LZ4. A plain\n"
               ".dds only works with a mod loader that bypasses this, and never\n"
               "inside a .pac. --fix compresses them; --decompress undoes it.")
    parser.add_argument('directory', nargs='?', default='.',
                        help="folder with the .mdl files (default: current)")
    parser.add_argument('--fix', action='store_true',
                        help="convert textures to the Sky 2nd Chapter format")
    parser.add_argument('--decompress', action='store_true',
                        help="convert textures back to plain .dds for editing")
    parser.add_argument('--image-dir', action='append', default=[],
                        metavar='DIR', help="where the .dds files are")
    parser.add_argument('--shader-ref', action='append', default=[],
                        metavar='PATH',
                        help="untouched 2nd Chapter .mdl files to check the "
                             "shader configurations against")
    parser.add_argument('--no-recursive', action='store_true',
                        help="do not descend into subfolders")
    parser.add_argument('--no-backup', action='store_true',
                        help="do not keep a backup of converted textures")
    parser.add_argument('--list-ok', action='store_true',
                        help="also list textures that are already fine")
    parser.add_argument('-q', '--quiet', action='store_true',
                        help="only print the problems and the summary")
    args = parser.parse_args()

    if args.fix and args.decompress:
        out("--fix and --decompress cannot be used together.")
        return 2

    recursive = not args.no_recursive
    scan_dir = os.path.abspath(args.directory)
    if not os.path.isdir(scan_dir):
        out("Not a folder: {}".format(scan_dir))
        return 2

    pattern = os.path.join(scan_dir, '**', '*.mdl') if recursive \
        else os.path.join(scan_dir, '*.mdl')
    mdl_files = sorted(glob.glob(pattern, recursive=recursive))
    if not mdl_files:
        out("No .mdl files found in {}".format(scan_dir))
        return 0

    if (args.fix or args.decompress) and not HAS_LZ4:
        out("The lz4 module is missing - textures cannot be converted.")
        out("Install it with:  python -m pip install lz4")
        return 2

    # Where to look for the textures: explicit folders first, then the game's
    # image folder, then each model's own folder and the scan folder.
    roots = [os.path.abspath(d) for d in args.image_dir]
    auto_dirs = find_game_image_dirs(scan_dir)
    for mdl in mdl_files:
        for candidate in find_game_image_dirs(os.path.dirname(mdl)):
            if candidate not in auto_dirs:
                auto_dirs.append(candidate)
    roots.extend(auto_dirs)
    roots.extend(sorted({os.path.dirname(m) for m in mdl_files}))
    roots.append(scan_dir)

    seen_roots, search_roots = set(), []
    for root in roots:
        key = os.path.normcase(os.path.abspath(root))
        if key not in seen_roots:
            seen_roots.add(key)
            search_roots.append(root)

    index = build_texture_index(search_roots, recursive=True)

    if not args.quiet:
        out("Models:   {0} .mdl file(s) in {1}".format(len(mdl_files), scan_dir))
        if auto_dirs:
            out("Textures: {}".format(auto_dirs[0]))
        out("Found:    {} .dds file(s)".format(len(index)))
        if args.shader_ref and not HAS_XXHASH:
            out("Note:     the xxhash module is missing, shaders cannot be checked.")
        out("")

    shader_ref_ids, shader_ref_count = set(), 0
    if args.shader_ref and HAS_XXHASH:
        shader_ref_ids, shader_ref_count = collect_shader_ids(
            args.shader_ref, recursive=recursive)
        if not args.quiet:
            out("Shader reference: {0} configuration(s) from {1} model(s)\n".format(
                len(shader_ref_ids), shader_ref_count))

    # ---- walk the models -------------------------------------------------
    handled = {}                      # texture path -> state after processing
    counted = set()                   # texture names already counted, for totals
    info_cache = {}                   # texture path -> (w, h, mips, format)
    no_mipmaps = []                   # textures shipped without a mip chain
    formats = {}                      # format -> how many textures use it
    bad_models = []

    def describe(path, state):
        """'  (2048x2048 BC7, no mipmaps)' for a texture, or '' if unreadable."""
        if path is None:
            return ''
        if path not in info_cache:
            info_cache[path] = read_dds_info(path, state)
        info = info_cache[path]
        if info is None:
            return ''
        width, height, mips, fmt = info
        return "  ({0}x{1} {2}, {3})".format(
            width, height, fmt,
            "no mipmaps" if mips <= 1 else "{} mipmaps".format(mips))
    unreadable = []
    shader_problems = []
    counts = {state: 0 for state in STATE_TEXT}
    fixed_count, failed_count = 0, 0

    for mdl in mdl_files:
        rel = os.path.relpath(mdl, scan_dir)
        try:
            materials = obtain_material_data(read_mdl(mdl))
        except Exception as e:
            unreadable.append((rel, str(e)))
            continue
        if not materials:
            unreadable.append((rel, "no material section"))
            continue

        names = []
        for material in materials:
            for name in material['textures']:
                if name and name not in names:
                    names.append(name)

        lines = []
        model_bad = False

        for name in names:
            path = index.get(name.lower())
            if path is None:
                state, detail = MISSING, ''
            else:
                state, detail = classify(path)

            # Models usually share textures. Each file is converted once, and
            # the totals count files rather than references to them.
            first_time = name.lower() not in counted
            counted.add(name.lower())

            # Image properties are worth knowing even when the wrapper is fine:
            # a texture without mipmaps shimmers at distance and costs memory
            # bandwidth, and it is easy to lose the mip chain when re-exporting.
            if first_time and path is not None:
                if path not in info_cache:
                    info_cache[path] = read_dds_info(path, state)
                info = info_cache[path]
                if info is not None:
                    formats[info[3]] = formats.get(info[3], 0) + 1
                    if info[2] <= 1:
                        no_mipmaps.append((name, info))

            if path is not None and path in handled:
                state = handled[path]
                detail = ''

            # --decompress turns the game's format back into a plain .dds, so
            # there a plain DDS is the goal and an "ok" texture is the one to
            # convert.
            if args.decompress and state == RAW:
                if args.list_ok:
                    lines.append("    [plain]   {}.dds".format(name))
                continue

            if args.decompress and state in (OK, CLE):
                if first_time:
                    counts[state] += 1
                ok, note = decompress_to_dds(path, state,
                                             keep_backup=not args.no_backup)
                if ok:
                    fixed_count += 1
                    handled[path] = RAW
                    lines.append("    [plain]   {0}.dds  ({1})".format(name, note))
                else:
                    failed_count += 1
                    model_bad = True
                    lines.append("    [FAILED]  {0}.dds  {1}".format(name, note))
                continue

            if state == OK:
                if first_time:
                    counts[OK] += 1
                if args.list_ok:
                    lines.append("    [ok]      {0}.dds{1}".format(
                        name, describe(path, state)))
                if path is not None:
                    handled[path] = OK
                continue

            if first_time:
                counts[state] += 1
            model_bad = True
            label = STATE_TEXT[state] + (" - " + detail if detail else "")

            if args.fix and state in FIXABLE:
                ok, note = convert_to_sky2(path, state, keep_backup=not args.no_backup)
                if ok:
                    fixed_count += 1
                    handled[path] = OK
                    lines.append("    [fixed]   {0}.dds  ({1}; {2})".format(
                        name, STATE_TEXT[state], note))
                else:
                    failed_count += 1
                    handled[path] = state
                    lines.append("    [FAILED]  {0}.dds  {1}".format(name, note))
            else:
                if path is not None:
                    handled[path] = state
                lines.append("    [{0:<7}] {1}.dds  {2}".format(state, name, label))
                if state != MISSING and path:
                    lines.append("              {}".format(path))

        # Shader configurations this model needs.
        if shader_ref_ids:
            missing_shaders = []
            for material in materials:
                sid = shader_id(material)
                if sid not in shader_ref_ids and sid not in missing_shaders:
                    missing_shaders.append(sid)
                    shader_problems.append((rel, material['material_name'], sid))
            for sid in missing_shaders:
                model_bad = True
                lines.append("    [shader]  {} - not in the reference models".format(sid))

        if model_bad or (args.list_ok and lines):
            if model_bad:
                bad_models.append(rel)
            out(rel)
            for line in lines:
                out(line)
        elif not args.quiet:
            out("{0}   ({1} texture(s), all ok)".format(rel, len(names)))

    # ---- summary ---------------------------------------------------------
    out("")
    out("=" * 62)
    problems = sum(counts[s] for s in (RAW, CLE, BAD_LZ4, UNKNOWN, MISSING))
    out("Models checked:      {}".format(len(mdl_files)))
    out("Textures ok:         {}".format(counts[OK]))
    if counts[RAW]:
        out("Plain DDS:           {}  (not compressed for Sky 2nd)".format(counts[RAW]))
    if counts[CLE]:
        out("Kuro format:         {}  (unreadable in Sky 2nd)".format(counts[CLE]))
    if counts[BAD_LZ4]:
        out("Damaged lz4:         {}".format(counts[BAD_LZ4]))
    if counts[UNKNOWN]:
        out("Unrecognised:        {}".format(counts[UNKNOWN]))
    if counts[MISSING]:
        out("Missing files:       {}".format(counts[MISSING]))
    if unreadable:
        out("Models unreadable:   {}".format(len(unreadable)))
        for rel, reason in unreadable:
            out("    {0}: {1}".format(rel, reason))
    if shader_problems:
        out("Shader problems:     {}".format(len(shader_problems)))
    if formats:
        out("Formats:             {}".format(", ".join(
            "{0} x{1}".format(fmt, n) for fmt, n in
            sorted(formats.items(), key=lambda kv: -kv[1]))))
    if no_mipmaps:
        out("Without mipmaps:     {}".format(len(no_mipmaps)))
    if args.fix or args.decompress:
        out("Textures converted:  {}".format(fixed_count))
        if failed_count:
            out("Conversions failed:  {}".format(failed_count))

    remaining = counts[BAD_LZ4] + counts[UNKNOWN] + counts[MISSING] + failed_count
    if not (args.fix or args.decompress):
        remaining += counts[RAW] + counts[CLE]

    out("=" * 62)

    if problems == 0 and not shader_problems and not unreadable:
        out("Everything is in the format Sky 2nd Chapter expects.")
    elif not (args.fix or args.decompress) and (counts[RAW] or counts[CLE]):
        out("Run again with --fix to convert {} texture(s).".format(
            counts[RAW] + counts[CLE]))
    if counts[MISSING]:
        out("Missing textures cannot be repaired - the .dds files have to be "
            "added to the mod,")
        out("unless they are stock textures the game itself supplies, which is "
            "normal and fine.")
        out("Use --image-dir if they live somewhere this script did not look.")
    if no_mipmaps:
        out("")
        out("These textures have no mipmap chain. They still work, but they "
            "shimmer at distance")
        out("and cost more memory bandwidth than they need to. Re-export them "
            "with mipmaps:")
        for name, info in no_mipmaps[:12]:
            out("    {0}.dds  ({1}x{2} {3})".format(name, info[0], info[1], info[3]))
        if len(no_mipmaps) > 12:
            out("    ... and {} more".format(len(no_mipmaps) - 12))
    if shader_problems:
        out("")
        out("The shader configurations listed above are not used by any of the "
            "reference models,")
        out("so 2nd Chapter most likely has no compiled shader for them. The game "
            "reports this as")
        out("'file not found: asset/dx11/shader/<name>#<hash>.fxo' and the "
            "affected meshes render")
        out("wrongly. Shaders cannot be converted - the material has to be "
            "rebuilt from one that")
        out("2nd Chapter has. See kuro_mdl_tool's kuro_find_similar_shaders.py.")

    return 1 if remaining or shader_problems or unreadable else 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        out("\nCancelled.")
        sys.exit(130)
