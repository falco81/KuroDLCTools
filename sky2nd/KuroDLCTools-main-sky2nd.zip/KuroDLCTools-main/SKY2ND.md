# Trails in the Sky 2nd Chapter — what was added

Everything in this package that concerns 2nd Chapter, in one place. The rest of
the toolkit is unchanged and still works for Kuro / Daybreak, Sky 1st Chapter,
Kyoto Xanadu and Ys X exactly as before.

## Install

```bash
install_python_modules.bat          # colorama zstandard lz4 xxhash blowfish
```

`lz4` and `xxhash` are the ones the new scripts need. `blowfish` and
`zstandard` are only used for Kuro-format (CLE) assets, and `sky_pac_lib.py`
needs nothing at all.

---

## New files

| File | What it is |
|---|---|
| `sky2_fix_shaders.py` | Finds and repairs materials whose shader configuration does not exist in 2nd Chapter — the cause of a costume that renders in a viewer but is invisible in game. |
| `sky2_check_textures.py` | Checks the textures every `.mdl` asks for: LZ4 wrapper, format, size, mipmaps. Converts with `--fix`. |
| `kurodlc_convert_sky1_to_sky2.py` | Converts `.kurodlc.json` DLC definitions from 1st to 2nd Chapter, and checks the shop ids against `t_shop.tbl`. |
| `sky_pac_lib.py` | Reader for the `.pac` (FPAC) archives the Sky remakes use instead of `.p3a`. Needs no third-party modules. |
| `kurodlc_game_profiles.py` | The per-game table layouts in one place: entry lengths, entry templates, costume category numbers, `chr_restrict` shape, game detection. |

## Changed files

| File | Change |
|---|---|
| `kurodlc_schema.json` | 11 schemas added, including `ItemTableData` at 256 bytes and `DLCAppIDConvertTableData`. 356 entries total. |
| `kurodlc_make_tbls.py` | Also writes `t_dlc_appid_convert.tbl`, so new DLC gets a Steam AppID mapping. |
| `kurodlc_add_mdl.py` | Generates entries in the layout of the detected game; `--game=kuro\|sky1st\|sky2nd\|ysx`. |
| `fix_subcategory.py` | Uses the costume category of the detected game (15 in Sky, 17 in Kuro). |
| `visualize_id_allocation.py` | Handles `chr_restrict` as a list; category names come from the detected game. |
| `find_all_*.py`, `find_unique_*.py`, `resolve_id_conflicts_in_kurodlc.py`, `shops_replace_in_kurodlc.py` | Accept `.pac` archives as a table source; `kurodlc_lib` and `p3a_lib` are imported independently, so a Sky setup needs no compression modules. |
| `kuro_mdl_rename.py` | Wording and detection cover both Sky chapters. |
| `tbl_wlx_plugin_v2/` | `Sora2` game tag plus `KURODLC_Sora2` schema variants for all 17 sections of the 2nd Chapter tables. Rebuilt `.wlx` / `.wlx64` included. |

---

## The two things that break a converted costume

### 1. Shaders — invisible meshes

Shaders are not compiled at run time. Each material names a shader plus a
configuration, and the engine turns that into one `<shader>#<hash>.fxo`. The
game ships only the combinations its own models use, so a material carried over
from another game can ask for one that was never compiled, and the mesh is not
drawn. The log says:

```
[LOG] file not found: asset/dx11/shader/chr_cloth#6192628a.fxo
```

A viewer renders with its own shaders, which is why the model looks right there.

```bash
# build the reference from the game once - every .pac in that folder is read
python sky2_fix_shaders.py mymod --ref "<game>/pac/steam"

# read the report, then apply it (a .bak of every model is kept)
python sky2_fix_shaders.py mymod --fix
```

A model you know renders correctly in game is the strongest reference there is;
point `--ref` at that instead.

**Note on `kuro_find_missing_shaders.py`:** eArmada's tool compares
`shader_name#<xxh64 of the switch block>` against `sky_shaders.csv`. That misses
this class of problem. On a real broken model it reported `{}` while the game
could not render it, because the switch block was identical to a working
material — the difference was `unknown2[2]` (6 where every working material with
that parameter set had 14). `sky2_fix_shaders.py` therefore compares the whole
configuration: shader, `str3`, the switch block and the parameter block in file
order, the UV mapping and both unknown fields.

### 2. Textures — format

2nd Chapter reads DDS compressed in the LZ4 frame format. A plain `.dds` only
works with a mod loader that bypasses this and never inside a `.pac`; textures
left in Kuro's format (`F9BA` / `C9BA` / `D9BA`) are not readable at all.

```bash
python sky2_check_textures.py mymod            # report
python sky2_check_textures.py mymod --fix      # convert to the game's format
python sky2_check_textures.py mymod --decompress   # back to plain .dds to edit
```

It also reports size, format and mipmaps. Textures it lists as missing are
usually stock ones the game itself supplies, which is fine.

---

## DLC tables

```bash
# convert the DLC definitions and check the shop ids
python kurodlc_convert_sky1_to_sky2.py

# build the tables, including t_dlc_appid_convert.tbl
python kurodlc_make_tbls.py
```

Both go in the game's `table_en` folder next to `kurodlc_lib.py` and
`kurodlc_schema.json`.

2nd Chapter maps every DLC id to a Steam AppID in `t_dlc_appid_convert.tbl`, and
DLC without an entry there does not appear in the in-game DLC menu. Whether the
game is satisfied by the mapping alone or checks ownership with Steam is
untested — if the entry is not enough, sell the items in a shop instead, which
is how Sky costume mods usually do it.

---

## Credits

The MDL and table formats, the shader advice this automates and the LZ4 texture
format are eArmada8's work ([kuro_mdl_tool](https://github.com/eArmada8/kuro_mdl_tool),
[kuro_dlc_tool](https://github.com/eArmada8/kuro_dlc_tool)), building on
[KuroTools](https://github.com/nnguyen259/KuroTools).
