#!/usr/bin/env python3
"""
fix_subcategory.py

Scans all .kurodlc.json files in the current directory and fixes costume
entries in ItemTableData whose subcategory is wrong.

The costume category number differs per game (kurodlc_game_profiles.py):

    Kuro / Daybreak / Kai        costume = 17, accessory = 19
    Trails in the Sky 1st / 2nd  costume = 15, accessory = 17

In every one of them a costume entry needs subcategory 16, so a costume with
subcategory 15 is the typo this script repairs.  The game is detected per file
from the ItemTableData field names, so a folder holding mods for several games
is handled correctly; --game forces one layout for every file.

Usage:
  python fix_subcategory.py                 # dry-run (preview)
  python fix_subcategory.py --apply         # apply changes
  python fix_subcategory.py --game=sky2nd   # force a game instead of detecting
"""

import json, os, sys, glob, shutil, datetime

try:
    from kurodlc_game_profiles import (get_profile, resolve_game_id, GAME_IDS,
                                       detect_game_from_kurodlc, DEFAULT_GAME)
    HAS_PROFILES = True
except ImportError:
    HAS_PROFILES = False
    DEFAULT_GAME = 'kuro'


def costume_category(game_id):
    """Category number that means "costume" in this game."""
    if HAS_PROFILES:
        return get_profile(game_id)['categories']['costume']
    return 17          # Kuro layout, used when the profile module is missing


def costume_subcategory(game_id):
    """Subcategory a costume entry must have (16 in every supported game)."""
    if HAS_PROFILES:
        return get_profile(game_id)['costume_subcategory']
    return 16


def main():
    apply = '--apply' in sys.argv
    forced_game = None

    for arg in sys.argv[1:]:
        if arg.startswith('--game='):
            requested = arg.split('=', 1)[1]
            forced_game = resolve_game_id(requested) if HAS_PROFILES else None
            if forced_game is None:
                print(f"Error: Unknown game '{requested}'."
                      + (" Known: " + ", ".join(GAME_IDS) if HAS_PROFILES else ""))
                return
        elif arg not in ('--apply',):
            print(f"Error: Unknown option '{arg}'")
            print(__doc__)
            return

    files = sorted(glob.glob('*.kurodlc.json'))
    if not files:
        print("No .kurodlc.json files found in current directory.")
        return

    total_fixed = 0
    files_changed = 0

    for fname in files:
        try:
            with open(fname, 'r', encoding='utf-8') as f:
                data = json.load(f)
        except Exception as e:
            print(f"  Error reading {fname}: {e}")
            continue

        if 'ItemTableData' not in data or not data['ItemTableData']:
            continue

        if forced_game:
            game_id = forced_game
            how = 'forced'
        elif HAS_PROFILES:
            game_id = detect_game_from_kurodlc(data)
            how = 'detected'
            if game_id is None:
                game_id = DEFAULT_GAME
                how = 'assumed'
        else:
            game_id = DEFAULT_GAME
            how = 'assumed'

        cat = costume_category(game_id)
        want_sub = costume_subcategory(game_id)

        count = 0
        for entry in data['ItemTableData']:
            if (isinstance(entry, dict)
                    and entry.get('category') == cat
                    and entry.get('subcategory') == want_sub - 1):
                if apply:
                    entry['subcategory'] = want_sub
                count += 1

        if count > 0:
            game_name = get_profile(game_id)['name'] if HAS_PROFILES else 'Kuro'
            print(f"  {fname}: {count} entry(s) with category={cat}, "
                  f"subcategory={want_sub - 1}\u2192{want_sub}  "
                  f"[{game_name}, {how}]")
            total_fixed += count
            files_changed += 1

            if apply:
                backup = fname + '_' + datetime.datetime.now().strftime("%Y%m%d_%H%M%S") + '.bak'
                shutil.copy2(fname, backup)
                with open(fname, 'w', encoding='utf-8') as f:
                    json.dump(data, f, indent=4, ensure_ascii=True)

    print(f"\nTotal: {total_fixed} entries in {files_changed} file(s)")
    if not apply and total_fixed > 0:
        print("[DRY RUN] No files modified. Use --apply to write changes.")
    elif apply and total_fixed > 0:
        print("All changes applied (backups created).")


if __name__ == "__main__":
    main()
