# Trails in the Sky 2nd Chapter — what was added

Everything in this package that concerns 2nd Chapter, in one place. The rest of
the toolkit is unchanged and still works for Kuro / Daybreak, Sky 1st Chapter,
Kyoto Xanadu and Ys X exactly as before.

## Install

```bash
install_python_modules.bat          # colorama zstandard lz4 xxhash blowfish
```

`lz4` and `xxhash` are the ones the new scripts need. `blowfish` and
`zstandard` are only used for Kuro-format (CLE) assets, and `sky_pac_lib.py`
needs nothing at all.

---

## New files

| File | What it is |
|---|---|
| `sky2_fix_shaders.py` | Finds and repairs materials whose shader configuration does not exist in 2nd Chapter — the cause of a costume that renders in a viewer but is invisible in game. `--mdl NAME` limits a run to one model (repeatable); without it every model in the folder is processed. |
| `sky2_fix_skeleton.py` | Finds meshes bound to bones the skeleton lacks - a costume that crashes or hangs the game the moment it loads - and adds the missing bones. Needs kuro_mdl_tool. |
| `sky2_check_textures.py` | Checks textures (the ones the models use, or `--all`): wrapper, broken or truncated DDS, format, mipmaps. `--fix` converts to what the installed mod loader needs (plain DDS or LZ4, detected automatically). |
| `kurodlc_convert_sky1_to_sky2.py` | Converts `.kurodlc.json` DLC definitions from 1st to 2nd Chapter, and checks the shop ids against `t_shop.tbl`. |
| `sky_pac_lib.py` | Reader for the `.pac` (FPAC) archives the Sky remakes use instead of `.p3a`. Needs no third-party modules. |
| `shops_add_category.py` | Puts every item of a kind (all costumes, all accessories...) on sale in a shop and writes a ShopItem-only `.kurodlc.json`. |
| `kurodlc_tui.py` | Small text-UI library for the wizard (lists, checkboxes, filter, wildcard ticking). Plain Python — msvcrt on Windows, termios elsewhere; colorama optional. |
| `kurodlc_game_profiles.py` | The per-game table layouts in one place: entry lengths, entry templates, costume category numbers (costume 17 in Kuro, 15 in Sky; subcategory 16 everywhere), `chr_restrict` shape, game detection, and `migrate_kurodlc()` to convert a whole `.kurodlc.json` between games. |

## Changed files

| File | Change |
|---|---|
| `kurodlc_schema.json` | 11 schemas added, including `ItemTableData` at 256 bytes and `DLCAppIDConvertTableData`. 356 entries total. |
| `kurodlc_make_tbls.py` | Also writes `t_dlc_appid_convert.tbl`, so new DLC gets a Steam AppID mapping; without a console (batch file) the AppID prompt takes its default. |
| `kurodlc_add_mdl.py` | Generates entries in the layout of the game: `--game=kuro\|sky1st\|sky2nd\|ysx`, else the `t_item` table in the folder, else the file. Entries already in the file that were made for another game are converted too (fields, `chr_restrict`, category numbers, DLC record size; `--no-migrate` keeps them), so a 1st Chapter mod needs no `kurodlc_convert_sky1_to_sky2.py` run: `kurodlc_add_mdl.py Mod.kurodlc.json --game=sky2nd --apply`. `--only-new` adds only models no other `.kurodlc.json` in the folder has. |
| `fix_subcategory.py` | Uses the costume category of the detected game (15 in Sky, 17 in Kuro). |
| `visualize_id_allocation.py` | Handles `chr_restrict` as a list; category names come from the detected game. |
| `find_all_*.py`, `find_unique_*.py`, `resolve_id_conflicts_in_kurodlc.py`, `shops_replace_in_kurodlc.py` | Accept `.pac` archives as a table source; `kurodlc_lib` and `p3a_lib` are imported independently, so a Sky setup needs no compression modules. |
| `kuro_mdl_rename.py` | Wording and detection cover both Sky chapters. Finds models, `.mi` files and textures in the game's `.pac` archives also when they are stored relative to the archive (`asset_common_model.pac` holding `chr5000_c72.mdl`) rather than under their full asset path. Started inside a Sky install without `--game`, it now reads the game's `.pac` archives (before, only the loose files in `asset/` were seen); loose files are listed with them and win, as with a mod loader (`--no-loose` leaves them out). Its embedded copy of kuro_mdl_tool now reads and writes MDL v5 skeletons (ported from kuro_mdl_tool 1.6.6) - 2nd Chapter's own models such as `chr5000_c72` are v5 and used to fail with a misaligned skeleton. Non-ASCII (Shift-JIS) names are written back byte for byte. Asks which MDL version to pack the output at (Enter keeps the original) or takes `--mdl-version N`; see *4. MDL version* below. |
| `tbl_wlx_plugin_v2/` | `Sora2` game tag plus `KURODLC_Sora2` schema variants for all 17 sections of the 2nd Chapter tables. Rebuilt `.wlx` / `.wlx64` included. |

---

## The four things that break a converted costume

### 1. Shaders — invisible meshes

Shaders are not compiled at run time. Each material names a shader plus a
configuration, and the engine turns that into one `<shader>#<hash>.fxo`. The
game ships a fixed set of them, so a material carried over from another game can
ask for one that was never compiled, and the mesh is not drawn. The log says:

```
[LOG] file not found: asset/dx11/shader/chr_cloth#6192628a.fxo
```

A viewer renders with its own shaders, which is why the model looks right there.

```bash
# report - the game is found automatically, read once and cached
python sky2_fix_shaders.py mymod

# apply it (a .bak of every model is kept)
python sky2_fix_shaders.py mymod --fix

# the game was not found, or you want a particular copy
python sky2_fix_shaders.py mymod --ref "<game>/pac/steam"
```

The game is looked for in the folders above the models and above the script
(`<game>/pac/steam`), then in every Steam library - extra drives, SteamOS and
Flatpak Steam included. The configurations are cached in `sky2_shader_ref.json`;
`--rebuild` reads the game again after an update, and `--ref` always wins. Models
with the same file name as the ones being checked are left out of an
auto-detected reference, in case the mod is already installed in the game.

**What `--fix` changes, and what it leaves alone.** A configuration that no
model of the game uses is not automatically broken - the game ships more
shaders than its own models use, and a costume that renders fine can be
flagged. So only proven cases are repaired:

| Report | Meaning | `--fix` |
|---|---|---|
| `[broken]` | only `unknown2[2]` lacks the 8 flag (6 where the game has 14) - the proven cause of an invisible mesh | repaired |
| `[?]` | the shader is used by no game model at all (`fur`) | left alone; `--substitute` moves it to `chr_cloth` |
| `[ok]` | the 8 flag is set where the game's models leave it out (14 vs 6) - proven to render | left alone |
| `[?]` | switches or parameters differ from every game model - unverified | left alone; `--aggressive` rewrites it |

If an older version rewrote models that were fine, `--restore` puts every model
back from its first `.bak` (the untouched original); then run `--fix` again.

Why `[?]` is left alone: the game has shaders none of its own models use. A
working port of a Kuro costume (chr5000_c210, fixed by hand) keeps a `fur`
material and six `chr_cloth` materials whose exact configuration appears in no
game model. Whether such a material renders can only be seen in game: the log
says `file not found: asset/dx11/shader/<name>#<hash>.fxo` when it does not.
`--substitute` moves a material whose shader no model uses to `chr_cloth`
(copied from a working material of the same model with the same textures where
possible, textures carried over by role); use it only when the log confirms the
shader is missing.

The hand-made port also shows what a script cannot do: the face, skin and
tights materials were given settings from working Sky costumes of the same
character (`chr5000_c20a`, the game's `chr5000_c64`) and their colours retuned.
That is manual work in a material editor.

A model you know renders correctly in game is the strongest reference there is;
point `--ref` at that instead.

**Note on `kuro_find_missing_shaders.py`:** eArmada's tool compares
`shader_name#<xxh64 of the switch block>` against `sky_shaders.csv`. That misses
this class of problem. On a real broken model it reported `{}` while the game
could not render it, because the switch block was identical to a working
material — the difference was `unknown2[2]` (6 where every working material with
that parameter set had 14). `sky2_fix_shaders.py` therefore compares the whole
configuration: shader, `str3`, the switch block and the parameter block in file
order, the UV mapping and both unknown fields.

### 2. Skeleton — the game crashes or hangs when the costume loads

Each mesh lists the bones it is bound to by name, and the engine looks every
one of them up in the skeleton. A port often keeps the original's list (end
bones like `LeftHand_Top`, hair or ribbon bones) while the skeleton lacks them;
the game then dies right after reading the model - the log's last line is its
`PAC bypass`, before any of its textures or shaders.

```bash
python sky2_fix_skeleton.py mymod          # report
python sky2_fix_skeleton.py mymod --fix    # add the missing bones (.bak kept)
```

Only bones no vertex uses are added, and only the skeleton section changes, so
the model looks exactly as before. Their position is copied from another model
of the same character in the folder where it has them (`--like` names one), so
hair physics in the `.mi` still finds sensible bones; end bones go under the
last bone of their chain. Missing bones that carry weight are reported for
Blender. Reading the meshes uses kuro_mdl_tool: put `kuro_mdl_export_meshes.py`
and `lib_fmtibvb.py` next to the script, or pass `--mdl-tool FOLDER`.

Not every report is a real problem: the game's own `chr5000_c72` (which loads
fine) reports 57 missing bones, 18 of them with weight (its shadow mesh is bound
to skirt bones the costume does not have). Compare with the untouched original
before rebinding anything.

### 3. Textures — format

Loose textures (`asset/dx11/image/*.dds` in the game folder) need the wrapper
the installed mod loader expects - and the two loaders in use want opposite
things:

| Loader | How to tell | Loose textures |
|---|---|---|
| older loader | log: `LZ4 bypassed: vtable swapped for raw DDS` | **plain `.dds`** (`--target old`) |
| **sora2looseload** (Hinkiii/sora1looseload fork, `xinput1_4.dll`) | log: only `Passing '...' to original InitialFileCheck` | **LZ4-wrapped** (`--target new`) |
| packed into a `.pac` | - | LZ4-wrapped (`--target lz4`) |

sora2looseload only redirects the path; the game then reads the file exactly as
it would from a `.pac`, so a plain `.dds` fails with `texture create failed` and
`texture is null`. The older loader switches the reader to raw DDS instead, so
there an LZ4 file fails. Textures left in Kuro's format (`F9BA` / `C9BA` /
`D9BA`) are unreadable either way.

```bash
python sky2_check_textures.py mymod               # textures the models use
python sky2_check_textures.py mymod --all         # every .dds in the folder
python sky2_check_textures.py mymod --all --fix   # convert for the loader found
python sky2_check_textures.py mymod --all --fix --target new   # sora2looseload
python sky2_check_textures.py mymod --all --fix --target old   # the older loader
```

`--target auto` (the default) finds the game folder - above the mod or in the
Steam libraries, or `--game DIR` - and reads the loader DLL next to
`sora_2nd.exe`. When no known loader is there it only reports, and `--fix` asks
for `--target raw` or `lz4`. Every texture is also checked for a valid DDS
header and complete image data. Converted files keep a backup (`.lz4_original`,
`.raw_original`, `.kuro_original`). Textures listed as missing are usually
stock ones the game supplies itself, which is fine.

---|---|---|
| loose files next to the game, served by the mod loader (log: `PAC bypass`, `LZ4 bypassed: vtable swapped for raw DDS`) | **plain `.dds`** | default |
| packed into a `.pac` | LZ4-wrapped DDS (`04 22 4D 18`) | `--target pac` |

The loader switches the game to raw DDS for loose files, so an LZ4-wrapped
texture put there does not load - a real case: `chr5004_pink_a.dds`, LZ4, did
not load while the plain `chr5000_c21_01.dds` did. Textures left in Kuro's
format (`F9BA` / `C9BA` / `D9BA`) are unreadable either way.

```bash
python sky2_check_textures.py mymod               # textures the models use
python sky2_check_textures.py mymod --all         # every .dds in the folder
python sky2_check_textures.py mymod --all --fix   # convert to plain .dds
python sky2_check_textures.py mymod --fix --target pac   # LZ4, for a .pac
```

Every texture is also checked for a valid DDS header and complete image data
(a truncated export fails to load too). Converted files keep a backup
(`.lz4_original`, `.raw_original`, `.kuro_original`). Textures listed as
missing are usually stock ones the game supplies itself, which is fine.

### 4. MDL version — crash on load after the textures were renamed

Seen with `chr5000_c72` (v5): the untouched model loads, the same model whose
materials only point to renamed textures (`kuro_mdl_rename.py`) crashes the
game the moment it is put on - the log ends with

    [MOD] PAC bypass: '...\asset\common\model\mod_chr5000_c72qw.mdl'
    [LOG] Application::OnLowCPUMemory(...)
    [LOG] MakeFreeSpaceInCPUMemory(...) failed

Geometry, skeleton, texture files and name length were ruled out one by one;
repacking the model as MDL version 1 made it load. Why v5 fails here is not
known.

```bash
# kuro_mdl_rename.py asks for the version; or set it directly
python kuro_mdl_rename.py --mdl-version 1 ...
# a model rebuilt with kuro_mdl_tool: put {"mdl_version": 1} in
# <model>/mdl_version.json, or run the importer with -f 1
```

Check the result in game: version 1 stores vertex colours as floats and drops
empty submeshes instead of keeping an invisible placeholder.

---

## Selling a whole category in a shop

Run it without arguments and a keyboard-driven wizard walks you through it:
data source (when there is more than one) → category → shops → items → output
file → confirm. Nothing is written until the last screen.

| Key | Action |
|---|---|
| ↑ ↓ PgUp PgDn Home End | move |
| Space | tick / untick (multi-select lists) |
| Enter | confirm the screen |
| Esc / Backspace | clear the filter, otherwise go back one step |
| `/` | filter as you type; plain text searches id, name and details |
| `*` / `-` | tick / untick every row matching a wildcard pattern (`*Estelle*`, `25??`) |
| `a` / `n` / `i` | tick all / none / invert, applied to the rows shown |

The item screen starts with everything obtainable that is not on sale yet
already ticked. Items marked `[unobtainable]` (NPC and enemy viewer models) and
`[sold in ...]` are shown but not ticked. The wizard needs a real console:
Windows 10+ cmd / PowerShell / Windows Terminal, or any Linux / SteamOS
terminal. `colorama` is used when installed; without it the VT mode is enabled
directly, and `NO_COLOR=1` turns colour off. The widgets live in
`kurodlc_tui.py`, which must sit next to the script.

Only `t_item` and `t_shop` are required. Other tables, when found in the same
places, turn numbers into names: `ItemKindParam2` inside `t_item` gives the
in-game item kinds (Orbment Covers, Weapons...), `t_itemhelp` the category
names where the game has it (Kuro/Kai), and `t_name` the characters — "Estelle"
instead of "char 0", `/Estelle` in the item list, and `--char Estelle`.

`python shops_add_category.py --help` has the full reference with examples.
Any option switches to the plain command line, which suits batch files:

```bash
# look first: every costume the game has
python shops_add_category.py --type costume --list

# put them on sale in Rinon's General Goods, then build the tables
python shops_add_category.py --type costume --shop 22 -o Costumes.kurodlc.json
python kurodlc_make_tbls.py
```

`--type` is resolved per game (costume is 15 in Sky, 17 in Kuro), or use
`--category N`. Narrow it down with `--char N`, `--name TEXT` or `--price N`.
Items the shop already sells are skipped, and so are the ones already put on
sale by the other `.kurodlc.json` files in the folder, so running it twice does
not list anything twice. The entries marked unobtainable - the costume-viewer
models for NPCs and enemies - are left out unless you pass `--include-hidden`.

Sources are detected as in the rest of the toolkit - `t_item.json`,
`t_item.tbl.original`, `t_item.tbl`, `script_en.p3a`, `zzz_combined_tables.p3a`
and the game's `.pac` archives - and when several are present you are asked
which to use. `--source TYPE` forces one and `--no-interactive` takes the first.

The same thing can be done with the two older scripts:
`find_unique_item_id_for_t_item_category.py 15` prints the ids, and
`shops_create.py` turns a config of ids and shops into the ShopItem section.
That route has no filtering and no duplicate checking.

## DLC tables

```bash
# convert the DLC definitions and check the shop ids
python kurodlc_convert_sky1_to_sky2.py

# build the tables, including t_dlc_appid_convert.tbl
python kurodlc_make_tbls.py
```

Both go in the game's `table_en` folder next to `kurodlc_lib.py` and
`kurodlc_schema.json`.

2nd Chapter maps every DLC id to a Steam AppID in `t_dlc_appid_convert.tbl`, and
DLC without an entry there does not appear in the in-game DLC menu. Whether the
game is satisfied by the mapping alone or checks ownership with Steam is
untested — if the entry is not enough, sell the items in a shop instead, which
is how Sky costume mods usually do it.

---

## Credits

The MDL and table formats, the shader advice this automates and the LZ4 texture
format are eArmada8's work ([kuro_mdl_tool](https://github.com/eArmada8/kuro_mdl_tool),
[kuro_dlc_tool](https://github.com/eArmada8/kuro_dlc_tool)), building on
[KuroTools](https://github.com/nnguyen259/KuroTools).
