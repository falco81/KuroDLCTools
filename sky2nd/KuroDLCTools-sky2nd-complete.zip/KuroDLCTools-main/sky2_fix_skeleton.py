#!/usr/bin/env python3
"""
sky2_fix_skeleton.py - find and repair meshes that use bones the skeleton lacks.

Every mesh in an .mdl carries a list of the bones it is bound to, by name. The
engine looks each one up in the model's skeleton when the model is put
together. A name that is not there makes Trails in the Sky 2nd Chapter crash or
hang the moment the costume loads - the log stops right after

    [MOD] PAC bypass: '...\\asset\\common\\model\\chr5000_c03.mdl'

before a single texture or shader of that model is requested.

It happens to ports: the mesh keeps the bone list of the original (end bones
such as LeftHand_Top, hair or ribbon bones), while the skeleton was taken from
another model or trimmed.

Checked for every model:
  - mesh bones missing from the skeleton, and whether any vertex uses them
  - blend indices beyond a mesh's bone list, triangle indices beyond its
    vertices, primitives naming a material that does not exist
  - vertices with no weight at all (a warning: they stay at the origin)

--fix adds the missing bones to the skeleton. Only the skeleton section
changes; meshes, weights and materials stay byte for byte the same. A bone no
vertex uses cannot change how the model looks, so this is safe. Where another
model of the same character has the bone (hair bones LeftHA01... from a
working costume), its position is copied, so physics set up for it in the .mi
works; end bones (*_Top) go under the last bone of their chain.

Reading the meshes needs kuro_mdl_tool (eArmada8): kuro_mdl_export_meshes.py
and lib_fmtibvb.py, next to this script, in the current folder, or given with
--mdl-tool. Its modules: numpy, blowfish, zstandard, xxhash.

Part of the KuroDLCTools toolkit.
"""

import argparse
import glob
import importlib.util
import io
import os
import struct
import sys

MDL_MAGIC = 0x204c444d
NEEDED_MODULES = ('numpy', 'blowfish', 'zstandard', 'xxhash')


def out(text=''):
    try:
        print(text)
    except UnicodeEncodeError:
        enc = sys.stdout.encoding or 'ascii'
        print(text.encode(enc, 'replace').decode(enc, 'replace'))


# ---------------------------------------------------------------------------
# kuro_mdl_tool
# ---------------------------------------------------------------------------

def load_mdl_tool(explicit=None):
    """Import kuro_mdl_export_meshes from wherever it is. (module, error)."""
    missing = [m for m in NEEDED_MODULES if importlib.util.find_spec(m) is None]
    if missing:
        return None, ("kuro_mdl_tool needs these Python modules: {0}\n"
                      "  python -m pip install {0}".format(" ".join(missing)))
    here = os.path.dirname(os.path.abspath(__file__))
    candidates = [explicit] if explicit else []
    candidates += [here, os.getcwd()]
    for base in (here, os.getcwd()):
        candidates += sorted(glob.glob(os.path.join(base, '*mdl*tool*')))
        candidates += sorted(glob.glob(os.path.join(base, '..', '*mdl*tool*')))
    for folder in candidates:
        if folder and os.path.isfile(os.path.join(folder, 'kuro_mdl_export_meshes.py')):
            sys.path.insert(0, os.path.abspath(folder))
            try:
                import kuro_mdl_export_meshes as tool
                return tool, None
            except (Exception, SystemExit) as e:
                return None, "kuro_mdl_export_meshes.py could not be loaded: {}".format(e)
    return None, ("kuro_mdl_export_meshes.py (kuro_mdl_tool by eArmada8) was not found.\n"
                  "Put it and lib_fmtibvb.py next to this script, or use --mdl-tool FOLDER.")


# ---------------------------------------------------------------------------
# MDL sections and the skeleton
# ---------------------------------------------------------------------------

def sections(data):
    """[(type, size, start)] of every section."""
    result, offset = [], 12
    while offset + 8 <= len(data):
        stype, size = struct.unpack_from('<II', data, offset)
        if offset + 8 + size > len(data):
            break
        result.append((stype, size, offset + 8))
        offset += 8 + size
    return result


def read_pascal(f):
    length, = struct.unpack('<B', f.read(1))
    return f.read(length).decode('ASCII')


def pascal(text):
    raw = text.encode('ASCII')
    return struct.pack('<B', len(raw)) + raw


def parse_skeleton(section, kuro_ver):
    nodes = []
    with io.BytesIO(section) as f:
        count, = struct.unpack('<I', f.read(4))
        for _ in range(count):
            node = {'name': read_pascal(f)}
            node['type'], node['mesh_index'] = struct.unpack('<Ii', f.read(8))
            node['pos'] = list(struct.unpack('<3f', f.read(12)))
            node['quat'] = list(struct.unpack('<4f', f.read(16)))
            node['skin'], = struct.unpack('<I', f.read(4))
            node['rot'] = list(struct.unpack('<3f', f.read(12)))
            node['scale'] = list(struct.unpack('<3f', f.read(12)))
            node['unknown'] = list(struct.unpack('<3f', f.read(12)))
            if kuro_ver > 4:
                node['unknown2'], = struct.unpack('<I', f.read(4))
            children, = struct.unpack('<I', f.read(4))
            node['children'] = list(struct.unpack('<{}I'.format(children),
                                                  f.read(4 * children)))
            nodes.append(node)
        rest = f.read()
    return nodes, rest


def build_skeleton(nodes, kuro_ver, rest=b''):
    body = struct.pack('<I', len(nodes))
    for node in nodes:
        body += pascal(node['name'])
        body += struct.pack('<Ii', node['type'], node['mesh_index'])
        body += struct.pack('<3f', *node['pos'])
        body += struct.pack('<4f', *node['quat'])
        body += struct.pack('<I', node['skin'])
        body += struct.pack('<3f', *node['rot'])
        body += struct.pack('<3f', *node['scale'])
        body += struct.pack('<3f', *node['unknown'])
        if kuro_ver > 4:
            body += struct.pack('<I', node.get('unknown2', 0))
        body += struct.pack('<I', len(node['children']))
        body += struct.pack('<{}I'.format(len(node['children'])), *node['children'])
    return body + rest


def replace_section(data, stype, new_body):
    for kind, size, start in sections(data):
        if kind == stype:
            header = data[start - 8:start - 4]
            return (data[:start - 8] + header + struct.pack('<I', len(new_body))
                    + new_body + data[start + size:])
    raise ValueError("no section {}".format(stype))


def parents_of(nodes):
    parent = {}
    for index, node in enumerate(nodes):
        for child in node['children']:
            parent[child] = index
    return parent


def depth_of(nodes, index, parent):
    depth = 0
    while index in parent:
        index = parent[index]
        depth += 1
    return depth


# ---------------------------------------------------------------------------
# Checking
# ---------------------------------------------------------------------------

def inspect(tool, data):
    """Everything the checks need, read through kuro_mdl_tool."""
    import numpy
    materials = tool.obtain_material_data(data)
    mesh = tool.obtain_mesh_data(data, materials)
    blocks = []
    for bi, block in enumerate(mesh['mesh_blocks']):
        names = [n['name'] for n in block['nodes']]
        matrices = {n['name']: numpy.array(n['matrix'], dtype=float)
                    for n in block['nodes']}
        used, problems, unweighted = set(), [], 0
        for pi, prim in enumerate(block['primitives']):
            buf = mesh['mesh_buffers'][bi][pi]
            vb = {e['SemanticName']: e for e in buf['vb']
                  if e['SemanticIndex'] in ('0', 0)}
            vertices = len(buf['vb'][0]['Buffer'])
            triangles = numpy.array(buf['ib']['Buffer']).ravel()
            if triangles.size and triangles.max() >= vertices:
                problems.append("{0}: triangle index {1} past its {2} vertices".format(
                    prim['material'], int(triangles.max()), vertices))
            if 'BLENDINDICES' in vb and 'BLENDWEIGHT' in vb:
                idx = numpy.array(vb['BLENDINDICES']['Buffer'])
                weight = numpy.array(vb['BLENDWEIGHT']['Buffer'])
                live = idx[weight > 0].astype(int)
                if live.size and live.max() >= len(names):
                    problems.append("{0}: blend index {1} past its {2} bones".format(
                        prim['material'], int(live.max()), len(names)))
                used |= set(int(x) for x in live.tolist())
                unweighted += int((weight.sum(axis=1) <= 0).sum())
        blocks.append({'name': block['name'], 'bones': names, 'matrices': matrices,
                       'used': used, 'problems': problems, 'unweighted': unweighted})
    return blocks


# ---------------------------------------------------------------------------
# Repair
# ---------------------------------------------------------------------------

def world_position(matrices, name):
    import numpy
    if name not in matrices:
        return None
    try:
        return numpy.linalg.inv(matrices[name])[3, :3]
    except numpy.linalg.LinAlgError:
        return None


def chain_parent(name, nodes, by_name, parent):
    """Parent for an end bone: LeftHand_Top -> LeftHand, LeftSA_Top -> LeftSA05."""
    if not name.endswith('_Top'):
        return None
    base = name[:-4]
    options = [i for i, n in enumerate(nodes)
               if n['name'] == base or (n['name'].startswith(base)
                                        and n['name'][len(base):].isdigit())]
    if not options:
        return None
    return max(options, key=lambda i: (depth_of(nodes, i, parent), nodes[i]['name']))


def new_bone(name, parent_node):
    bone = {'name': name, 'type': 1, 'mesh_index': -1,
            'pos': [0.0, 0.0, 0.0], 'quat': [0.0, 0.0, 0.0, 1.0],
            'skin': parent_node['skin'] or 2, 'rot': [0.0, 0.0, 0.0],
            'scale': [1.0, 1.0, 1.0], 'unknown': [0.0, 0.0, 0.0], 'children': []}
    if 'unknown2' in parent_node:
        bone['unknown2'] = parent_node['unknown2']
    return bone


def donor_entry(name, donors):
    """(donor, its node, its parent's name) from the first donor that has it."""
    for donor in donors:
        if name in donor['by_name']:
            index = donor['by_name'][name]
            up = donor['parent'].get(index)
            return donor, donor['nodes'][index], \
                (donor['nodes'][up]['name'] if up is not None else None)
    return None, None, None


def place(name, nodes, matrices):
    """Parent for a bone no donor has: end of its chain, else nearest in the bind
    pose, else Root. Returns (index, how)."""
    import numpy
    by_name = {n['name']: i for i, n in enumerate(nodes)}
    index = chain_parent(name, nodes, by_name, parents_of(nodes))
    if index is not None:
        return index, "end of the {} chain".format(nodes[index]['name'])
    here = world_position(matrices, name)
    best = None
    if here is not None:
        for i, n in enumerate(nodes):
            there = world_position(matrices, n['name'])
            if there is not None:
                dist = float(numpy.linalg.norm(here - there))
                if best is None or dist < best[0]:
                    best = (dist, i)
    if best is not None:
        return best[1], "nearest bone"
    index = by_name.get('Root', 0)
    return index, "under {} (no position known)".format(nodes[index]['name'])


def add_missing_bones(nodes, missing, matrices, donors):
    """Append the missing bones to `nodes`. Returns [(name, parent, how)]."""
    import numpy
    added, pending = [], list(missing)
    while pending:
        progress, deferred = False, []
        for name in pending:
            by_name = {n['name']: i for i, n in enumerate(nodes)}
            donor, template, donor_parent = donor_entry(name, donors)
            if template is not None and donor_parent not in by_name \
                    and donor_parent in pending:
                deferred.append(name)          # its parent is added first
                continue
            if template is not None and donor_parent in by_name:
                parent_index = by_name[donor_parent]
                bone = new_bone(name, nodes[parent_index])
                for key in ('type', 'pos', 'quat', 'skin', 'rot', 'scale', 'unknown'):
                    value = template[key]
                    bone[key] = list(value) if isinstance(value, list) else value
                how = "as in {}".format(donor['label'])
            else:
                parent_index, how = place(name, nodes, matrices)
                bone = new_bone(name, nodes[parent_index])
                a = world_position(matrices, name)
                b = world_position(matrices, nodes[parent_index]['name'])
                if a is not None and b is not None:
                    # Bones point along their local +Z in these skeletons.
                    bone['pos'] = [0.0, 0.0, float(numpy.linalg.norm(a - b))]
            nodes.append(bone)
            nodes[parent_index]['children'].append(len(nodes) - 1)
            added.append((name, nodes[parent_index]['name'], how))
            progress = True
        if not progress:                        # a cycle - should not happen
            for name in deferred:
                parent_index, how = place(name, nodes, matrices)
                nodes.append(new_bone(name, nodes[parent_index]))
                nodes[parent_index]['children'].append(len(nodes) - 1)
                added.append((name, nodes[parent_index]['name'], how))
            break
        pending = deferred
    return added


def load_donor(path, label):
    data = open(path, 'rb').read()
    if struct.unpack_from('<I', data, 0)[0] != MDL_MAGIC:
        return None
    ver = struct.unpack_from('<I', data, 4)[0]
    for kind, size, start in sections(data):
        if kind == 2:
            nodes, _ = parse_skeleton(data[start:start + size], ver)
            return {'label': label, 'nodes': nodes, 'parent': parents_of(nodes),
                    'by_name': {n['name']: i for i, n in enumerate(nodes)}}
    return None


def character_of(path):
    base = os.path.basename(path)
    return base.split('_')[0] if '_' in base else os.path.splitext(base)[0]


# ---------------------------------------------------------------------------

def backup_path(path):
    candidate = path + '.bak'
    n = 1
    while os.path.exists(candidate):
        candidate = '{0}.bak{1}'.format(path, n)
        n += 1
    return candidate


def main():
    parser = argparse.ArgumentParser(
        description="Find and repair meshes bound to bones the skeleton does not "
                    "have - a costume that crashes or hangs the game the moment it "
                    "loads.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="Examples:\n"
               "  python sky2_fix_skeleton.py mymod                 report\n"
               "  python sky2_fix_skeleton.py mymod --fix           add the missing bones\n"
               "  python sky2_fix_skeleton.py mymod --fix --like chr5000_c20a.mdl\n"
               "\n"
               "--fix only adds bones no vertex uses (the usual case), so the model looks\n"
               "exactly as before. Missing bones that do carry weight are reported and\n"
               "left for Blender. A .bak of every changed model is kept.")
    parser.add_argument('directory', nargs='?', default='.',
                        help="folder with the .mdl files (default: current)")
    parser.add_argument('--fix', action='store_true',
                        help="add the missing unweighted bones to the skeleton")
    parser.add_argument('--like', action='append', default=[], metavar='MDL',
                        help="a working model of the same character to copy bone "
                             "positions from (default: the other models of that "
                             "character in the folder)")
    parser.add_argument('--mdl-tool', metavar='FOLDER',
                        help="folder with kuro_mdl_tool's kuro_mdl_export_meshes.py")
    parser.add_argument('--no-recursive', action='store_true',
                        help="do not descend into subfolders")
    parser.add_argument('--no-backup', action='store_true',
                        help="do not keep a .bak of changed models")
    args = parser.parse_args()

    tool, problem = load_mdl_tool(args.mdl_tool)
    if tool is None:
        out(problem)
        return 2

    scan = os.path.abspath(args.directory)
    pattern = os.path.join(scan, '*.mdl') if args.no_recursive \
        else os.path.join(scan, '**', '*.mdl')
    files = sorted(glob.glob(pattern, recursive=not args.no_recursive))
    if not files:
        out("No .mdl files in {}".format(scan))
        return 0

    explicit_donors = []
    for path in args.like:
        donor = load_donor(path, os.path.basename(path))
        if donor:
            explicit_donors.append(donor)
        else:
            out("[!] --like {}: not a readable model".format(path))

    bad_models, fixed_models, weighted_total = 0, 0, 0
    for path in files:
        rel = os.path.relpath(path, scan)
        data = open(path, 'rb').read()
        if len(data) < 12 or struct.unpack_from('<I', data, 0)[0] != MDL_MAGIC:
            out("{}   skipped (not a plain MDL - CLE-compressed or other)".format(rel))
            continue
        ver = struct.unpack_from('<I', data, 4)[0]
        skel = [s for s in sections(data) if s[0] == 2]
        if not skel:
            out("{}   no skeleton (animation or static object) - skipped".format(rel))
            continue
        _, size, start = skel[0]
        nodes, rest = parse_skeleton(data[start:start + size], ver)
        names = {n['name'] for n in nodes}
        try:
            blocks = inspect(tool, data)
        except Exception as e:
            out("{0}   could not read the meshes: {1}".format(rel, e))
            bad_models += 1
            continue

        missing, weighted, matrices, problems, unweighted = [], [], {}, [], 0
        for block in blocks:
            problems += ["{0}: {1}".format(block['name'], p) for p in block['problems']]
            unweighted += block['unweighted']
            for i, bone in enumerate(block['bones']):
                if bone not in names:
                    if bone not in missing:
                        missing.append(bone)
                    if i in block['used'] and bone not in weighted:
                        weighted.append(bone)
                    matrices.setdefault(bone, block['matrices'][bone])
            for bone, matrix in block['matrices'].items():
                matrices.setdefault(bone, matrix)

        if not missing and not problems:
            note = "   ({} vertex(es) without weight)".format(unweighted) if unweighted else ""
            out("{0}   ok - {1} bones, {2} mesh(es){3}".format(rel, len(nodes),
                                                               len(blocks), note))
            continue

        bad_models += 1
        out(rel)
        for p in problems:
            out("    [broken] {}".format(p))
        if missing:
            out("    [broken] {0} bone(s) the meshes use are not in the skeleton "
                "({1} carry weight)".format(len(missing), len(weighted)))
            shown = ", ".join(missing[:12]) + (", ..." if len(missing) > 12 else "")
            out("             {}".format(shown))
        if unweighted:
            out("    [warn]   {} vertex(es) without any weight - they stay at the "
                "origin".format(unweighted))
        if weighted:
            weighted_total += 1
            out("    Bones with weight cannot be added safely: their position shapes "
                "the mesh.")
            out("    Rebind those vertices in Blender, or bring the bones over from "
                "the original.")
        if not args.fix or not missing or weighted or problems:
            continue

        donors = list(explicit_donors)
        me = character_of(path)
        for other in files:
            if other != path and character_of(other) == me:
                donor = load_donor(other, os.path.basename(other))
                if donor and any(b in donor['by_name'] for b in missing):
                    donors.append(donor)

        added = add_missing_bones(nodes, missing, matrices, donors)
        new_data = replace_section(data, 2, build_skeleton(nodes, ver, rest))

        # Check the result before writing it.
        try:
            check = inspect(tool, new_data)
            check_nodes, _ = parse_skeleton(
                [new_data[s:s + z] for t, z, s in sections(new_data) if t == 2][0], ver)
            still = [b for blk in check for b in blk['bones']
                     if b not in {n['name'] for n in check_nodes}]
        except Exception as e:
            out("    [FAILED] the repaired model does not read back: {}".format(e))
            continue
        if still:
            out("    [FAILED] still missing after the repair: {}".format(", ".join(still)))
            continue
        untouched = all(new_data[s:s + z] == data[s0:s0 + z0]
                        for (t, z, s), (t0, z0, s0) in zip(sections(new_data), sections(data))
                        if t != 2 and t == t0)

        if not args.no_backup:
            target = backup_path(path)
            with open(target, 'wb') as f:
                f.write(data)
            out("    backup: {}".format(os.path.basename(target)))
        with open(path, 'wb') as f:
            f.write(new_data)
        fixed_models += 1
        out("    added {} bone(s):".format(len(added)))
        for name, parent_name, how in added:
            out("      {0:<24} under {1:<18} {2}".format(name, parent_name, how))
        out("    written - meshes, weights and materials {}".format(
            "unchanged" if untouched else "CHANGED (unexpected!)"))

    out("")
    out("=" * 62)
    out("Models checked:        {}".format(len(files)))
    out("Models with problems:  {}".format(bad_models))
    if args.fix:
        out("Models repaired:       {}".format(fixed_models))
    out("=" * 62)
    if bad_models and not args.fix:
        out("Run again with --fix to add the missing bones (a .bak is kept).")
    if weighted_total:
        out("{} model(s) need Blender: bones with weight are missing.".format(
            weighted_total))
    return 1 if bad_models - fixed_models else 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        out("\nCancelled.")
        sys.exit(130)
